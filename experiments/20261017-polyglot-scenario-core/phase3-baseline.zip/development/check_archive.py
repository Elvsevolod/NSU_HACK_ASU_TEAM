"""Test the packaged code in an isolated directory and reproduce a saved graph."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

VARIANT = Path(__file__).resolve().parents[1]


def main():
    archive = VARIANT / "solution.zip"
    with TemporaryDirectory(prefix="polygraph-archive-") as temporary:
        root = Path(temporary)
        with ZipFile(archive) as source:
            assert all(not name.startswith("/") and ".." not in Path(name).parts for name in source.namelist())
            source.extractall(root)
        frozen = json.loads((root / "development/code-freeze.json").read_text())["files"]
        assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == digest for name, digest in frozen.items())
        env = {**os.environ, "PYTHONPATH": str(root / "code"), "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "29"}
        tests = subprocess.run([sys.executable, "-B", "-m", "pytest", "code/tests", "-q", "-p", "no:cacheprovider"], cwd=root, env=env, capture_output=True, text=True)
        (VARIANT / "benchmark/standalone-tests.stdout.txt").write_text(tests.stdout)
        (VARIANT / "benchmark/standalone-tests.stderr.txt").write_text(tests.stderr)
        assert tests.returncode == 0, tests.stdout + tests.stderr
        fixture = root / "benchmark/core-integration/fixture"
        args = [sys.executable, "-B", "code/offline_run.py", "--source", str(fixture / "src"), "--skeleton", str(fixture / "skeleton.json"),
                "--context", str(fixture / "context.json"), "--scenarios", str(fixture / "scenario.json"), "--output", str(root / "new.json"), "--report", str(root / "report.json")]
        result = subprocess.run(args, cwd=root, env=env, capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
        assert json.loads((root / "new.json").read_text()) == json.loads((root / "benchmark/core-integration/cold.json").read_text())
        report = {"passed": True, "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "code_hashes_match_freeze": True,
                  "tests_stdout": tests.stdout, "test_returncode": tests.returncode, "standalone_CLI_returncode": result.returncode,
                  "standalone_graph_matches_saved": True, "application_executed": False}
        (VARIANT / "benchmark/archive-verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps({key: report[key] for key in ["passed", "archive_sha256", "standalone_graph_matches_saved"]}))
        print(tests.stdout)


if __name__ == "__main__":
    main()
