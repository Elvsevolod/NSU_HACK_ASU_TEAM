"""Copy-on-write table snapshots; immutable input rows are shared across paths."""
from copy import deepcopy
import gzip
import json
import re

from .values import Object, Symbol, Unknown


class Store:
    def __init__(self, base=None, changes=None, tainted=None):
        self.base = base if base is not None else {}
        self.changes = changes if changes is not None else {}
        self.tainted = tainted if tainted is not None else set()

    def __deepcopy__(self, memo):
        result = Store(self.base, deepcopy(self.changes, memo), self.tainted.copy())
        memo[id(self)] = result
        return result

    def read(self, table):
        if table in self.tainted:
            return Unknown("table may have been modified by unsupported code", origin=table)
        if table not in self.changes and table not in self.base:
            return Unknown("initial table contents were not supplied", origin=table)
        return list(deepcopy(self.changes.get(table, self.base.get(table, ()))))

    def replace(self, table, rows):
        self.changes[table] = deepcopy(rows)
        self.tainted.discard(table)

    def havoc(self):
        self.tainted.update(set(self.base) | set(self.changes))

    def snapshot(self):
        return {k: self.read(k) for k in sorted(set(self.base) | set(self.changes))}


class State:
    def __init__(self, store=None):
        self.store = store if store is not None else Store()
        self.globals = {}
        self.objects = {}
        self.sequence = 0
        self.pending = {}
        self.sessions = set()

    def new(self, typ, fields=None):
        self.sequence += 1
        obj = Object(f"o{self.sequence}", typ, fields if fields is not None else {})
        self.objects[obj.identity] = obj
        return obj

    def symbol(self, typ):
        self.sequence += 1
        return Symbol(f"fresh:{self.sequence}", typ)

    def havoc(self):
        self.store.havoc()
        self.pending.clear()
        for obj in self.objects.values():
            obj.fields = {k: Unknown("unknown call may modify reachable object", origin=obj.identity) for k in obj.fields}


def sql_statements(source):
    """Split MySQL dump statements without splitting semicolons inside strings."""
    result, start, quote, i = [], 0, "", 0
    while i < len(source):
        char = source[i]
        if quote:
            if char == "\\":
                i += 2
                continue
            if char == quote:
                if i + 1 < len(source) and source[i + 1] == quote:
                    i += 2
                    continue
                quote = ""
        elif char in "'\"`":
            quote = char
        elif char == ";":
            result.append(source[start:i].strip())
            start = i + 1
        i += 1
    if source[start:].strip():
        result.append(source[start:].strip())
    return result


def sql_values(source):
    values, token, quote, quoted, i = [], "", "", False, 0
    while i < len(source):
        char = source[i]
        if quote:
            if char == "\\" and i + 1 < len(source):
                i += 1
                token += {"n": "\n", "r": "\r", "t": "\t", "0": "\0"}.get(source[i], source[i])
            elif char == quote:
                if i + 1 < len(source) and source[i + 1] == quote:
                    token += quote
                    i += 1
                else:
                    quote = ""
            else:
                token += char
        elif char in "'\"":
            quote, quoted = char, True
        elif char in ",)":
            raw = token.strip() if not quoted else token
            if quoted:
                value = Unknown("SQL text contains undecodable bytes") if "\ufffd" in raw else raw
            elif raw.upper() == "NULL":
                value = None
            else:
                try:
                    value = json.loads(raw)
                except ValueError:
                    value = Unknown("unsupported SQL literal", origin=raw[:120])
            values.append(value)
            token, quoted = "", False
            if char == ")":
                yield values
                values = []
                while i + 1 < len(source) and source[i + 1] in " ,\n\r\t(":
                    i += 1
        elif char != "(" or token:
            token += char
        i += 1


def load_context(path, facts):
    if path is None:
        return Store(), {}, ["No initial data context supplied"]
    if path.is_dir():
        candidates = sorted(p for p in path.iterdir() if p.suffix in {".sql", ".gz", ".json"})
        if len(candidates) != 1:
            raise ValueError("Select one context file explicitly when a directory is ambiguous")
        path = candidates[0]
    raw = path.read_bytes()
    if path.suffix == ".gz":
        raw = gzip.decompress(raw)
    if path.name.endswith(".json"):
        context = json.loads(raw)
        tables = context.get("tables", {})
        base = {}
        for name, rows in tables.items():
            rid = facts.table_id(name)
            if not rid:
                raise ValueError("Context table not mapped uniquely to skeleton: " + name)
            base[rid] = tuple(deepcopy(rows))
        return Store(base), context, []
    decoded = raw.decode("utf-8", errors="replace")
    source = re.sub(r"(?m)^\s*(?:--|#).*\n?", "", decoded)
    source = re.sub(r"/\*.*?\*/", "", source, flags=re.S)
    base, schemas, warnings, database = {}, {}, [], ""
    if "\ufffd" in decoded:
        warnings.append("Context contains non-UTF8 bytes; affected SQL values remain unknown")
    for statement in sql_statements(source):
        use = re.match(r"USE\s+`?([\w-]+)`?", statement, re.I)
        if use:
            database = use[1]
            continue
        create = re.match(r"CREATE TABLE(?: IF NOT EXISTS)?\s+`?([\w-]+)`?\s*\((.*)\)\s*(?:ENGINE|$)", statement, re.I | re.S)
        if create:
            columns = re.findall(r"(?:^|\n|,)\s*`([^`]+)`\s+\w+", create[2])
            schemas[(database, create[1])] = columns
            rid = facts.table_id(create[1], database)
            if rid:
                base.setdefault(rid, [])
            continue
        insert = re.match(r"INSERT INTO\s+(?:`?([\w-]+)`?\.)?`?([\w-]+)`?\s*(\([^)]*\))?\s*VALUES\s*(.*)", statement, re.I | re.S)
        if insert:
            schema, table = insert[1] or database, insert[2]
            rid = facts.table_id(table, schema)
            if not rid:
                warnings.append(f"Unmapped context table: {schema}.{table}")
                continue
            columns = [s.strip().strip('`"') for s in insert[3][1:-1].split(",")] if insert[3] else schemas.get((schema, table))
            if not columns:
                warnings.append("Missing SQL column schema: " + rid)
                continue
            for values in sql_values(insert[4]):
                if len(columns) != len(values):
                    warnings.append("SQL column/value count mismatch: " + rid)
                    continue
                base.setdefault(rid, []).append(dict(zip(columns, values)))
        elif statement and not re.match(r"(?:SET|LOCK|UNLOCK|DROP|CREATE DATABASE|ALTER|DELIMITER)\b", statement, re.I):
            warnings.append("Unsupported context SQL statement: " + statement[:100])
    return Store({k: tuple(v) for k, v in base.items()}), {}, warnings
