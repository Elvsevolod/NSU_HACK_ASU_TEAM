# Срез требований исследования

Исходные 18 случаев были спецификацией, не готовыми тестами. «Проверено» ниже означает ограниченный случай; это не доказательство всей семантики языка/фреймворка. Тесты находятся в `code/tests/`.

| Требование | Состояние | Свидетельство / граница |
| --- | --- | --- |
| C01: Java/Python integers | Проверен срез | int/long overflow, division/remainder, SMT, переход через HTTP |
| C02: exception type/finally | Проверен срез | Catch по типу, finally, вложенный active exception |
| C03: return в switch | Проверено | Return сохраняется общим kernel |
| C04: null receiver | Проверено | Хвост после null-вызова не исполняется |
| C05: HTTP verb | Проверено | GET и POST по одному пути различаются |
| C06: HTTP error policy | Частично | RestTemplate/requests/httpx проверены на 404; JavaScript fetch не поддержан |
| C07: независимые состояния | Проверено | Изменения доступны внутри цепочки и не переходят в другой сценарий |
| C08: id разных сущностей | Частично | Типы/таблицы не объединяются по id; автоматическое связывание истории слабое |
| C09: MySQL columns/escaping | Проверено | Named columns, quotes, comments, semicolons, versioned comments |
| C10: rollback и факт обращения | Проверен срез | Совершённый flush сохраняет data, rollback убирает запись; add без flush не даёт data |
| C11: JSON Number JavaScript | Не реализовано | JS/TS и IEEE754 rounding не моделируются |
| C12: profiles/middleware | Частично | Profiles выбираются; точный filter/security lifecycle неизвестен |
| C13: unknown mutation | Проверен срез | Havoc объектов, таблиц, оверлеев; normal/throw остаются альтернативами |
| C14: бюджет | Проверено | Необследованный хвост не доказывает отсутствие эффектов, must пуст |
| C15: cold/warm cache | Проверено | Тот же граф, 6 IR hits, новое состояние; полной инкрементальности нет |
| C16: units | Частично | 5 kg не становится 5 grams; неизвестная конверсия остаётся unknown |
| C17: неоднозначный запрос | Проверен срез | Близкие кандидаты остаются гипотезами; scorer не калиброван |
| C18: фоновые изменения | Не реализовано | Нет очередей, scheduler, background tasks и внешних конкурентных эффектов |

Дополнительно проверены LibCST aliases/shadowing/syntax, Z3 UNSAT/unknown и абляция, SQLGlot JOIN/GROUP/ORDER/COUNT/NULL, JDBC/native @Query/SQLAlchemy, Session binding/delayed write origin/flush/read/rollback и static Java fields. Результаты — `benchmark/tests.xml`, абляция — `benchmark/oss-components.json`.
