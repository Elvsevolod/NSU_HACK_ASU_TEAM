"""Deterministic contract retrieval and input provenance, separate from execution."""
from collections import Counter
import math
import re

from .values import Unknown


STOP = set("the a an of to with from for on in by and their this that my our list show open please get request endpoint api using".split())
VERBS = {"read": "GET", "view": "GET", "show": "GET", "get": "GET", "list": "GET", "find": "GET", "retrieve": "GET",
         "create": "POST", "add": "POST", "register": "POST", "post": "POST",
         "update": "PUT", "edit": "PUT", "change": "PUT", "put": "PUT", "delete": "DELETE", "remove": "DELETE",
         "получить": "GET", "показать": "GET", "создать": "POST", "добавить": "POST", "изменить": "PUT", "удалить": "DELETE"}


def tokens(text):
    text = re.sub(r"([a-zа-я])([A-ZА-Я])", r"\1 \2", text)
    return [word.rstrip("s") for word in re.findall(r"[^\W_]+", text.lower()) if word not in STOP]


def reference(value, history):
    if isinstance(value, dict) and set(value) == {"$ref"}:
        path = str(value["$ref"]).split(".")
        current = history
        for part in path:
            if isinstance(current, dict) and part in current:
                current = current[part]
            elif isinstance(current, (list, tuple)) and part.isdigit() and int(part) < len(current):
                current = current[int(part)]
            else:
                return Unknown("history reference is unavailable", origin=value["$ref"])
        return current
    if isinstance(value, dict):
        return {k: reference(v, history) for k, v in value.items()}
    if isinstance(value, list):
        return [reference(v, history) for v in value]
    return value


class Grounder:
    def __init__(self, project):
        self.p = project
        self.documents = []
        for endpoint in project.endpoints:
            method = project.methods[endpoint.method]
            owner = project.types.get(method.owner)
            fields = []
            for param in method.params:
                fields.extend([param.name, param.typ, param.alias])
                resolved = project.resolve_type(param.typ, method.module, method.span.file)
                fields.extend(project.type_fields(resolved))
            self.documents.append(Counter(tokens(" ".join([method.name, owner.name if owner else "", endpoint.path, method.doc, *fields]))))
        counts = Counter(token for document in self.documents for token in document)
        self.idf = {token: math.log(1 + len(self.documents) / count) for token, count in counts.items()}

    def candidates(self, action):
        query = tokens(action)
        verbs = [VERBS[word] for word in re.findall(r"\w+", action.lower()) if word in VERBS]
        ranked = []
        for index, (endpoint, document) in enumerate(zip(self.p.endpoints, self.documents)):
            score = sum(self.idf.get(token, 0) * min(document.get(token, 0), 2) for token in query)
            if verbs:
                score += 2 if endpoint.verb in {verbs[0], "*"} else -2
            if score > 0:
                ranked.append((score, index))
        ranked.sort(key=lambda item: (-item[0], item[1]))
        if not ranked:
            return []
        # Keep close alternatives as hypotheses; score is not a calibrated probability.
        return [(i, s) for s, i in ranked if s >= ranked[0][0] - max(0.15, ranked[0][0] * 0.08)]

    @staticmethod
    def extract(action, name, typ):
        pattern = r"\b" + re.escape(name) + r"\s*(?:=|:|is\b)?\s*(?:'([^']*)'|\"([^\"]*)\"|([-+]?\d+(?:\.\d+)?)\b|(true|false)\b)"
        match = re.search(pattern, action, re.I)
        if not match:
            return Unknown("no source-grounded scenario literal", typ, name)
        if match[1] is not None or match[2] is not None:
            return match[1] if match[1] is not None else match[2]
        if match[4]:
            return match[4].lower() == "true"
        unit = re.match(r"\s*(kg|grams?|kilograms?|g|lb|lbs|pounds?|km|cm|mm|ms|seconds?|minutes?|hours?)\b", action[match.end():], re.I)
        if unit:
            return Unknown("numeric literal carries units without a source-derived conversion", typ, name)
        return float(match[3]) if "." in match[3] else int(match[3])

    def bind(self, engine, scenario, step, history):
        if isinstance(step.get("request"), dict):
            request = reference(step["request"], history)
            return request, {"kind": "explicit-request", "input": step["request"]}
        action = step.get("action", "")
        direct = re.search(r"\b(GET|POST|PUT|PATCH|DELETE)\s+((?:https?://[^\s]+)?/[^\s]*)", action, re.I)
        if direct:
            return {"method": direct[1].upper(), "url": direct[2]}, {"kind": "literal-http", "literal": direct[0]}
        combined = action + " " + scenario.get("title", "") + " " + scenario.get("description", "")
        candidates = self.candidates(action)
        if not candidates:
            engine.note("ungrounded-action", "No source contract matches the scenario action", action=action)
            return None, {"kind": "unresolved", "action": action}
        if len(candidates) > 1:
            engine.note("grounding-hypotheses", "Contract retrieval is ambiguous", action=action,
                        candidates=[{"handler": self.p.methods[self.p.endpoints[i].method].skeleton_id, "score": score} for i, score in candidates])
            choice = engine.choose(tuple(range(len(candidates))), "scenario endpoint hypothesis")
        else:
            choice = 0
        index, score = candidates[choice]
        endpoint = self.p.endpoints[index]
        method = self.p.methods[endpoint.method]
        request = {"method": endpoint.verb if endpoint.verb != "*" else "GET", "path": endpoint.path,
                   "module": endpoint.module, "body": {}, "query": {}, "path_params": {}}
        supplied = {**engine.context.get("inputs", {}), **scenario.get("inputs", {}), **step.get("inputs", {})}
        provenance = []
        for param in method.params:
            if param.dependency:
                continue
            alias = param.alias or param.name
            location = param.location or ("path" if "{" + alias + "}" in endpoint.path else "query")
            resolved = self.p.resolve_type(param.typ, method.module, method.span.file)
            if location == "body" or (endpoint.framework == "fastapi" and resolved):
                for field, (typ, default) in self.p.type_fields(resolved).items():
                    value = reference(supplied[field], history) if field in supplied else self.extract(combined, field, typ)
                    if not isinstance(value, Unknown) or default is None:
                        request["body"][field] = value
                    provenance.append({"field": field, "source": "provided-input" if field in supplied else "scenario-literal", "value": value, "entity": resolved})
            else:
                value = reference(supplied.get(alias), history) if alias in supplied else self.extract(combined, alias, param.typ)
                target = "path_params" if location == "path" else "query"
                if not isinstance(value, Unknown) or param.default is None:
                    request[target][alias] = value
                provenance.append({"field": alias, "source": "provided-input" if alias in supplied else "scenario-literal", "value": value})
        return request, {"kind": "lexical-hypothesis", "handler": method.skeleton_id, "score": score, "provenance": provenance}
