# Используемый открытый код

Тяжёлые алгоритмы подключены как библиотеки с закреплёнными версиями. Это исполняемый код upstream-проектов, а не ссылки для справки. Мы не копируем их реализации парсеров, решателей и планировщиков в собственные модули.

| Проект | Версия | Что выполняет в варианте № 13 | Наш адаптер |
| --- | --- | --- | --- |
| [Tree-sitter Python bindings](https://github.com/tree-sitter/py-tree-sitter) | 0.25.2 | Построение синтаксического дерева Java | `code/polygraph/java.py` |
| [Tree-sitter Java grammar](https://github.com/tree-sitter/tree-sitter-java) | 0.23.5 | Грамматика Java | `code/polygraph/java.py` |
| [LibCST](https://github.com/Instagram/LibCST) | 1.9.0 | Разбор Python, `QualifiedNameProvider`, `ScopeProvider`, позиции и преобразование синтаксиса в памяти | `code/polygraph/python_names.py` |
| [SQLGlot](https://github.com/tobymao/sqlglot) | 30.23.0 | SQL-лексер, AST дампов, оптимизатор, планировщик и Python executor для чтения переданных снимков | `code/polygraph/sql.py`, `sql_queries.py` |
| [Z3](https://github.com/Z3Prover/z3) / `z3-solver` | 5.3.1.0 | SMT-проверка осуществимости путей: целые Python, знаковые bit vectors Java, булевы формулы | `code/polygraph/constraints.py` |
| [PyYAML](https://github.com/yaml/pyyaml) | 6.0.3 | Транзитивная зависимость LibCST; самостоятельного извлечения YAML у нас пока нет | Через LibCST |

Tree-sitter, его Java-грамматика, SQLGlot, Z3 и PyYAML используют MIT. У LibCST есть также части под PSF и Apache 2.0: полное уведомление сохранено. Лицензии находятся в [third_party/](third_party/); [provenance.json](third_party/provenance.json) содержит версии, адреса проектов и SHA-256 файлов лицензий. Для первых пяти пакетов, кроме Z3, уведомления скопированы из установленных дистрибутивов. Уведомление Z3 получено из официального репозитория; его источник: [LICENSE.txt](https://github.com/Z3Prover/z3/blob/master/LICENSE.txt).

Прямые зависимости закреплены в [requirements.txt](requirements.txt), всё проверенное окружение — в [requirements.lock.txt](requirements.lock.txt). Изученные upstream-файлы и журналы загрузки сохранены вне runtime, в `experiments/20261017-polyglot-scenario-core/oss-sources/`. Подключённые пакеты не изменяются. Наш код связывает их с входным скелетом, источниками значений, состоянием сценария и схемой результата.

Польза проверяется поведением: [benchmark/oss-components.json](benchmark/oss-components.json) содержит сравнение с отключённым Z3; [code/tests/test_oss_components.py](code/tests/test_oss_components.py) проверяет SQL из JDBC/SQLAlchemy, native `@Query`, NULL, ошибки привязки Session, отложенную запись и синтаксис Python. SQLGlot читает только проверенное подмножество запросов над памятью; соединения с БД и запуск исходного приложения отсутствуют. Z3 исключает ветвь только при UNSAT. LibCST не запускает импорт исследуемого модуля, Pyre или Watchman.

Выбор этих компонентов не означает, что Tree-sitter покрывает семантику JVM, LibCST выполняет Python или Z3 понимает Spring. Семантический IR и ограниченные контракты фреймворков остаются нашим кодом. Joern, CodeQL, Semgrep, Spoon и другие системы из исследования не выдаются за подключённые компоненты.
