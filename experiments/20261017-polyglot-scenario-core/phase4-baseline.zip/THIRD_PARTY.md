# Используемый открытый код

Тяжёлые алгоритмы подключены как библиотеки с закреплёнными версиями. Это исполняемый код upstream-проектов, а не ссылки для справки. Мы не копируем их реализации парсеров, решателей и планировщиков в собственные модули.

| Проект | Версия | Что выполняет в варианте № 13 | Наш адаптер |
| --- | --- | --- | --- |
| [Tree-sitter Python bindings](https://github.com/tree-sitter/py-tree-sitter) | 0.25.2 | Построение синтаксического дерева Java | `code/polygraph/java.py` |
| [Tree-sitter Java grammar](https://github.com/tree-sitter/tree-sitter-java) | 0.23.5 | Грамматика Java | `code/polygraph/java.py` |
| [Tree-sitter JavaScript grammar](https://github.com/tree-sitter/tree-sitter-javascript) | 0.25.0 | CST запросов, выражений и условий JavaScript | `code/polygraph/ui_extract/` |
| [QuickJS-NG](https://github.com/quickjs-ng/quickjs), [Python wrapper](https://github.com/genotrance/quickjs-ng) | wrapper 0.17.0.1 | Числа IEEE754, coercion/equality, UTF-16, parseInt/parseFloat и JSON для конкретных значений | `code/polygraph/ui_extract/native.py` |
| [html5lib](https://github.com/html5lib/html5lib-python) | 1.1 | HTML5-дерево, option/text и фрагменты таблиц | `code/polygraph/ui_extract/html_rows.py`, `html_options.py` |
| [LibCST](https://github.com/Instagram/LibCST) | 1.9.0 | Разбор Python, `QualifiedNameProvider`, `ScopeProvider`, позиции и преобразование синтаксиса в памяти | `code/polygraph/python_names.py` |
| [SQLGlot](https://github.com/tobymao/sqlglot) | 30.23.0 | SQL-лексер, AST дампов, оптимизатор, планировщик и Python executor для чтения переданных снимков | `code/polygraph/sql.py`, `sql_queries.py` |
| [Z3](https://github.com/Z3Prover/z3) / `z3-solver` | 5.3.1.0 | SMT-проверка осуществимости путей: целые Python, знаковые bit vectors Java, булевы формулы | `code/polygraph/constraints.py` |
| [PyYAML](https://github.com/yaml/pyyaml) | 6.0.3 | Транзитивная зависимость LibCST; самостоятельного извлечения YAML у нас пока нет | Через LibCST |
| [Rank-BM25](https://github.com/dorianbrown/rank_bm25) | 0.2.2 | Построение индексов и расчёт `BM25Plus(delta=0)` по контрактам и отдельным телам методов | `code/polygraph/grounding.py` |
| [NumPy](https://github.com/numpy/numpy) | 2.2.6 | Массивы и векторные вычисления Rank-BM25 | Через Rank-BM25 |

Tree-sitter, его Java-грамматика, SQLGlot, Z3 и PyYAML используют MIT. У LibCST есть также части под PSF и Apache 2.0: полное уведомление сохранено. Лицензии находятся в [third_party/](third_party/); [provenance.json](third_party/provenance.json) содержит версии, адреса проектов и SHA-256 файлов лицензий. Для первых пяти пакетов, кроме Z3, уведомления скопированы из установленных дистрибутивов. Уведомление Z3 получено из официального репозитория; его источник: [LICENSE.txt](https://github.com/Z3Prover/z3/blob/master/LICENSE.txt).

Прямые зависимости закреплены в [requirements.txt](requirements.txt), всё проверенное окружение — в [requirements.lock.txt](requirements.lock.txt). Изученные upstream-файлы и журналы загрузки сохранены вне runtime, в `experiments/20261017-polyglot-scenario-core/oss-sources/`. Подключённые пакеты не изменяются. Наш код связывает их с входным скелетом, источниками значений, состоянием сценария и схемой результата.

Rank-BM25 — Apache 2.0, NumPy — BSD с уведомлениями зависимостей бинарной сборки; все четыре файла лицензий установленного NumPy объединены в сохранённое уведомление с исходными путями. В релизе Rank-BM25 0.2.2 BM25L дополнительно умножает вклад на term frequency; в проверенном GitHub master этого множителя нет. Вместо изменения upstream выбран имеющийся `BM25Plus(delta=0)`: насыщение TF, положительный IDF и нулевой вклад отсутствующего слова. На фиксированных публичных запросах top-1 изменился с 9/10 до 10/10, точный набор — с 8/10 до 9/10. Корпус небольшой и не слепой; это не калибровка достоверности. Полные лицензии — в `third_party/`, сравнение — `benchmark/retrieval-formulas.json`.

Чистое выделение контекстных span перенесено из собственного варианта № 14; исходные пути, имена функций и хеш сохранены в [reused-components.json](development/reused-components.json). Импорта его движка нет. Небольшие контракты Spring остаются нашим кодом: [model-contracts.json](development/model-contracts.json) указывает проверенные upstream-теги и git blob. Spring не подключён как исполняемая библиотека анализатора.

Польза проверяется поведением: [benchmark/oss-components.json](benchmark/oss-components.json) содержит сравнение с отключённым Z3; [code/tests/test_oss_components.py](code/tests/test_oss_components.py) проверяет SQL из JDBC/SQLAlchemy, native `@Query`, NULL, ошибки привязки Session, отложенную запись и синтаксис Python. SQLGlot читает только проверенное подмножество запросов над памятью; соединения с БД и запуск исходного приложения отсутствуют. Z3 исключает ветвь только при UNSAT. LibCST не запускает импорт исследуемого модуля, Pyre или Watchman.

Выбор этих компонентов не означает, что Tree-sitter покрывает семантику JVM, LibCST выполняет Python или Z3 понимает Spring. Семантический IR и ограниченные контракты фреймворков остаются нашим кодом. Joern, CodeQL, Semgrep, Spoon и другие системы из исследования не выдаются за подключённые компоненты.

QuickJS-NG исполняет наши фиксированные чистые операции и только подтверждённые CST примитивные литералы. Исследуемые скрипты, callback-функции, модули и приложения не запускаются. Host callbacks не зарегистрированы; контекст ограничен 8 MiB памяти, 256 KiB стека и 20 ms на операцию. Символьные значения не передаются в движок под выдуманными строками. Они сохраняются отдельными тегами; JSON-текст с таким значением остаётся абстрактным и может быть прочитан следующим шагом с тем же ID.

Установленная обёртка QuickJS-NG — небольшой отдельный проект, не сама большая кодовая база движка. Проверен её релиз `v0.17.0.1`: git submodule движка — `6d2a9bacbc9feb5c1f46f80b3cf4c25bedd2187b`. Лицензия MIT движка сохранена отдельно от MIT обёртки. JavaScript-грамматика, html5lib и six — MIT; webencodings содержит собственное BSD-уведомление. Версии транзитивных six/webencodings и все уведомления закреплены в lock/provenance.

Исходный UI-экстрактор перенесён самостоятельным снимком из собственного № 14: [ui-source-provenance.json](development/ui-source-provenance.json) хранит исходные и текущие хеши, исключённые методы и изменения. Импортов его backend-движка нет. Сохранены 60 прежних чистых тестов; они не считаются независимым авторством новых эталонов. Новые проверки границ и сквозной CLI описаны в [UI.md](UI.md). Правила сериализации jQuery, ограниченного `$http` AngularJS, FastAPI Form и Spring RequestParam сверены с [источниками контрактов](development/model-contracts.json); эти фреймворки не запускаются внутри анализатора.
