# Решение № 13 — polyglot-scenario-core

Первый проверенный срез общего ядра Java/Spring и Python/FastAPI. Архитектурный предшественник — № 11; код предыдущих вариантов не импортируется. Tree-sitter, LibCST, SQLGlot и Z3 выполняют разбор, разрешение Python-имён, SQL-планы и проверку ограничений. Наш код связывает их с IR, состоянием сценария, контрактами технологий и ID входного графа.

**Требуемое качество универсального анализатора пока не достигнуто.** Локальный S0 — **0,2964** против **0,9510** у № 11. Связывание текста с запросами существенно слабее, подготовка UI и полный Spring lifecycle ещё не перенесены. Все восемь сценариев остаются `partial`. Это реализация архитектурной основы с измеренными границами.

| Показатель | Значение |
| --- | --- |
| Score сайта | — (не получен) |
| Тестовый score S0 | 0,29642857142857143 |
| S0: executes / calls / remote / data, IoU | 0,1 / 0,08571428571428572 / 1 / 0 |
| Формат S0–S7 | Проверен официальным валидатором; S6 пуст |
| Время построения ответа | 11,544 с внутри CLI; 11,748 с весь процесс, локально |
| Подготовка / анализ | 0,887 / 10,657 с |
| Пиковый RSS | 233062400 байт |
| Окружение | Python 3.11.9, macOS/Apple Silicon; версии пакетов закреплены |
| Обращения к моделям при анализе | 0, внешних LLM API нет |
| Проверки | 102 теста; 7 проверок тел на 2 публичных проектах; смешанная интеграция |

`remote=1` у S0 означает два пустых множества. В S0 найдено 5 правильных executes из 34, 3 calls из 24 и ни одного data из 7; лишние рёбра также учтены в IoU. Скрытые S1–S7 не оценены. Время не выдаётся за ускорение относительно № 11: понижены только 23 тела из 3032 найденных методов, покрытие сильно меньше.

SHA-256 ответа: `bb47df200d7319d77526e5b99c78c31c1d40f301336020fc8fcee13a3e8a0ee3`. Повтор всех сценариев с `PYTHONHASHSEED=17` дал тот же файл. Полные значения и команды — [summary.json](benchmark/summary.json), [analysis-report.json](benchmark/analysis-report.json), [comparison.json](benchmark/comparison.json).

## Открытые компоненты

| Проект | Что реально используется |
| --- | --- |
| Tree-sitter / tree-sitter-java | Деревья Java, извлечение деклараций и тел |
| LibCST | CST, QualifiedNameProvider, ScopeProvider, import aliases и нормализация exception tuples Python 3.14 в памяти |
| SQLGlot | SQL AST контекста, upstream optimizer/planner/executor для ограниченных SELECT-планов над переданными снимками |
| Z3 | UNSAT-отсечение путей; Int для Python, BitVec для Java; сохранение альтернатив при unknown/таймауте |

Версии, лицензии и места подключения — [THIRD_PARTY.md](THIRD_PARTY.md). Upstream-пакеты не изменены. Joern, CodeQL, Semgrep и Spoon не выдаются за подключённые движки.

Сравнение с `--no-smt` на одинаковых исходниках Java и Python воспроизводит лишний вызов из ветви `n>10` и одновременно `n<5`; Z3 исключает его. Проверены overflow, division/remainder, нулевой делитель и числовая семантика после HTTP. [Сохранённая абляция](benchmark/oss-components.json). На полном Train Ticket решатель пока не получил формул — улучшение S0 за счёт SMT не заявляется.

SQLGlot используется JDBC, literal native `@Query` и SQLAlchemy `text/execute`. Один JOIN/GROUP/ORDER/COUNT-запрос из Java и Python даёт одинаковый проверенный результат. Подключения к базе нет. JPQL, неподдержанный AST, неизвестные SQL-параметры и типы значений диагностируются. Неизвестная мутация контекста не превращается в пустую таблицу.

## Запуск

Из каталога варианта; зависимости устанавливаются до анализа:

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock.txt
NSU_CASE_ROOT=../../tt-challenge
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B code/offline_run.py \
  --source "$NSU_CASE_ROOT/targets/trainticket" \
  --skeleton "$NSU_CASE_ROOT/skeleton/trainticket.json.gz" \
  --context "$NSU_CASE_ROOT/context/db-after-warmup.sql.gz" \
  --scenarios "$NSU_CASE_ROOT/scenarios" \
  --output submission.json --report benchmark/analysis-report.json
```

Для другого проекта меняются четыре входных пути. Готовый граф-скелет обязателен. JSON-контекст принимает `tables`, `table_schemas`, `inputs`, `services`, `principal`, `globals`, явные `assumptions`; неоднозначные таблицы отвергаются. SQL-контекст — `.sql`/`.sql.gz`, диалект задаётся `--sql-dialect` (mysql по умолчанию). Для невычислимых значений времени определения Python можно передать `globals`: ключ модуля, например `main.VALUE`, или `main.read:default:value`. Вызовы их инициализации не считаются выполнением сценария; без значения остаётся unknown. Полный текстовый контекст организаторов пока не извлекается в структурированные факты.

Параметры: `--cache PATH`, `--profile NAME`, `--policy may|must`, `--path-limit 16`, `--loop-limit 32`, `--depth-limit 32`, `--step-limit 30000`, `--smt-timeout-ms 50`, `--no-smt`. Ключ IR-кеша включает исходники, скелет, конфигурацию, profiles, код и версии библиотек. Состояние и ответ вычисляются заново; подготовка пока повторяется даже при тёплом кеше.

Явный HTTP-`request` в шаге позволяет отдельно проверить выполнение. Ссылка `{"$ref":"steps.1.body.id"}` в `request`/`inputs` переносит результат предыдущего шага. Это дополнительный контракт; текстовые сценарии принимаются, их текущая точность отражена в S0. ID сценария влияет только на `scenario:<id>`.

## Проверки

```bash
PYTHONPATH=code PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B -m pytest code/tests -q -p no:cacheprovider
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B development/benchmark_core.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B development/benchmark_oss.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B development/run_benchmark.py --case-root "$NSU_CASE_ROOT"
```

- [102 теста](benchmark/tests.xml): управление, исключения, области видимости, алиасы, HTTP/Depends, SQL/Session, неизвестные эффекты, бюджеты, состояние, кеш и OSS. Проверяются значения и рёбра, не только формат.
- [Смешанная интеграция](benchmark/core-integration/verification.json): Java → Python, создание → чтение по символическому UUID; ровно 6 executes, 1 calls, 2 remote, 2 data. Все четыре множества непусты, граф совпал с ручным эталоном. Пример синтетический.
- Холодный/тёплый результаты совпали, повтор дал 6 IR hits и 0 новых понижений. Переменованы все ID скелета и сценария — нормализованный граф сохранился. Значимое ускорение кешем не установлено.
- [PiggyMetrics](https://github.com/sqshq/piggymetrics), commit `6bb2cf9ddbca980b664d3edbb6ff775d75369278`: 72 производственных Java-файла под хешами; 2 проверки — чтение аккаунта через контроллер/сервис/репозиторий и отказ при пустом имени.
- [FastAPI Template](https://github.com/fastapi/full-stack-fastapi-template), commit `b1125d8839482cb7bbae603ddc6d0081bf87532e`: 25 производственных Python-файлов под хешами; 5 проверок — владелец, чужой объект, отсутствие, частичное обновление → чтение, удаление → отсутствие. Новый exception-синтаксис разобран, parse errors этих файлов — 0.

Все 7 публичных проверок прошли: [результаты](benchmark/public-corpus/corpus-results.json), [эталоны](development/corpus_reference.json), [воспроизведение](development/check_corpus.py). Команда: `python -B development/check_corpus.py --java ROOT --python BACKEND --output DIR`. Нужны исходники по указанным commit; в рабочем репозитории они сохранены в `experiments/20261017-polyglot-scenario-core/`.

Публичные пробы ограничены телами методов с предоставленными Session/User и состоянием. Они не доказывают полный HTTP/security/validation-граф приложений. Эталоны составлены Codex до первого сравнения; отдельного независимого автора нет. Пустые remote-множества этих проб не выдаются за межсервисное качество. Приложения и сервисы не запускались.

## Границы и статус цели

Устройство — [ARCHITECTURE.md](ARCHITECTURE.md), требования — [SUPPORT_MATRIX.md](SUPPORT_MATRIX.md). Выполнение ограничено поддержанными конструкциями. `must` пуст при необследованных путях; `may` — объединение обнаруженных эффектов, не доказанная полная верхняя оценка произвольной программы.

Для качества продукта необходимы UI/контекстное связывание, источники параметров из истории, фазы Spring/FastAPI и расширение моделей. Не реализованы полный JVM/Python, reflection, Streams/lambdas, ORM relationships/cascades/identity map/dirty tracking, произвольный SQL, фоновые задачи, summaries с footprint, fixpoint/widening и точная инкрементальная инвалидация. Третий язык потребует адаптера и проверки. Поддержка любого языка и аппаратная переносимость вне проверенного macOS/ARM не заявляются. Общая цель качественного универсального анализатора остаётся открытой.

DeepSeek консультировал архитектуру в режиме только чтения. Попытка отдельной проверки эталонов завершилась HTTP 403 FreeTierError; выполненным независимым ревью она не считается. Дополнительное OSS-ревью прочитало файлы, затем остановилось без итогового ответа; оно тоже не засчитано как пройденное. DeepSeek не изменял файлы. Принятые изменения и проверки просмотрены Codex. [Аудит](development/deepseek-audit.json), [замечания](development/deepseek-review.txt).

В [solution.zip](solution.zip) находятся `submission.json` в корне, код, зависимости, лицензии и инструкции. На сайт не отправлялся. Старые варианты, исходный пакет, sample и прежние runs этой работой не редактировались; изменения параллельного чата сохранены.
