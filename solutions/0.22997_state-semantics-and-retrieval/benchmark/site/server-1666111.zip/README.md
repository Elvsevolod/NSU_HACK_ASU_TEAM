Solution 32. Python source-only Java/Spring scenario analyzer.
Install requirements.txt in an isolated Python 3.11 environment.
Run: python -B code/offline_run.py --source SOURCE --skeleton SKELETON --context CONTEXT --scenarios SCENARIOS --output answer.json --report report.json
All six paths are supplied by the caller. path-limit defaults to 4. Target JVM/services are never launched. No external LLM API or model weights are required.
The default uses accepted bounded static/List/Stream/Set/ordering semantics and baseline retrieval. Lexical/dense retrieval remain optional rejected development experiments. This is not complete Java/JVM/SQL support; unsupported cases are diagnosed and may stop a path.
Local S0 is separate from hidden/site quality. See the analytical package for experiments, independent fixtures and limitations. The ready skeleton is required; no graph is built from scratch.
