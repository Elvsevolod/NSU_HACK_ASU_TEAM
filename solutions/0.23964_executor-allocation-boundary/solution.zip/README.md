# Решение №35 — executor-allocation-boundary

Родитель — проверенный E28 решения №33. C02 проверяет источник неизвестных эффектов при создании неиспользуемого пула потоков перед поиском. Поддержка ограничена созданием объекта: выполнение задач не моделируется.

| Показатель | Значение |
| --- | --- |
| Score сайта | — (не получен) |
| Тестовый score S0 | 0.8008928571428572 |
| S0: executes / calls / remote / data | 0.8285714285714286 / 0.625 / 1.0 / 0.75 |
| Формат S0–S7 | Ошибок и предупреждений нет |
| Время построения ответа | 50.618039291999594 с, локально, Python3.11.9 |

Python3.11.9; зависимости requirements.txt. Запуск: `python -B code/offline_run.py --source ../../tt-challenge/targets/trainticket --skeleton ../../tt-challenge/skeleton/trainticket.json.gz --context ../../tt-challenge/context --scenarios ../../tt-challenge/scenarios --output submission.json --report benchmark/report.json`.
Path limit4, completion budget8; те же входы и default baseline. Без моделей, запуска сервисов и сценарных исключений. Сайт и S0 оцениваются раздельно. №32 и лучший пакет №5 сохраняются.

Измеренная дельта: +28/−0 рёбер. Точный состав и source witnesses: benchmark/edge-delta.json и edge-witnesses.json. Остановка анализа не означает выполнение оставшейся операции. Оценка сайта ожидается.
