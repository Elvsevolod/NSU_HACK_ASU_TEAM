# Решение №34 — short-circuit-reference-guards

Родитель — проверенный E28 решения №33. Эксперимент C01: лишнее исполнение правой части неизвестного Java &&/|| и потеря доказанного null/non-null guard для локального String. Цель — исправить source semantics и измерить изменения конечных рёбер, прежде чем решать об отправке. Эталон и исходные входы не меняются.

| Показатель | Значение |
| --- | --- |
| Score сайта | — (не получен) |
| Тестовый score S0 | 0.8008928571428572 |
| S0: executes / calls / remote / data | 0.8285714285714286 / 0.625 / 1.0 / 0.75 |
| Формат S0–S7 | Ошибок и предупреждений нет |
| Время построения ответа | 52.812878083001124 с; Python3.11.9, локально |

Запуск: Python3.11.9, зависимости requirements.txt; `python -B code/offline_run.py --source ../../tt-challenge/targets/trainticket --skeleton ../../tt-challenge/skeleton/trainticket.json.gz --context ../../tt-challenge/context --scenarios ../../tt-challenge/scenarios --output submission.json --report benchmark/report.json`. Прежние path_limit=4/completion_budget=8 сохраняются.

Baseline№32 и лучший пакет№5 доступны только для чтения. Никаких business/scenario IDs в исполнителе, моделей, target JVM, push и платных ресурсов. Новый сайт-пакет возможен только после реального изменения JSON и проверок.

Измеренный ответ: +6/−58 рёбер, толькоS5/S6; budget alternatives302→321. Это эксперимент с риском потери полезных продолжений, не объявленное улучшение качества. S0 и сайт — отдельные показатели. Независимые source controls before/after,2453 локальных теста и8-шаговая PiggyMetrics цепочка пройдены. Полный raw trace и причины сохранены отдельно; source/report hashes есть в metadata.
