# Решение № 30 — collection-value-flow

Родитель № 29. Ограниченные HashSet/Map proof, source Angular callback, actor-owned credentials/state, formatter/effects и строгие проверки. Подробности и оставшиеся границы: [IMPLEMENTATION_REVIEW.md](IMPLEMENTATION_REVIEW.md), [карта требований](development/requirements.json).

| Показатель | Значение |
| --- | --- |
| Score сайта | — (не получен) |
| Тестовый score S0 | 0.8008928571 |
| S0: executes / calls / remote / data | 0.828571 / 0.625000 / 1.000000 / 0.750000 (remote gold пуст) |
| Формат S0–S7 | Корректен |
| Время построения ответа | 85.148 с локально, Python 3.11.9; расчёт отдельно 67.300 с |

1762 теста. Строгие Piggy 8+3 и отрицательные контроли пройдены; Petclinic сохраняет ID/поля/число строк. Новый независимый cart profile не пройден: Stream.toList. TT поиск остаётся частичным на следующем Map-цикле; полного сценария бронирования и универсальности не заявлено. DeepSeek, модели и внешние LLM API не использовались. Исследуемые приложения не запускались.

Из этой папки:

```sh
python -m pip install -r requirements.txt
python -B code/offline_run.py --source ../../tt-challenge/targets/trainticket --skeleton ../../tt-challenge/skeleton/trainticket.json.gz --context ../../tt-challenge/context --scenarios ../../tt-challenge/scenarios --output /tmp/answer30.json --report /tmp/report30.json
```

SHA-256 submission.json: `1a5f48620fb8e840f17903b78bfff037cf88191f888a452dc609f6970789731a`. Сайт и S0 — разные оценки. Посылка solution.zip сохраняется неизменной после отправки; новые метаданные сайта находятся рядом в benchmark.
