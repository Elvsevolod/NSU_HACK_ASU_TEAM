"""Static extraction and symbolic evaluation of browser request contracts."""
from copy import deepcopy
from html.parser import HTMLParser
from pathlib import Path
import json
import re
from urllib.parse import urlsplit, parse_qsl
from tree_sitter import Language, Parser
import tree_sitter_javascript
from baseline_nlp import front_files
from .project import text, walk
from .state import U


def pairs(node):
    return {text(c.child_by_field_name('key')).strip('\"\''): c.child_by_field_name('value')
            for c in node.named_children if c.type == 'pair'} if node and node.type == 'object' else {}


def literal(node):
    if node is None:
        return U
    raw = text(node)
    if node.type == 'string':
        try:
            return json.loads(raw) if raw.startswith('"') else raw[1:-1]
        except ValueError:
            return U
    try:
        return json.loads(raw)
    except ValueError:
        return U


def ancestor(node, kinds):
    while node and node.type not in kinds:
        node = node.parent
    return node


def unwrapped(node):
    while node is not None and node.type in ('expression_statement', 'parenthesized_expression'):
        node = node.named_children[0] if node.named_children else None
    return node


FUNCTIONS = ('function_expression', 'function_declaration', 'method_definition', 'arrow_function')


def substitute(expression, bindings):
    """Substitute reference identifiers, preserving string literals and property names."""
    parser = Parser(Language(tree_sitter_javascript.language()))
    source = ('(' + expression + ');').encode()
    tree = parser.parse(source)
    changes = []
    for node in walk(tree.root_node):
        if node.type == 'identifier' and text(node) in bindings:
            changes.append((node.start_byte, node.end_byte, '(' + bindings[text(node)] + ')'))
    for start, end, value in reversed(changes):
        source = source[:start] + value.encode() + source[end:]
    return source.decode()[1:-2]


UNSTABLE = ('if_statement', 'conditional_expression', 'switch_statement', 'for_statement', 'for_in_statement',
            'while_statement', 'do_statement', 'try_statement', 'catch_clause')


def callee_parts(node):
    if node is None:
        return None, None
    if node.type == 'identifier':
        return None, text(node)
    if node.type == 'member_expression':
        obj, prop = node.child_by_field_name('object'), node.child_by_field_name('property')
        if obj is not None and prop is not None and prop.type == 'property_identifier':
            return text(obj), text(prop)
    return None, None


def wrapper_identity(scope):
    """Name and owning object literal of the wrapper defined at this scope."""
    if scope is None or scope.type == 'program':
        return None, None
    name = text(scope.child_by_field_name('name'))
    if scope.type == 'method_definition':
        return name or None, ancestor(scope.parent, ('object',))
    parent = scope.parent
    key = parent.child_by_field_name('key') if parent is not None and parent.type == 'pair' else None
    if (scope.type == 'function_expression' and key is not None and key.type == 'property_identifier'
            and parent.child_by_field_name('value') == scope):
        return name or text(key) or None, ancestor(parent.parent, ('object',))
    return name or None, None


def this_owner(call):
    """Object literal providing a stable `this` to the call, or None inside plain nested functions."""
    function = ancestor(call.parent, FUNCTIONS)
    while function is not None and function.type == 'arrow_function':
        function = ancestor(function.parent, FUNCTIONS)
    if function is None:
        return None
    if function.type == 'method_definition':
        return ancestor(function.parent, ('object',))
    parent = function.parent
    key = parent.child_by_field_name('key') if parent is not None and parent.type == 'pair' else None
    if (function.type == 'function_expression' and key is not None and key.type == 'property_identifier'
            and parent.child_by_field_name('value') == function):
        return ancestor(parent.parent, ('object',))
    return None


def url_shape(expression):
    """URL segments from the AST; `{}` marks one dynamic path piece, query strings are dropped."""
    tree = Parser(Language(tree_sitter_javascript.language())).parse(('(' + expression + ');').encode())
    operands = []

    def collect(node):
        node = unwrapped(node)
        if node is not None and node.type == 'binary_expression' and text(node.child_by_field_name('operator')) == '+':
            collect(node.child_by_field_name('left'))
            collect(node.child_by_field_name('right'))
        else:
            operands.append(node)

    root = tree.root_node
    collect(unwrapped(root.named_children[0]) if root.named_children else None)
    buffer, query = '', False
    for operand in operands:
        if query:
            continue
        if operand is not None and operand.type == 'string':
            value = literal(operand)
            if not isinstance(value, str):
                buffer += '\x00'
                continue
            if '?' in value:
                value, _, _ = value.partition('?')
                query = True
            buffer += value
        else:
            buffer += '\x00'
    if '://' in buffer:
        rest = buffer.split('://', 1)[1]
        buffer = rest[rest.find('/'):] if '/' in rest else ''
    return ['{}' if '\x00' in part else part for part in buffer.split('/') if part]


def shape_match(shape, template):
    """Literal URLs need the full route; one dynamic piece fills exactly one template segment."""
    for index, segment in enumerate(shape):
        if index >= len(template):
            return False
        expected = template[index]
        if expected == '**':
            return True
        if expected.startswith('{') or expected == '*':
            continue
        if segment == '{}' or segment != expected:
            return False
    if len(shape) == len(template):
        return True
    return all(expected == '**' for expected in template[len(shape):])


def entire_object(node):
    for child in node.named_children:
        key = child.child_by_field_name('key') if child.type == 'pair' else None
        if key is None or key.type not in ('property_identifier', 'string', 'number'):
            return False
    return True


def straight_line(node, scope):
    parent = node.parent
    while parent is not None and parent != scope:
        if parent.type in UNSTABLE or parent.type in FUNCTIONS:
            return False
        parent = parent.parent
    return parent == scope


def scope_label(scope):
    name = text(scope.child_by_field_name('name'))
    parent = scope.parent
    if not name and parent is not None and parent.type == 'pair':
        key = parent.child_by_field_name('key')
        name = text(key) if key is not None and key.type == 'property_identifier' else ''
    return name or text(parent)[:120]


def label_origin(scope):
    """Enclosing scope carrying a user-visible name, skipping anonymous callbacks."""
    while scope is not None and scope.type in ('arrow_function', 'function_expression'):
        parent = scope.parent
        if parent is not None and parent.type == 'pair' and parent.child_by_field_name('value') == scope:
            break
        if text(scope.child_by_field_name('name')):
            break
        scope = ancestor(scope.parent, (*FUNCTIONS, 'program'))
    return scope


def local_walk(scope):
    """Walk a single scope without descending into nested function bodies."""
    yield scope
    for child in scope.named_children:
        if child.type in FUNCTIONS:
            continue
        yield from local_walk(child)


def redeclares(scope, name, wrapper):
    """True when this scope declares `name` itself, shadowing an outer wrapper."""
    pars = scope.child_by_field_name('parameters') or scope.child_by_field_name('parameter')
    if pars is not None and any(n.type == 'identifier' and text(n) == name for n in walk(pars)):
        return True
    stack = [scope]
    while stack:
        for child in stack.pop().named_children:
            if child == wrapper:
                continue
            if child.type == 'function_declaration' and text(child.child_by_field_name('name')) == name:
                return True
            if child.type == 'variable_declarator' and text(child.child_by_field_name('name')) == name:
                return True
            if child.type not in FUNCTIONS:
                stack.append(child)
    return False


def shadowed(caller, wrapper, name):
    """True when a nested scope between the caller and the wrapper rebinds `name`."""
    scope = ancestor(caller.parent, (*FUNCTIONS, 'program'))
    while scope is not None and scope != wrapper:
        if redeclares(scope, name, wrapper):
            return True
        scope = ancestor(scope.parent, (*FUNCTIONS, 'program')) if scope.type != 'program' else None
    return False


def request_contexts(root, call, depth=0, visited=()):
    """Inline wrappers: unshadowed bare names, this.name only within the same object literal."""
    scope = ancestor(call.parent, (*FUNCTIONS, 'program'))
    name, owner = wrapper_identity(scope)
    pars = scope.child_by_field_name('parameters')
    parameters = [text(n) for n in pars.named_children] if pars else []
    if not name or not parameters:
        return [(scope, None, {})]
    if depth >= 3 or name in visited:
        return []
    contexts = []
    for caller in walk(root):
        if caller.type != 'call_expression':
            continue
        receiver, callee = callee_parts(caller.child_by_field_name('function'))
        if callee != name:
            continue
        if receiver is None:
            if owner is not None or shadowed(caller, scope, name):
                continue
        elif receiver != 'this' or owner is None or this_owner(caller) != owner:
            continue
        args = caller.child_by_field_name('arguments')
        values = args.named_children if args else []
        if len(values) != len(parameters):
            continue
        for outer, trigger, bindings in request_contexts(root, caller, depth + 1, (*visited, name)):
            contexts.append((outer, trigger if trigger is not None else caller,
                             {key: substitute(text(value), bindings) for key, value in zip(parameters, values)}))
    return contexts or [(scope, None, {})]


class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.values, self.labels, self.scripts, self.options = {}, [], [], []
        self.option = None
        self.select = ''

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == 'script' and a.get('src'):
            self.scripts.append(a['src'])
        if tag == 'input' and a.get('id') and 'value' in a:
            self.values['#' + a['id']] = a['value']
        if tag == 'option' and 'value' in a:
            self.option = {'value': a['value'], 'label': '', 'control': self.select}
        if tag == 'select':
            self.select = a.get('id', a.get('name', a.get('v-model', '')))

    def handle_data(self, data):
        value = data.strip()
        if value:
            self.labels.append(value)
            if self.option is not None:
                self.option['label'] += value

    def handle_endtag(self, tag):
        if tag == 'option' and self.option is not None:
            self.options.append(self.option)
            self.option = None
        if tag == 'select':
            self.select = ''


class Frontend:
    def __init__(self, project):
        self.project = project
        self.parser = Parser(Language(tree_sitter_javascript.language()))
        self.sites, self.pages, self.trees, self.warnings = {}, {}, {}, []
        files = sorted(Path(p) for p in front_files(str(project.root)))
        for path in files:
            if path.suffix not in ('.html', '.htm'):
                continue
            page = Page()
            page.feed(path.read_text(errors='replace'))
            self.pages[path] = page
        for path in files:
            if path.suffix != '.js':
                continue
            source = path.read_bytes()
            tree = self.parser.parse(source)
            self.trees[path] = tree
            defaults = {}
            for node in walk(tree.root_node):
                if node.type == 'pair' and text(node.child_by_field_name('key')) == 'data':
                    defaults.update({k: literal(v) for k, v in pairs(node.child_by_field_name('value')).items()})
            pages = [(p, page) for p, page in self.pages.items()
                     if any((p.parent / src).resolve() == path.resolve() for src in page.scripts if not src.startswith(('http', '//')))]
            for call, caller_scope, entry_call, argument_bindings in [
                    (c, outer_scope, trigger, bindings) for c in walk(tree.root_node) if c.type == 'call_expression'
                    for outer_scope, trigger, bindings in request_contexts(tree.root_node, c)]:
                if call.type != 'call_expression':
                    continue
                function = text(call.child_by_field_name('function'))
                args = call.child_by_field_name('arguments')
                if not args or not args.named_children:
                    continue
                config = pairs(args.named_children[0])
                if not config.get('url') or not re.search(r'ajax$|\$http$', function):
                    continue
                raw_url = substitute(text(config['url']), argument_bindings)
                local_definitions = {}
                for node in local_walk(caller_scope):
                    limit = entry_call or call
                    if node.start_byte >= limit.start_byte:
                        continue
                    if node.type == 'variable_declarator':
                        local_definitions[text(node.child_by_field_name('name'))] = (
                            text(node.child_by_field_name('value')) if straight_line(node, caller_scope) else 'undefined')
                    if node.type == 'assignment_expression' and node.child_by_field_name('left').type == 'identifier':
                        local_definitions[text(node.child_by_field_name('left'))] = (
                            text(node.child_by_field_name('right')) if straight_line(node, caller_scope) else 'undefined')
                # Resolve aliases only when their definition is a single expression.
                for _ in range(4):
                    changed = substitute(raw_url, {k: v for k, v in local_definitions.items()
                                                  if v and re.search(r'[\"\'](?:/|http)', v)})
                    if changed == raw_url:
                        break
                    raw_url = changed
                strings = re.findall(r'[\"\']([^\"\']+)[\"\']', raw_url)
                prefix = next((s for s in strings if s.startswith(('/', 'http'))), '')
                verb = str(literal(config.get('type') or config.get('method'))).upper()
                if not prefix:
                    self.warnings.append(str(path.relative_to(project.root)) + ': unresolved request URL')
                    continue
                shape = url_shape(raw_url)
                handlers = sorted({mid for mid, hv, template in project.ix.handlers
                                   if (verb == str(U).upper() or hv is None or hv == verb)
                                   and shape_match(shape, template)})
                if not handlers:
                    continue
                scope = ancestor(call.parent, (*FUNCTIONS, 'program'))
                inlined = caller_scope != scope
                field_scopes = [(caller_scope, entry_call), (scope, call)] if inlined else [(scope, call)]
                definitions, fields, straight, unknown_writes = {}, {}, {}, set()
                for owner_scope, limit in field_scopes:
                    for node in local_walk(owner_scope):
                        if node.start_byte >= limit.start_byte:
                            continue
                        if node.type == 'variable_declarator':
                            name = text(node.child_by_field_name('name'))
                            definitions[name] = (text(node.child_by_field_name('value'))
                                                 if straight_line(node, owner_scope) else 'undefined')
                            if node.child_by_field_name('value') is not None:
                                straight.setdefault(name, []).append(straight_line(node, owner_scope))
                        if node.type == 'assignment_expression':
                            lhs = text(node.child_by_field_name('left'))
                            if '[' in lhs:
                                owner = lhs.split('[', 1)[0].rstrip('.')
                                unknown_writes.add(owner)
                                fields[owner] = {}
                            elif '.' in lhs:
                                owner, key = lhs.rsplit('.', 1)
                                line = straight_line(node, owner_scope)
                                straight.setdefault(owner, []).append(line)
                                if line:
                                    fields.setdefault(owner, {})[key] = text(node.child_by_field_name('right'))
                                else:
                                    fields.setdefault(owner, {}).pop(key, None)
                            else:
                                fields.pop(lhs, None)
                                definitions[lhs] = (text(node.child_by_field_name('right'))
                                                    if straight_line(node, owner_scope) else 'undefined')
                                unknown_writes.add(lhs)
                data = substitute(text(config.get('data')), argument_bindings)
                seen, stringified = set(), False
                while data and data not in seen:
                    seen.add(data)
                    root = self.parser.parse(('(' + data + ');').encode()).root_node
                    node = unwrapped(root.named_children[0]) if root.named_children else None
                    if node is None:
                        break
                    if node.type == 'call_expression' and text(node.child_by_field_name('function')) == 'JSON.stringify':
                        args = node.child_by_field_name('arguments')
                        inner = unwrapped(args.named_children[0]) if args and len(args.named_children) == 1 else None
                        if inner is None:
                            break
                        data, stringified = text(inner), True
                        continue
                    raw = text(node)
                    if raw != data:
                        data = raw
                        continue
                    if node.type == 'identifier' and data in definitions and data not in fields:
                        data = definitions[data]
                        continue
                    break
                body = fields.get(data, {})
                body_complete = False
                root = self.parser.parse(('(' + data + ');').encode()).root_node if data else None
                body_node = unwrapped(root.named_children[0]) if root and root.named_children else None
                if body_node is not None and body_node.type == 'object':
                    body = {key: text(value) for key, value in pairs(body_node).items()}
                    body_complete = entire_object(body_node)
                elif config.get('data') is not None and not body and literal(body_node) is U:
                    self.warnings.append(str(path.relative_to(project.root)) + ': unresolved request body: ' + data[:160])
                elif data in fields and definitions.get(data) in ('new Object()', '{}'):
                    body_complete = data not in unknown_writes and all(straight.get(data, []))
                for owner, properties in fields.items():
                    if definitions.get(owner) in ('new Object()', '{}'):
                        definitions[owner] = '{' + ','.join(json.dumps(k) + ':' + v for k, v in properties.items()) + '}'
                success = config.get('success')
                effects = []
                response_definitions = {}
                response_name = 'response'
                if success:
                    pars = success.child_by_field_name('parameters')
                    if pars and pars.named_children:
                        response_name = text(pars.named_children[0])
                    for node in walk(success):
                        if node.type == 'variable_declarator':
                            response_definitions[text(node.child_by_field_name('name'))] = text(node.child_by_field_name('value'))
                        condition = []
                        parent = node.parent
                        while parent and parent != success:
                            if parent.type == 'if_statement':
                                cond = text(parent.child_by_field_name('condition'))
                                alternative = parent.child_by_field_name('alternative')
                                condition.append('!(' + cond + ')' if alternative and alternative.start_byte <= node.start_byte < alternative.end_byte else cond)
                            parent = parent.parent
                        if node.type == 'call_expression':
                            fn = text(node.child_by_field_name('function'))
                            arguments = node.child_by_field_name('arguments')
                            values = arguments.named_children if arguments else []
                            storage = re.fullmatch(r'(?:sessionStorage|localStorage)\.setItem', fn)
                            dom = re.fullmatch(r'\$\(([\"\'])([^\"\']*)\1\)\.(val|text|html)', fn)
                            if storage and len(values) >= 2 and isinstance(literal(values[0]), str):
                                effects.append({'space': 'storage', 'key': literal(values[0]), 'expr': text(values[1]), 'conditions': condition})
                            elif dom and values:
                                effects.append({'space': 'dom', 'key': dom[2], 'expr': text(values[0]), 'conditions': condition})
                        elif node.type == 'assignment_expression':
                            lhs = text(node.child_by_field_name('left'))
                            if lhs.startswith(('this.', 'that.')):
                                effects.append({'space': 'form', 'key': lhs.split('.', 1)[1], 'expr': text(node.child_by_field_name('right')), 'conditions': condition})
                            elif lhs in ('location.href', 'window.location.href'):
                                effects.append({'space': 'navigation', 'key': 'href', 'expr': text(node.child_by_field_name('right')), 'conditions': condition})
                sid = path.relative_to(project.root).as_posix() + ':' + str(call.start_point.row + 1)
                if argument_bindings:
                    sid += '@' + str(caller_scope.start_point.row + 1) + ':' + str(len(self.sites))
                label_scope = label_origin(caller_scope if inlined else scope)
                self.sites[sid] = {'id': sid, 'file': path.relative_to(project.root).as_posix(),
                                   'page': pages[0][0].relative_to(project.root).as_posix() if pages else path.relative_to(project.root).as_posix(),
                                   'line': call.start_point.row + 1, 'handlers': handlers, 'verb': verb,
                                   'url': raw_url, 'prefix': prefix, 'url_shape': shape,
                                   'body_fields': body, 'body_complete': body_complete, 'stringified': stringified,
                                   'definitions': definitions, 'defaults': defaults,
                                   'dom_defaults': {k: v for _, page in pages for k, v in page.values.items()},
                                   'options': [o for _, page in pages for o in page.options],
                                   'labels': ' '.join(label for _, page in pages for label in page.labels)[:1800],
                                   'source': text(label_scope)[:2800],
                                   'helper_source': text(scope)[:2800] if inlined else None,
                                   'action_label': scope_label(label_scope),
                                   'effects': effects, 'response_name': response_name,
                                   'response_definitions': response_definitions}

    def evaluate(self, expression, state, extra=None, definitions=None):
        if not expression:
            return U
        tree = self.parser.parse(('(' + expression + ');').encode())
        active = set()
        env = {'this': state.browser['form'], 'that': state.browser['form'], **(extra or {})}

        def value(node):
            if node is None:
                return U
            kind, raw = node.type, text(node)
            if kind in ('string', 'number', 'true', 'false', 'null'):
                return literal(node)
            if kind in ('parenthesized_expression', 'expression_statement'):
                return value(node.named_children[0]) if node.named_children else U
            if kind in ('identifier', 'this'):
                if raw in env:
                    return env[raw]
                if raw in (definitions or {}) and raw not in active:
                    active.add(raw)
                    result = self.evaluate(definitions[raw], state, env, {k: v for k, v in definitions.items() if k != raw})
                    active.remove(raw)
                    return result
                return U
            if kind == 'member_expression':
                obj = value(node.child_by_field_name('object'))
                key = text(node.child_by_field_name('property'))
                return obj.get(key, U) if isinstance(obj, dict) else len(obj) if key == 'length' and isinstance(obj, (str, list)) else U
            if kind == 'subscript_expression':
                obj, key = value(node.child_by_field_name('object')), value(node.child_by_field_name('index'))
                if isinstance(obj, dict):
                    return obj.get(key, U)
                return obj[key] if isinstance(obj, (list, str)) and isinstance(key, int) and 0 <= key < len(obj) else U
            if kind == 'binary_expression':
                left, right = value(node.child_by_field_name('left')), value(node.child_by_field_name('right'))
                op = text(node.child_by_field_name('operator'))
                if left is U or right is U:
                    return U
                if any(isinstance(value, dict) and '__symbol__' in value for value in (left, right)):
                    return U
                if op == '+':
                    return str(left) + str(right) if isinstance(left, str) or isinstance(right, str) else left + right
                if op in ('==', '===', '!=', '!=='):
                    equal = left == right or (op in ('==', '!=') and str(left) == str(right))
                    return not equal if '!' in op else equal
                if op in ('&&', '||'):
                    return left and right if op == '&&' else left or right
                return U
            if kind == 'unary_expression':
                arg = value(node.child_by_field_name('argument'))
                return not arg if raw.startswith('!') and isinstance(arg, bool) else U
            if kind == 'call_expression':
                fn = text(node.child_by_field_name('function'))
                args = node.child_by_field_name('arguments')
                vals = [value(c) for c in args.named_children] if args else []
                if fn in ('sessionStorage.getItem', 'localStorage.getItem') and vals and isinstance(vals[0], str):
                    return state.browser['storage'].get(vals[0], U)
                if fn == 'JSON.stringify' and vals:
                    return vals[0]
                if fn in ('parseInt', 'parseFloat') and vals:
                    try:
                        return int(vals[0]) if fn == 'parseInt' else float(vals[0])
                    except (ValueError, TypeError):
                        return U
                dom = re.fullmatch(r'\$\(([\"\'].*?[\"\'])\)\.(?:val|text)', fn)
                if dom:
                    return state.browser['dom'].get(dom[1][1:-1], U)
                return U
            if kind == 'object':
                return {key: value(val) for key, val in pairs(node).items()}
            if kind == 'array':
                return [value(c) for c in node.named_children]
            return U

        try:
            return value(tree.root_node.named_children[0])
        except (TypeError, ValueError, IndexError, KeyError, AttributeError):
            state.limitations.append('unsupported JavaScript value operation: ' + expression[:160])
            return U

    def enter(self, site, state):
        page = site['page']
        active = state.browser.get('active_page')
        if page != active:
            if isinstance(active, str):
                state.browser.setdefault('pages', {})[active] = {'form': state.browser['form'], 'dom': state.browser['dom']}
            previous = state.browser.setdefault('pages', {}).get(page, {})
            if not isinstance(previous, dict):
                previous = {'form': {key: U for key in site['defaults']},
                            'dom': {key: U for key in site['dom_defaults']}}
                state.limitations.append('unknown prior browser page state: ' + page)
            state.browser['form'] = deepcopy(previous.get('form', {}))
            state.browser['dom'] = deepcopy(previous.get('dom', {}))
            state.browser['active_page'] = page
        for name, default in site['defaults'].items():
            state.browser['form'].setdefault(name, deepcopy(default))
        for name, default in site['dom_defaults'].items():
            state.browser['dom'].setdefault(name, default)

    def apply_response(self, site, result, state):
        env = {site['response_name']: result}
        for effect in site['effects']:
            conditions = [self.evaluate(c, state, env, site['response_definitions']) for c in effect['conditions']]
            if False in conditions:
                continue
            val = self.evaluate(effect['expr'], state, env, site['response_definitions'])
            if any(c is U for c in conditions):
                val = U
                state.limitations.append('unknown browser response guard: ' + site['id'])
            if effect['space'] == 'navigation':
                if isinstance(val, str):
                    state.browser['url'] = dict(parse_qsl(urlsplit(val).query))
                else:
                    state.browser['url'] = {key: U for key in state.browser['url']}
                    state.limitations.append('unknown browser navigation target: ' + site['id'])
            else:
                key = effect['key']
                if not isinstance(key, str):
                    state.browser[effect['space']] = {key: U for key in state.browser[effect['space']] if isinstance(key, str)}
                    state.limitations.append('unknown browser response key: ' + site['id'])
                else:
                    state.browser[effect['space']][key] = val
