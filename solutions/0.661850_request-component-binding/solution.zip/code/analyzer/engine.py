"""Bounded abstract interpretation of Java source, with explicit unknown values.

Only source text is interpreted. This module never loads JVM classes or contacts
the application's services. Unresolved branches retain both possible paths.
"""
from collections import defaultdict,Counter
from copy import deepcopy
from contextlib import contextmanager
import json
import operator
import math
import re

from .project import text,walk
from .state import U
from .models import construct, library, known, unwrap, wire, key_equal, http_entity, optional_value, status_code, header_values
from .constraints import assume, compare
from .java_exceptions import JavaThrow, assignable, native_type, NATIVE_TYPES
from .symbolic_text import concat_text
from .request_url import request_address, client_template
from .http_binding import bind_named, BindingFailure
from .models import java_date_text, uuid_value, http_headers_type
from .java_collections import JavaObject, JavaRecord, JavaMap, JavaMapView, JavaMapEntry, JavaMapIterator, JavaEnumValue, JavaTypeToken, JavaTypeFactory, JsonObject, JsonText, JavaJsonMapper, JacksonFeature, reference_equal, is_symbolic
from .json_codec import operation as codec_operation, conversion as codec_conversion
from .java_numbers import parse_integer
from .http_json import decode_response,type_parts
from .map_keys import same_key
from .heap_join import join_environment,clone_environment,owned_objects,widen
from .map_views import iterator_next
from datetime import datetime


def member(obj, key):
    if not isinstance(obj, dict):
        return U
    if key in obj:
        return obj[key]
    if isinstance(obj,(JavaRecord,JsonObject,JavaEnumValue)):return U
    normalized = re.sub(r'[^a-z0-9]', '', key.lower())
    return next((v for k, v in obj.items() if re.sub(r'[^a-z0-9]', '', k.lower()) == normalized), U)


def exception_type(value):
    return value.java_type if isinstance(value,JavaObject) else native_type(value.get('__type__',U)) if type(value) is dict else U


def merge(a, b, active=None, memo=None):
    active=set() if active is None else active
    memo={} if memo is None else memo
    pair=(id(a),id(b))
    if pair in active:return U
    if pair not in memo:memo[pair]=merge_values(a,b,active,memo)
    return memo[pair]


def merge_values(a, b, active, memo):
    if a is b:return a
    if isinstance(a,JacksonFeature) or isinstance(b,JacksonFeature):
        return a if isinstance(a,JacksonFeature) and isinstance(b,JacksonFeature) and a.name==b.name else U
    if isinstance(a,JavaJsonMapper) or isinstance(b,JavaJsonMapper):
        if not isinstance(a,JavaJsonMapper) or not isinstance(b,JavaJsonMapper):return U
        identity=a.java_identity if a.java_identity is b.java_identity else None
        result=JavaJsonMapper({key:merge(a.flags[key],b.flags[key],active,memo) for key in a.defaults},identity)
        result.used,result.opaque=a.used or b.used,a.opaque or b.opaque
        return result
    if isinstance(a,JavaTypeToken) or isinstance(b,JavaTypeToken):
        return a if isinstance(a,JavaTypeToken) and isinstance(b,JavaTypeToken) and (a.written,a.kind,a.context)==(b.written,b.kind,b.context) else U
    if isinstance(a,JavaEnumValue) or isinstance(b,JavaEnumValue):
        return a if isinstance(a,JavaEnumValue) and isinstance(b,JavaEnumValue) and a.enum_key==b.enum_key and a==b else U
    if isinstance(a,JavaRecord) or isinstance(b,JavaRecord):
        if not isinstance(a,JavaRecord) or not isinstance(b,JavaRecord) or a.declared_type!=b.declared_type:return U
    active=set() if active is None else active
    pair=(id(a),id(b))
    if pair in active:return U
    active.add(pair)
    try:
        if isinstance(a,JavaRecord):
            fields={key:merge(a.get(key,U),b.get(key,U),active,memo) for key in sorted(a.keys()|b.keys())}
            wire_fields=a.wire_fields|b.wire_fields
            if isinstance(a,JavaObject) and isinstance(b,JavaObject):
                identity=a.java_identity if a.java_identity is b.java_identity else None
                return JavaObject(a.java_type,fields,identity,wire_fields)
            return JavaRecord(a.declared_type,fields,wire_fields)
        if isinstance(a,JavaMap) or isinstance(b,JavaMap):
            if not isinstance(a,JavaMap) or not isinstance(b,JavaMap):return U
            identity=a.java_identity if a.java_identity is b.java_identity else None
            if (not isinstance(a.mapping,dict) or not isinstance(b.mapping,dict) or a.mapping.keys()!=b.mapping.keys()
                    or len(a.typed_entries)!=len(b.typed_entries)
                    or any(same_key(left,right) is not True for left,right in zip(a.typed_entries,b.typed_entries))):
                return JavaMap(U,identity).merge_metadata(a,b)
            typed=[{**left,'value':merge(left['value'],right['value'],active,memo),
                    'value_kind':left.get('value_kind') if left.get('value_kind')==right.get('value_kind') else None} for left,right in zip(a.typed_entries,b.typed_entries)]
            origin=a.origin_type if a.origin_type==b.origin_type else None
            kinds={key:a.value_types.get(key) if a.value_types.get(key)==b.value_types.get(key) else None for key in a.mapping}
            return JavaMap({key:merge(value,b.mapping[key],active,memo) for key,value in a.mapping.items()},identity,typed,origin,kinds).merge_metadata(a,b)
        if isinstance(a,JavaMapView) or isinstance(b,JavaMapView):
            if not isinstance(a,JavaMapView) or not isinstance(b,JavaMapView) or a.kind!=b.kind:return U
            backing=merge(a.backing,b.backing,active,memo)
            return JavaMapView(backing,a.kind) if isinstance(backing,JavaMap) else U
        if isinstance(a,JavaMapEntry) or isinstance(b,JavaMapEntry):
            if not isinstance(a,JavaMapEntry) or not isinstance(b,JavaMapEntry) or same_key(a.key,b.key) is not True:return U
            backing=merge(a.backing,b.backing,active,memo)
            if not isinstance(backing,JavaMap):return U
            result=JavaMapEntry(backing,a.key);result.version=a.version if a.version==b.version else None
            return result
        if isinstance(a,JavaMapIterator) or isinstance(b,JavaMapIterator):
            if not isinstance(a,JavaMapIterator) or not isinstance(b,JavaMapIterator):return U
            view=merge(a.view,b.view,active,memo)
            if not isinstance(view,JavaMapView):return U
            result=JavaMapIterator(view)
            result.remaining=merge(a.remaining,b.remaining,active,memo)
            result.expected=a.expected if a.expected==b.expected else None
            result.last=merge(a.last,b.last,active,memo)
            return result
        if isinstance(a,JsonText) or isinstance(b,JsonText):
            return JsonText(merge(a.payload,b.payload,active,memo),a.exact and b.exact) if isinstance(a,JsonText) and isinstance(b,JsonText) else U
        if isinstance(a,JsonObject) or isinstance(b,JsonObject):
            if not isinstance(a,JsonObject) or not isinstance(b,JsonObject):return U
            fields={key:merge(a.get(key,U),b.get(key,U),active,memo) for key in a.keys()|b.keys()}
            return JsonObject(fields,a.origin_type if a.origin_type==b.origin_type else None)
        if isinstance(a, dict) and isinstance(b, dict):
            return {key: merge(a.get(key, U), b.get(key, U),active,memo) for key in sorted(a.keys() | b.keys(), key=lambda k: (type(k).__name__, str(k)))}
        if isinstance(a,list) and isinstance(b,list):
            if len(a)!=len(b):return U
            joined=[merge(left,right,active,memo) for left,right in zip(a,b)]
            return joined if joined==a and joined==b else U
        if isinstance(a,tuple) and isinstance(b,tuple) and len(a)==len(b)==5 and a[0]==b[0]=='lambda':
            if a[1]!=b[1] or a[3:]!=b[3:]:return U
            return ('lambda',a[1],merge(a[2],b[2],active,memo),a[3],a[4])
        if type(a) is type(b) and a == b:return a
        return U
    finally:
        active.remove(pair)


class AlternativeRequired(Exception):
    def __init__(self, key, choices):
        self.key, self.choices = key, choices


class Engine:
    def __init__(self, project, state, decisions=None, conservative=False, constraints=True):
        self.p, self.state = project, state
        self.edges = set()
        self.evidence = defaultdict(set)
        self.conditions, self.warnings = [], set()
        self.data_operations = []
        self.created_objects = []
        self.active = set()
        self.calls = 0
        self.method = None
        self.params = {}
        self.uncertain = 0
        self.decisions = decisions or {}
        self.conservative = conservative
        self.branch_index = 0
        self.approximate = False
        self.outcome = 'returned' 
        self.use_constraints = constraints
        self.variable_types = {}
        self.constraint_sequence = 0
        self.filter_frames = []
        self.operation_issues=Counter()

    def constraint_symbol(self):
        self.constraint_sequence += 1
        return 'path-scalar-' + str(self.constraint_sequence)

    def choose(self, label, choices):
        self.branch_index += 1
        key = str(self.branch_index) + ':' + label
        if key in self.decisions:
            return self.decisions[key]
        if not self.conservative:
            raise AlternativeRequired(key, choices)
        self.approximate = True
        self.warnings.add('path budget: alternatives conservatively retained at ' + label)
        return None

    def add(self, source, relation, target, reason):
        self.edges.add((source, relation, target))
        self.evidence[(source, relation, target)].add(reason)

    def executed(self, mid, reason):
        self.add('', 'executes', mid, reason)

    def json_issue(self,message,reason):
        self.approximate=True
        self.warnings.add(message+': '+reason)
        self.operation_issues[('http_json_binding',message)]+=1

    def json_wire(self,value,reason):
        return wire(value,lambda message:self.json_issue(message,reason),self.p.json_model_limits)

    def run(self, entry, params):
        self.params = params
        self.entry = entry
        try:
            args = lambda: [self.input_value(name, typ, params) for name, typ in self.p.parameters(entry)]
            result,_ = self.http_invoke(entry, args, 'scenario request')
            if any(entry==handler for handler,_,_ in self.p.ix.handlers):
                try:self.json_wire(unwrap(result),entry)
                except JavaThrow as failure:
                    if isinstance(failure.value,dict) and failure.value.get('__serialization_failure__'):
                        self.outcome='HTTP serialization failure'
                        self.warnings.add('default HTTP JSON serialization failed on cyclic object graph: '+entry)
                        return U
                    raise
            if http_entity(result) and type(result.get('status')) is int and result['status']>=400:
                self.outcome='HTTP error response'
        except JavaThrow as exc:
            self.outcome = 'uncaught application exception'
            self.warnings.add('uncaught Java exception: '+str(exception_type(exc.value)))
            return U
        return unwrap(result)

    def http_invoke(self,entry,args,reason):
        if not self.p.enabled_type(self.p.methods[entry]['owner']):
            self.outcome='inactive request handler'
            self.warnings.add('request handler disabled by Spring profile: '+entry)
            return U,False
        meta=self.p.methods[entry]
        type_names=[*re.findall(r'[\w.]+',meta.get('return_raw','')),
                    *(typ for _,typ in self.p.parameters(entry))]
        for name in type_names:
            tid=self.p.resolve_type(name,meta['module'],meta['file'])
            for annotation in self.p.nodes.get(tid,{}).get('annotations',[]):
                if annotation['name'].split('.')[-1] in ('JsonSerialize','JsonDeserialize'):
                    self.approximate=True
                    self.warnings.add('custom HTTP codec is not executed: '+annotation['name']+' on '+name)
        filters = [mid for mid in self.p.by_name.get('doFilterInternal',[])
                   if self.p.ix.unit_of(mid)==self.p.ix.unit_of(entry)
                   and self.p.enabled_type(self.p.methods[mid]['owner'])
                   and 'OncePerRequestFilter' in (self.p.root/self.p.methods[mid]['file']).read_text()]
        def order(mid):
            annotations = [*self.p.methods[mid].get('annotations',[]),*self.p.nodes[self.p.methods[mid]['owner']].get('annotations',[])]
            values = [re.fullmatch(r'\(\s*(-?\d+)\s*\)',a.get('args','')) for a in annotations if a['name'].split('.')[-1]=='Order']
            return int(values[0][1]) if len(values)==1 and values[0] is not None else None
        orders = [order(mid) for mid in filters]
        if filters:
            self.approximate=True
            self.warnings.add('request filter registration is assumed from source classes; full bean registration is not modeled')
        if len(filters)>1 and (None in orders or len(set(orders))!=len(orders)):
            self.warnings.add('unknown request filter order; possible execution retained: '+entry)
            self.fallback(entry)
            for mid in filters:self.fallback(mid)
        filters.sort(key=lambda mid:(order(mid) is None,order(mid) or 0,mid))
        response = {'__type__':'HttpServletResponse','status':200,'body':U}
        frame = {'entry':entry,'args':args,'filters':filters,'reason':reason,'entered':False,'result':U,
                 'response':response,'request':{'__type__':'HttpServletRequest'}}
        self.filter_frames.append(frame)
        try:
            self.continue_filter(len(self.filter_frames)-1,0)
            if frame['entered']:return frame['result'],True
            if len(self.filter_frames)==1:self.outcome='HTTP binding failure' if frame.get('binding_failed') else 'request stopped by filter'
            return {'__type__':'ResponseEntity','__http_entity__':True,'body':response['body'],'status':response['status']},False
        except JavaThrow as failure:
            failure.http_entered=frame['entered']
            raise
        finally:
            self.filter_frames.pop()

    def server_error_status(self,target,failure):
        unit=self.p.ix.unit_of(target)
        cache=self.p.__dict__.setdefault('_server_error_mapping_cache',{})
        if unit not in cache:
            cache[unit]=any(any(annotation['name'].split('.')[-1]=='ExceptionHandler' for annotation in meta.get('annotations',[]))
                            for mid,meta in self.p.methods.items() if self.p.ix.unit_of(mid)==unit)
            cache[unit]|=any(any(parent.split('.')[-1] in ('HandlerExceptionResolver','ErrorController') for parent in parents)
                             for owner,parents in self.p.framework_types.items() if unit in self.p.ix.units.get(self.p.nodes[owner].get('module'),()))
        thrown=exception_type(failure.value)
        meta=self.p.methods[target]
        pending=[self.p.resolve_type(thrown,meta['module'],meta['file'])] if isinstance(thrown,str) else []
        seen=set();custom=cache[unit]
        while pending:
            owner=pending.pop()
            if owner is None or owner in seen:continue
            seen.add(owner)
            custom|=any(a['name'].split('.')[-1]=='ResponseStatus' for a in self.p.nodes[owner].get('annotations',[]))
            pending.extend(self.p.type_parents.get(owner,()))
        if not custom and isinstance(failure.value,dict) and '__http_binding_status__' in failure.value:
            return failure.value['__http_binding_status__']
        if not custom and (assignable(thrown,'java.lang.Exception',self.p) is True or assignable(thrown,'java.lang.Error',self.p) is True):return 500
        self.json_issue('server exception status or custom exception resolver is not modeled',target)
        return U

    def continue_filter(self,frame_index,position):
        frame = self.filter_frames[frame_index]
        if position==len(frame['filters']):
            try:
                args=frame['args']() if callable(frame['args']) else frame['args']
            except BindingFailure as failure:
                frame['binding_failed']=True
                self.warnings.add('HTTP binding rejected request: '+str(failure))
                frame['response']['status']=self.server_error_status(frame['entry'],JavaThrow(
                    {'__http_binding_status__':failure.status,'__type__':'ServletRequestBindingException'}))
                return
            frame['entered']=True
            frame['result']=self.invoke(frame['entry'],args,reason=frame['reason'])
            return
        mid = frame['filters'][position]
        skips=self.p.methods_of(self.p.methods[mid]['owner'],'shouldNotFilter')
        if len(skips)==1:
            skip=self.invoke(skips[0],[frame['request']],reason='OncePerRequestFilter shouldNotFilter callback')
            if type(skip) is not bool:
                self.approximate=True
                self.warnings.add('unknown shouldNotFilter result: '+mid)
                skip=self.choose(mid+':should-not-filter',[True,False])
                if skip is None:self.fallback(frame['entry'])
            if skip is True:
                self.continue_filter(frame_index,position+1)
                return
        values = [{'__filter_chain__':(frame_index,position+1)} if typ.endswith('FilterChain') else
                  frame['response'] if typ.endswith('HttpServletResponse') else frame['request']
                  for _,typ in self.p.parameters(mid)]
        self.invoke(mid,values,reason='project request filter')

    def input_value(self, name, typ, params):
        if typ.split('.')[-1].lstrip('?')=='HttpHeaders':
            return {'__type__': 'HttpHeaders','__http_headers__':True,'headers':U}
        if name in params:
            target=self.method or getattr(self,'entry','')
            if any(p['name']==name and p['kind']=='RequestBody' for p in self.p.http_parameters(target)):
                if self.standard_type(typ,'java.lang.String',self.p.methods[target]):
                    return deepcopy(params[name]) if isinstance(params[name],JsonText) else self.coerce(params[name],typ)
                return self.bind_http_body(params[name],typ,target,'scenario request')
            return self.coerce(params[name], typ)
        if typ.split('.')[-1] in ('String', 'UUID', 'int', 'double', 'boolean', 'Date', 'Long'):
            return U
        value = {'__type__': typ, **deepcopy(params)}
        method = self.method or getattr(self, 'entry', '')
        meta = self.p.methods.get(method, {})
        tid = self.p.resolve_type(typ, meta.get('module'), meta.get('file'))
        if tid in self.p.type_fields and not typ.startswith('org.springframework.http.'):
            if '__http_entity__' not in self.p.type_fields[tid]:value['__http_entity__'] = False
            value=JavaRecord(self.p.nodes[tid]['fqn'],value,self.p.type_fields[tid])
        return value

    def bind_http_body(self,value,typ,target,reason):
        """Own the HTTP value independently and rebind by the receiver's schema."""
        meta=self.p.methods[target]
        payload=self.json_wire(value,reason)
        if self.standard_type(typ,'java.lang.String',meta):
            if isinstance(payload,(JsonText,str)) or is_symbolic(payload) and payload.get('__type__') in ('String','java.lang.String'):return deepcopy(payload)
            if type(payload) in (int,bool):return str(payload).lower()
            if isinstance(payload,(dict,list)):return JsonText(payload)
            if payload is U or payload is None:return payload
            self.json_issue('HTTP request text representation is not modeled',reason)
            return U
        if isinstance(payload,JsonText):payload=payload.payload
        owner=self.p.resolve_type(typ,meta['module'],meta['file'])
        if owner in self.p.type_fields and isinstance(payload,dict) and not is_symbolic(payload):
            payload=JsonObject({**self.p.request_body_defaults(target),**payload},getattr(payload,'origin_type',None))
        return decode_response(self.p,payload,typ,meta,self.standard_type,lambda message:self.json_issue(message,reason))

    @staticmethod
    def coerce(value, typ):
        if typ in ('UUID','java.util.UUID') and value is not None and value is not U:
            try:return uuid_value(value)
            except JavaThrow:return U
        typ = typ.split('.')[-1]
        if value is U or value is None:
            return value
        if is_symbolic(value):
            aliases = {'Integer': 'int', 'Long': 'long', 'Boolean': 'boolean', 'Double': 'double', 'Float': 'float'}
            source_type = value['__type__'].split('.')[-1]
            return value if aliases.get(source_type, source_type) == aliases.get(typ, typ) else U
        if typ in ('boolean', 'Boolean'):
            return value if isinstance(value, bool) else value.lower() == 'true' if isinstance(value, str) and value.lower() in ('true', 'false') else U
        if typ in ('int', 'Integer', 'long', 'Long', 'short', 'Short', 'byte', 'Byte'):
            if isinstance(value, bool):
                return U
            try:
                return int(value) if isinstance(value, (str, int)) else U
            except ValueError:
                return U
        if typ in ('double', 'Double', 'float', 'Float'):
            try:
                return float(value) if not isinstance(value, bool) else U
            except (TypeError, ValueError):
                return U
        if typ == 'Date':
            from .models import date_value
            return date_value(value)
        if typ == 'String':
            return value if isinstance(value, str) else U
        if isinstance(value, str):
            try:
                if typ in ('int', 'Integer', 'long', 'Long'): return int(value)
                if typ in ('double', 'Double', 'float', 'Float'): return float(value)
                if typ in ('boolean', 'Boolean'): return value.lower() == 'true'
            except ValueError:
                return U
        return value

    def invoke(self, mid, args, receiver=None, reason='source call'):
        self.executed(mid, reason)
        meta = self.p.methods[mid]
        if self.p.profile_status(meta['owner']) is U:
            self.approximate=True
            self.warnings.add('unsupported Spring profile expression; candidate retained as possible: '+mid)
        for annotation in [*meta.get('annotations',[]),*self.p.nodes[meta['owner']].get('annotations',[])]:
            if annotation['name'].split('.')[-1] in ('PreAuthorize','PostAuthorize','Secured','RolesAllowed','Cacheable','CachePut','CacheEvict','Async') or annotation['name'].split('.')[-1].startswith('Conditional'):
                self.approximate=True
                self.warnings.add('framework method interception is not fully modeled: '+annotation['name']+' at '+mid)
        node=self.p.ast.get(mid)
        if node is not None and re.search(r'@(?:Valid|Validated)\b',text(node.child_by_field_name('parameters'))):
            self.approximate=True
            self.warnings.add('request bean validation is not fully modeled: '+mid)
        transactional = any(a['name'].split('.')[-1] == 'Transactional' for a in
                            [*meta.get('annotations', []), *self.p.nodes[meta['owner']].get('annotations', [])])
        if transactional:
            self.approximate = True
            self.warnings.add('transaction dirty checking is not fully modeled: ' + mid)
        signature = (mid, json.dumps(args, sort_keys=True, default=str))
        if signature in self.active or self.calls >= 12000 or len(self.active) >= 64:
            self.warnings.add('recursion or context budget: conservative closure used')
            self.fallback(mid)
            return U
        node = self.p.ast.get(mid)
        if node is None:
            self.warnings.add('no source body: ' + mid)
            self.fallback(mid)
            return U
        self.calls += 1
        self.active.add(signature)
        previous = self.method
        previous_types = self.variable_types
        self.method = mid
        self.variable_types = dict(self.p.parameters(mid))
        env = {name: args[i] if i < len(args) else U for i, (name, _) in enumerate(self.p.parameters(mid))}
        env['this'] = receiver if isinstance(receiver, dict) else {}
        body = node.child_by_field_name('body')
        data_start, failed = len(self.data_operations), True
        try:
            try:
                result, control = self.execute(body, env)
            except (TypeError, ValueError, IndexError, KeyError, AttributeError, ZeroDivisionError) as exc:
                self.approximate = True
                self.warnings.add('unsupported value operation in ' + mid + ': ' + type(exc).__name__)
                self.fallback(mid)
                result, control = U, None
            failed = control == 'throw'
        finally:
            if transactional and failed:
                for operation in self.data_operations[data_start:]:
                    rows = self.state.database.rows(self.p.nodes[operation['resource']])
                    if rows is not None:
                        self.state.database.invalidate(rows)
                self.approximate = True
                self.warnings.add('transaction failure: rollback/commit is unknown; touched tables widened: ' + mid)
            self.method = previous
            self.variable_types = previous_types
            self.active.remove(signature)
        if control == 'throw':
            raise JavaThrow(result)
        return result

    def fallback(self, mid):
        self.approximate = True
        methods, calls, remote, data = self.p.ix.closure({mid})
        for method in methods:
            self.executed(method, 'unresolved source: may-call closure')
        for relation, pairs in [('calls', calls), ('remote', remote), ('data', data)]:
            for source, target in pairs:
                self.add(source, relation, target, 'unresolved source: may-call closure')
                if relation == 'data':
                    rows = self.state.database.rows(self.p.nodes[target])
                    if rows is not None:
                        self.state.database.invalidate(rows)

    def execution_fork(self,state):
        # Method execution never mutates completed request observations. Share
        # their payloads, but own the journal list and all mutable execution data.
        return deepcopy(state,{id(state.history):list(state.history)})

    @contextmanager
    def binding_scope(self,env,names):
        saved={name:(name in env,env.get(name),self.variable_types.get(name)) for name in names}
        try:yield
        finally:
            for name,(present,value,typ) in saved.items():
                if present:env[name]=value
                else:env.pop(name,None)
                if typ is None:self.variable_types.pop(name,None)
                else:self.variable_types[name]=typ

    def unbox(self,value,node):
        if value is None and any(self.standard_type(self.source_type(node),'java.lang.'+name)
                                 for name in ('Integer','Long','Short','Byte','Float','Double','Character','Boolean')):
            raise JavaThrow({'__type__':'NullPointerException'})
        if value is None:
            self.approximate=True
            self.warnings.add('null scalar conversion requires an unresolved source type: '+self.method)
        return value

    def primitive_value(self,value,typ):
        if value is None and typ in ('int','long','short','byte','float','double','char','boolean'):
            raise JavaThrow({'__type__':'NullPointerException'})
        return value

    def binary_unboxes(self,node,side):
        op=text(node.child_by_field_name('operator'))
        if op in ('==','!='):
            other=node.child_by_field_name('right' if side=='left' else 'left')
            return self.source_type(other) in ('int','long','short','byte','float','double','char','boolean')
        if op=='+':
            return not any(self.standard_type(self.source_type(node.child_by_field_name(key)),'java.lang.String')
                           for key in ('left','right'))
        return op in ('-','*','/','%','<','>','<=','>=','&','|','^','<<','>>','>>>','&&','||')

    def execute(self, node, env):
        if node is None:
            return U, None
        typ = node.type
        if typ in ('block', 'constructor_body'):
            names=[text(var.child_by_field_name('name')) for child in node.named_children
                   if child.type=='local_variable_declaration' for var in child.named_children if var.type=='variable_declarator']
            with self.binding_scope(env,names):
                for child in node.named_children:
                    value, control = self.execute(child, env)
                    if control:
                        return value, control
            return U, None
        if typ in ('return_statement', 'throw_statement'):
            value = self.value(node.named_children[0], env) if node.named_children else None
            if typ=='return_statement':value=self.primitive_value(value,self.p.methods[self.method].get('return_raw',''))
            if typ=='throw_statement' and value is None:value={'__type__':'NullPointerException'}
            return value, 'return' if typ == 'return_statement' else 'throw'
        if typ in ('switch_expression','switch_statement'):
            result,control = self.execute_switch(node,env)
            return (U,None) if control=='yield' else (result,control)
        if typ=='yield_statement':
            return self.value(node.named_children[0],env),'yield'
        if typ == 'if_statement':
            condition=node.child_by_field_name('condition')
            cond = self.unbox(self.value(condition, env),condition)
            self.conditions.append({'method': self.method, 'line': node.start_point.row + 1,
                                    'condition': text(node.child_by_field_name('condition')),
                                    'value': cond if isinstance(cond, bool) else 'unknown'})
            if isinstance(cond, bool):
                return self.execute(node.child_by_field_name('consequence' if cond else 'alternative'), env)
            decision = self.choose(self.method + ':' + str(node.start_point.row + 1), [True, False])
            if decision is not None:
                if self.use_constraints:
                    refined = assume(node.child_by_field_name('condition'), env, decision,
                                     self.variable_types, self.constraint_symbol)
                    self.conditions[-1]['refined'] = refined
                return self.execute(node.child_by_field_name('consequence' if decision else 'alternative'), env)
            before_state = self.state
            left,left_copies=clone_environment(env)
            right,right_copies=clone_environment(env)
            self.state = self.execution_fork(before_state)
            a, ac = self.execute(node.child_by_field_name('consequence'), left)
            left_state = self.state
            self.state = self.execution_fork(before_state)
            b, bc = self.execute(node.child_by_field_name('alternative'), right)
            right_state = self.state
            self.state = left_state
            # Keep agreed writes; conflicting contents are unavailable to queries.
            self.state.database.unknown_tables.update(left_state.database.unknown_tables | right_state.database.unknown_tables)
            for table in set(left_state.database.tables) | set(right_state.database.tables):
                if left_state.database.tables.get(table) != right_state.database.tables.get(table):
                    self.state.database.unknown_tables.add(table)
            self.state.symbol_sequence=max(left_state.symbol_sequence,right_state.symbol_sequence)
            self.state.input_sequence=max(left_state.input_sequence,right_state.input_sequence)
            join_environment(env,left,right,left_copies,right_copies,merge)
            return (merge(a, b), ac) if ac == bc and ac else (U, None)
        if typ == 'enhanced_for_statement':
            values = self.value(node.child_by_field_name('value'), env)
            name = text(node.child_by_field_name('name'))
            if self.commuting_map_copy(node,values,env):return U,None
            certain=isinstance(values,list) or isinstance(values,JavaMapView) and isinstance(values.backing.mapping,dict)
            items = self.view_items(values,env,self.method+':'+str(node.start_point.row+1),
                                    text(node.child_by_field_name('type')),self.source_type(node.child_by_field_name('value'))) if isinstance(values,JavaMapView) else values if isinstance(values,list) else [U]
            if isinstance(items,list) and len(items) > 64:
                self.approximate = True
                self.warnings.add('loop collection widened after 64 elements')
                items = items[:64] + [U]
            with self.binding_scope(env,[name]):
                self.variable_types[name]=text(node.child_by_field_name('type'))
                for item in items:
                    env[name] = self.primitive_value(item,self.variable_types[name])
                    result, control = self.execute(node.child_by_field_name('body'), env)
                    if control in ('return', 'throw') and certain:
                        return result, control
                    if control == 'break': break
            return U, None
        if typ in ('for_statement', 'while_statement', 'do_statement'):
            init = node.child_by_field_name('init')
            names=[text(var.child_by_field_name('name')) for var in init.named_children if var.type=='variable_declarator'] if init is not None and init.type=='local_variable_declaration' else []
            with self.binding_scope(env,names):
                if init: self.execute(init, env)
                condnode = node.child_by_field_name('condition')
                for iteration in range(64):
                    cond = self.unbox(self.value(condnode, env),condnode) if condnode else U
                    if cond is False and not (typ == 'do_statement' and iteration == 0): break
                    if cond is U:
                        decision = self.choose(self.method + ':loop:' + str(node.start_point.row + 1), [True, False])
                        if decision is False:
                            break
                        if decision is True:
                            cond = True
                        else:
                            self.uncertain += 1
                    result, control = self.execute(node.child_by_field_name('body'), env)
                    if cond is U: self.uncertain -= 1
                    if control in ('return', 'throw') and cond is True: return result, control
                    if control == 'break': break
                    update = node.child_by_field_name('update')
                    if update: self.value(update, env)
                    if cond is not True:
                        self.warnings.add('unknown loop bounded to one pass: ' + self.method)
                        break
                else:
                    self.approximate = True
                    self.warnings.add('loop bounded after 64 passes: ' + self.method)
                    self.fallback(self.method)
                return U, None
        if typ == 'try_statement' or typ == 'try_with_resources_statement':
            resources = node.child_by_field_name('resources')
            if resources:
                self.value(resources, env)
            try:
                result, control = self.execute(node.child_by_field_name('body'), env)
            except JavaThrow as exc:
                result, control = exc.value, 'throw'
            if control == 'throw':
                for child in node.named_children:
                    if child.type == 'catch_clause':
                        parameter = next(c for c in child.named_children if c.type=='catch_formal_parameter')
                        types = next(c for c in parameter.named_children if c.type=='catch_type')
                        thrown = exception_type(result)
                        matches = [assignable(thrown,self.catch_type(text(c)),self.p) for c in types.named_children]
                        match = True if True in matches else U if U in matches else False
                        if match is U:
                            self.approximate = True
                            self.warnings.add('unknown exception assignability: '+text(types)+' at '+self.method)
                            match = self.choose(self.method+':catch:'+str(child.start_point.row+1),[True,False])
                            if match is None:
                                self.fallback(self.method)
                                break
                        if match:
                            name=text(parameter.child_by_field_name('name'))
                            with self.binding_scope(env,[name]):
                                self.variable_types[name]=text(types)
                                env[name] = result
                                try:
                                    result, control = self.execute(child.child_by_field_name('body'), env)
                                except JavaThrow as exc:
                                    result,control = exc.value,'throw'
                            break
            for child in node.named_children:
                if child.type == 'finally_clause':
                    try:
                        final, fc = self.execute(child.named_children[-1], env)
                    except JavaThrow as exc:
                        final,fc = exc.value,'throw'
                    if fc:
                        return final, fc
            return result, control
        if typ == 'local_variable_declaration':
            for child in node.named_children:
                if child.type == 'variable_declarator':
                    name = text(child.child_by_field_name('name'))
                    self.variable_types[name] = text(node.child_by_field_name('type'))
                    env[name] = self.primitive_value(self.value(child.child_by_field_name('value'), env),self.variable_types[name])
            return U, None
        if typ in ('break_statement', 'continue_statement'):
            return U, 'break' if typ == 'break_statement' else 'continue'
        if typ in ('line_comment', 'block_comment'):
            return U, None
        return self.value(node, env), None

    def execute_switch(self,node,env):
        selected = self.value(node.child_by_field_name('condition'),env)
        groups = [g for g in node.child_by_field_name('body').named_children
                  if g.type not in ('line_comment','block_comment')]
        possible,default,unknown,found = [],None,selected is U,False
        for index,group in enumerate(groups):
            label = group.named_children[0]
            if text(label)=='default':
                default = index
                continue
            for case in label.named_children:
                value = self.value(case,env)
                if value is U and isinstance(selected,JavaEnumValue):
                    key = selected.enum_key.rsplit('.',1)[0]+'.'+text(case)
                    value = self.p.enum_objects.get(key,U)
                equal = key_equal(selected,value)
                if equal is True:
                    possible = [index]
                    found = True
                    break
                if equal is U:
                    unknown = True
                    possible.append(index)
            if found:
                unknown = False
                break
        if selected is None and not possible:
            raise JavaThrow({'__type__':'NullPointerException'})
        if unknown:
            choices = sorted(set(possible+[default if default is not None else -1]))
            start = self.choose(self.method+':switch:'+str(node.start_point.row+1),choices)
            if start is None:
                self.warnings.add('unresolved switch control flow: '+self.method)
                self.fallback(self.method)
                return U,None
        else:
            start = possible[0] if possible else default
        if start is None or start == -1:
            return U,None
        for group in groups[start:]:
            result = U
            for statement in group.named_children[1:]:
                result,control = self.execute(statement,env)
                if control == 'break':return U,None
                if control:return result,control
            if group.type=='switch_rule':
                return result,'yield'
        return U,None

    def value(self, node, env):
        if node is None:
            return U
        typ, raw = node.type, text(node)
        if typ == 'identifier':
            return env.get(raw, member(env.get('this'), raw))
        if typ in ('true', 'false'):
            return typ == 'true'
        if typ == 'null_literal':
            return None
        if typ == 'character_literal':
            content=raw[1:-1]
            if len(content)==1:return content
            if content=="\\'":return "'"
            if content=='\\s':return ' '
            if re.fullmatch(r'\\[0-7]{1,3}',content) and int(content[1:],8)<=255:return chr(int(content[1:],8))
            try:
                decoded=json.loads('"'+content+'"')
                if len(decoded.encode('utf-16-le',errors='surrogatepass'))==2:return decoded
            except ValueError:pass
            self.approximate=True
            self.warnings.add('unsupported Java character literal: '+self.method)
            return U
        if typ == 'string_literal':
            try:
                return json.loads(raw)
            except ValueError:
                return raw[1:-1]
        if typ in ('decimal_integer_literal', 'decimal_floating_point_literal'):
            try:
                return float(raw.rstrip('fFdD')) if '.' in raw else int(raw.rstrip('lL'))
            except ValueError:
                return U
        if typ == 'this':
            return env.get('this', U)
        if typ == 'parenthesized_expression':
            return self.value(node.named_children[-1], env)
        if typ == 'cast_expression':
            value = self.value(node.named_children[-1], env)
            target = text(node.child_by_field_name('type'))
            value=self.primitive_value(value,target)
            if isinstance(value,(JavaJsonMapper,JacksonFeature)):
                allowed=('java.lang.Object','java.io.Serializable')+(
                    ('com.fasterxml.jackson.databind.ObjectMapper','com.fasterxml.jackson.core.ObjectCodec','com.fasterxml.jackson.core.TreeCodec','com.fasterxml.jackson.core.Versioned')
                    if isinstance(value,JavaJsonMapper) else ('com.fasterxml.jackson.databind.DeserializationFeature','java.lang.Enum','java.lang.Comparable'))
                if any(self.standard_type(target,fqn) for fqn in allowed):return value
                meta=self.p.methods[self.method]
                if self.p.resolve_type(target,meta['module'],meta['file']) or target.endswith('[]') or target in ('int','long','short','byte','char','boolean','float','double') or self.standard_type(target,'java.lang.String'):
                    raise JavaThrow({'__type__':'ClassCastException'})
                self.json_issue('JSON codec reference cast is not proven compatible',self.method)
                self.fallback(self.method)
                return U
            if isinstance(value,(JavaMapView,JavaMapEntry,JavaMapIterator)):
                base,_=type_parts(target)
                allowed=['java.lang.Object']
                if isinstance(value,JavaMapView):
                    allowed+=['java.lang.Iterable','java.util.Collection','java.util.AbstractCollection']
                    if value.kind!='values':allowed+=['java.util.Set','java.util.AbstractSet']
                elif isinstance(value,JavaMapEntry):allowed+=['java.util.Map.Entry']
                else:allowed+=['java.util.Iterator']
                if any(self.standard_type(base,fqn) for fqn in allowed) or isinstance(value,JavaMapEntry) and base=='Map.Entry' and self.standard_type('Map','java.util.Map'):
                    return value
                meta=self.p.methods[self.method]
                owner=self.p.resolve_type(base,meta['module'],meta['file'])
                if owner or base in ('int','long','short','byte','char','boolean','float','double') or base.endswith('[]') or self.standard_type(base,'java.lang.String'):
                    raise JavaThrow({'__type__':'ClassCastException'})
                self.approximate=True
                self.warnings.add('Map view/entry/iterator reference cast is unresolved: '+self.method)
                self.fallback(self.method)
                return U
            if target=='char':
                source=self.source_type(node.named_children[-1])
                if type(value) is int:return chr(value%65536)
                if isinstance(value,str) and (source=='char' or self.standard_type(source,'java.lang.Character')) and len(value.encode('utf-16-le',errors='surrogatepass'))==2:return value
                self.approximate=True
                self.warnings.add('unsupported Java char conversion: '+self.method)
                return U
            if isinstance(value,(str,JsonText)):
                base=target.split('<',1)[0]
                meta=self.p.methods[self.method]
                owner=self.p.resolve_type(base,meta['module'],meta['file'])
                source_incompatible=owner and self.p.nodes[owner]['fqn'] not in ('java.lang.String','java.lang.Object')
                if source_incompatible or any(self.standard_type(base,'java.util.'+name) for name in ('Map','HashMap','LinkedHashMap')):
                    raise JavaThrow({'__type__':'ClassCastException'})
            if isinstance(value,JavaMap):
                meta=self.p.methods[self.method]
                owner=self.p.resolve_type(target,meta['module'],meta['file'])
                allowed=('java.util.Map','java.util.HashMap','java.util.AbstractMap',
                         'java.lang.Object','java.lang.Cloneable','java.io.Serializable')
                if any(self.standard_type(target,typ) for typ in allowed):return value
                if target.endswith('[]') or owner and not self.p.nodes[owner]['fqn'].startswith('java.'):
                    raise JavaThrow({'__type__':'ClassCastException'})
                self.approximate=True
                self.warnings.add('Java Map reference cast is not proven compatible: '+text(node))
                return U
            limits = {'byte': (-128, 127), 'short': (-32768, 32767),
                      'int': (-2147483648, 2147483647), 'long': (-9223372036854775808, 9223372036854775807)}
            if target in limits:
                if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
                    narrowed = int(value)
                    if limits[target][0] <= narrowed <= limits[target][1]:
                        return narrowed
                self.approximate = True
                self.warnings.add('unsupported numeric cast outside modeled finite range: ' + text(node))
                return U
            return value
        if typ == 'field_access':
            if raw in self.p.constants: return self.p.constants[raw]
            constants = {'Float.MAX_VALUE': 3.4028235e38, 'Double.MAX_VALUE': 1.7976931348623157e308,
                         'Long.MAX_VALUE': 9223372036854775807, 'Integer.MAX_VALUE': 2147483647}
            if raw in constants: return constants[raw]
            if raw.startswith(('HttpMethod.', 'HttpStatus.', 'Calendar.')):
                return raw.split('.')[-1]
            enum = self.p.enum_reference(raw, self.method)
            if enum:
                return deepcopy(self.p.enum_objects[enum])
            qualifier=node.child_by_field_name('object')
            field=text(node.child_by_field_name('field'))
            root=text(qualifier).split('.')[0]
            meta=self.p.methods[self.method]
            class_name=qualifier.type in ('identifier','scoped_identifier','field_access') and root not in env and root not in self.variable_types and root not in self.p.type_fields.get(meta['owner'],{})
            if field in JavaJsonMapper.defaults and ((class_name and self.standard_type(text(qualifier),'com.fasterxml.jackson.databind.DeserializationFeature'))
                    or self.standard_type(self.source_type(qualifier),'com.fasterxml.jackson.databind.DeserializationFeature')):
                if not class_name:self.value(qualifier,env)
                return JacksonFeature(field)
            obj = self.value(node.child_by_field_name('object'), env)
            field = text(node.child_by_field_name('field'))
            if obj is None:
                declared=self.source_type(node.child_by_field_name('object'))
                constant=self.p.constants.get(declared.split('.')[-1]+'.'+field,U)
                if constant is not U:return constant
                owner=self.p.resolve_type(declared,self.p.methods[self.method]['module'],self.p.methods[self.method]['file'])
                if field in self.p.type_fields.get(owner,{}) or declared.endswith('[]') and field=='length':
                    raise JavaThrow({'__type__':'NullPointerException'})
                self.approximate=True
                self.warnings.add('unresolved static/instance field access through null: '+raw)
            return len(obj) if isinstance(obj, list) and field == 'length' else member(obj, field)
        if typ == 'unary_expression':
            operand=node.child_by_field_name('operand') or node.named_children[-1]
            arg = self.unbox(self.value(operand, env),operand)
            if arg is U:
                return U
            if raw.startswith('!') and isinstance(arg, bool):
                return not arg
            if raw.startswith('-') and isinstance(arg, (int, float)):
                return self.narrow_integer(-arg,self.numeric_type(node)) if type(arg) is int else -arg
            self.approximate=True
            self.warnings.add('unsupported Java unary operation: '+raw)
            return U
        if typ == 'binary_expression':
            op = text(node.child_by_field_name('operator'))
            a = self.value(node.child_by_field_name('left'), env)
            if a is None and self.binary_unboxes(node,'left'):self.unbox(a,node.child_by_field_name('left'))
            if (op == '&&' and a is False) or (op == '||' and a is True):
                return a
            b = self.value(node.child_by_field_name('right'), env)
            if b is None and self.binary_unboxes(node,'right'):self.unbox(b,node.child_by_field_name('right'))
            if op == '&&' and b is False:
                return False
            if op == '||' and b is True:
                return True
            if a is U or b is U:
                if op=='+' and any(self.standard_type(self.source_type(node.child_by_field_name(side)),'java.lang.String') or
                                   is_symbolic(v) and v.get('__type__') in ('String','java.lang.String')
                                   for side,v in zip(('left','right'),(a,b))):
                    # String concatenation preserves its literal parts even
                    # when one operand's text (including delimiters) is unknown.
                    a={'__symbol__':self.constraint_symbol(),'__type__':'String'} if a is U else a
                    b={'__symbol__':self.constraint_symbol(),'__type__':'String'} if b is U else b
                else:return U
            # A Java char is represented by one UTF-16 code unit, but participates
            # in numeric promotion unless this is a source-typed String concat.
            operand_types=[self.numeric_type(node.child_by_field_name(side)) for side in ('left','right')]
            if all(t in ('byte','short','char','int','long','float','double') for t in operand_types):
                converted=[]
                for value,source_type in zip((a,b),operand_types):
                    if source_type=='char' and isinstance(value,str):
                        units=value.encode('utf-16-le',errors='surrogatepass')
                        if len(units)==2:value=int.from_bytes(units,'little')
                        else:
                            value=U;self.approximate=True
                            self.warnings.add('unresolved Java char code unit: '+self.method)
                    converted.append(value)
                a,b=converted
                if a is U or b is U:return U
            if op in ('==','!=') and any(isinstance(value,(JavaRecord,JavaMap,JavaMapView,JavaMapEntry,JavaMapIterator,JavaEnumValue,JavaTypeToken,JavaTypeFactory,JavaJsonMapper,JacksonFeature)) for value in (a,b)):
                equal=reference_equal(a,b)
                if equal is U:
                    self.approximate=True
                    self.warnings.add('unresolved Java reference identity: '+raw)
                return equal if equal is U or op=='==' else not equal
            if op=='+' and any(type(v) is dict and v.get('__type__') in ('String','java.lang.String')
                               and '__symbol__' in v for v in (a,b)):
                def string_part(value):
                    if value is None:return 'null'
                    if type(value) is bool:return str(value).lower()
                    if type(value) in (str,int):return str(value)
                    if isinstance(value,datetime):return java_date_text(value)
                    return value
                return concat_text(string_part(a),string_part(b))
            if any(is_symbolic(v) for v in (a, b)):
                if op in ('==','!='):
                    equal=key_equal(a,b)
                    if equal is not U:return equal if op=='==' else not equal
                if self.use_constraints:
                    constrained = compare(a, op, b)
                    if constrained is not U:
                        return constrained
                if op in ('==', '!=') and a == b:
                    return op == '=='
                return U
            if op in ('==','!=') and any(isinstance(v,dict) and '__type__' in v for v in (a,b)):
                if a is b:equal=True
                elif a is None or b is None or key_equal(a,b) is False:equal=False
                else:
                    equal=U
                    self.approximate=True
                    self.warnings.add('unresolved Java reference identity: '+raw)
                return equal if equal is U or op=='==' else not equal
            ops = {'==': operator.eq, '!=': operator.ne, '<': operator.lt, '>': operator.gt,
                   '<=': operator.le, '>=': operator.ge, '+': operator.add, '-': operator.sub,
                   '*': operator.mul, '/': operator.truediv, '&&': lambda x, y: x and y,
                   '||': lambda x, y: x or y}
            if op == '+' and (isinstance(a, str) or isinstance(b, str) or
                              (a is None or b is None) and any(self.standard_type(self.source_type(node.child_by_field_name(side)),'java.lang.String') for side in ('left','right'))):
                def scalar(value):
                    if value is None:return 'null'
                    if type(value) is bool:return str(value).lower()
                    if isinstance(value,(str,int)):return str(value)
                    if type(value) is float and math.isfinite(value) and 'e' not in repr(value):return str(value)
                    if isinstance(value,datetime):return java_date_text(value)
                    return U
                left,right=scalar(a),scalar(b)
                if left is U or right is U:
                    self.approximate=True
                    self.warnings.add('unsupported Java object string conversion: '+raw)
                    return U
                return concat_text(left,right)
            try:
                promoted=self.numeric_type(node)
                if op in ('+','-','*','/','%') and type(a) in (int,float) and type(b) in (int,float):
                    if promoted=='float' or (not promoted and (type(a) is float or type(b) is float)):
                        self.approximate=True
                        self.warnings.add('float rounding or floating-point source type is not modeled: '+raw)
                        return U
                    if promoted=='double':a,b=float(a),float(b)
                if op in ('/', '%') and type(a) is int and type(b) is int:
                    if b==0:raise JavaThrow({'__type__':'ArithmeticException'})
                    quotient = (abs(a) // abs(b)) * (-1 if (a < 0) != (b < 0) else 1)
                    return self.narrow_integer(quotient if op=='/' else a-quotient*b,self.numeric_type(node))
                if op in ops:
                    result=ops[op](a,b)
                    return self.narrow_integer(result,self.numeric_type(node)) if type(result) is int else result
                self.approximate = True
                self.warnings.add('unsupported Java binary operator: ' + op)
                return U
            except (TypeError, ValueError, ZeroDivisionError):
                self.approximate = True
                self.warnings.add('unsupported or failing Java arithmetic: ' + raw)
                return U
        if typ == 'update_expression':
            child = node.named_children[0]
            old = self.unbox(self.value(child, env),child)
            new = old + (1 if '++' in raw else -1) if isinstance(old, (int, float)) else U
            if type(new) is int:new=self.narrow_integer(new,self.numeric_type(child))
            if child.type == 'identifier': env[text(child)] = new
            return new if raw.startswith(('++', '--')) else old
        if typ == 'assignment_expression':
            lhs, rhs = node.child_by_field_name('left'), node.child_by_field_name('right')
            op = text(node.child_by_field_name('operator'))
            old = self.unbox(self.value(lhs, env),lhs) if op!='=' else U
            result = self.primitive_value(self.value(rhs, env),self.source_type(lhs))
            if op != '=':
                try: result = {'+=': operator.add, '-=': operator.sub}[op](old, result)
                except (KeyError, TypeError):
                    result = U;self.approximate=True
                    self.warnings.add('unsupported Java compound assignment: '+self.method)
                if type(result) is int:result=self.narrow_integer(result,self.numeric_type(lhs))
            if lhs.type == 'identifier':
                env[text(lhs)] = result
            elif lhs.type == 'field_access':
                obj = self.value(lhs.child_by_field_name('object'), env)
                if obj is None:
                    owner=self.p.resolve_type(self.source_type(lhs.child_by_field_name('object')),self.p.methods[self.method]['module'],self.p.methods[self.method]['file'])
                    if text(lhs.child_by_field_name('field')) in self.p.type_fields.get(owner,{}):
                        raise JavaThrow({'__type__':'NullPointerException'})
                    self.approximate=True
                    self.warnings.add('unresolved static/instance field write through null: '+text(lhs))
                if isinstance(obj, dict):
                    obj[text(lhs.child_by_field_name('field'))] = result
            return result
        if typ == 'ternary_expression':
            condition=node.child_by_field_name('condition')
            c = self.unbox(self.value(condition, env),condition)
            if isinstance(c, bool):
                return self.primitive_value(self.value(node.child_by_field_name('consequence' if c else 'alternative'), env),self.source_type(node))
            decision = self.choose(self.method + ':ternary:' + str(node.start_point.row + 1), [True, False])
            if decision is not None:
                return self.primitive_value(self.value(node.child_by_field_name('consequence' if decision else 'alternative'), env),self.source_type(node))
            self.uncertain += 1
            self.approximate = True
            result = merge(self.value(node.child_by_field_name('consequence'), deepcopy(env)),
                         self.value(node.child_by_field_name('alternative'), deepcopy(env)))
            self.uncertain -= 1
            return result
        if typ in ('switch_expression', 'switch_statement'):
            result,control = self.execute_switch(node,env)
            if control=='throw':raise JavaThrow(result)
            return result if control=='yield' else U
        if typ == 'lambda_expression':
            return ('lambda', node, dict(env), self.method, dict(self.variable_types))
        if typ in ('method_invocation', 'object_creation_expression'):
            return self.call(node, env)
        if typ == 'array_initializer':
            return [self.value(child, env) for child in node.named_children]
        if typ == 'array_access':
            arr = self.value(node.child_by_field_name('array'), env)
            idx = self.value(node.child_by_field_name('index'), env)
            if arr is None:raise JavaThrow({'__type__':'NullPointerException'})
            if isinstance(arr,list) and type(idx) is int and not 0<=idx<len(arr):
                raise JavaThrow({'__type__':'ArrayIndexOutOfBoundsException'})
            return arr[idx] if isinstance(arr, list) and isinstance(idx, int) and 0 <= idx < len(arr) else U
        if typ == 'expression_statement':
            return self.value(node.named_children[0], env)
        if typ=='class_literal':return JavaTypeToken(raw.removesuffix('.class'),self.p.methods[self.method],'Class')
        if typ in ('type_identifier', 'scoped_type_identifier', 'generic_type', 'class_literal', 'line_comment', 'block_comment'):
            return U
        self.approximate=True
        self.warnings.add('unsupported Java expression '+typ+': '+self.method+':'+str(node.start_point.row+1))
        for child in node.named_children:
            if child.type.endswith('statement') or child.type in ('block', 'local_variable_declaration'):
                self.execute(child, env)
            else:
                self.value(child, env)
        if typ in ('switch_expression', 'switch_statement'):
            self.warnings.add('switch alternatives conservatively retained: ' + self.method)
        return U

    def numeric_type(self,node):
        """Source types for Java integer promotion; values alone lose long vs int."""
        if node is None:return ''
        kind,raw=node.type,text(node)
        aliases={'Integer':'int','Long':'long','Short':'short','Byte':'byte','Double':'double','Float':'float','Character':'char','Boolean':'boolean'}
        if kind=='decimal_integer_literal':return 'long' if raw.lower().endswith('l') else 'int'
        if kind=='decimal_floating_point_literal':return 'float' if raw.lower().endswith('f') else 'double'
        if kind=='character_literal':return 'char'
        if kind in ('true','false'):return 'boolean'
        if kind=='identifier':
            info=self.p.type_fields.get(self.p.methods[self.method]['owner'],{}).get(raw,{})
            written=self.variable_types.get(raw,info.get('type',''))
            if self.has_type_variables(written,self.p.methods[self.method]):return ''
            typ=written.split('.')[-1]
            return aliases.get(typ,typ)
        if kind in ('parenthesized_expression','unary_expression','update_expression','expression_statement','yield_statement'):
            typ=self.numeric_type(node.named_children[-1])
            return 'int' if kind=='unary_expression' and typ in ('byte','short','char') else typ
        if kind=='cast_expression':return text(node.child_by_field_name('type'))
        if kind=='field_access':
            if raw.startswith(('Integer.','Long.')):return 'int' if raw.startswith('Integer.') else 'long'
            obj=node.child_by_field_name('object');field=text(node.child_by_field_name('field'))
            owner=self.p.methods[self.method]['owner'] if text(obj)=='this' else self.p.resolve_type(self.variable_types.get(text(obj),text(obj)),self.p.methods[self.method]['module'])
            info=self.p.type_fields.get(owner,{}).get(field,{})
            if self.has_type_variables(info.get('type',''),{'owner':info.get('declaring_type',owner)}):return ''
            typ=info.get('type','').split('.')[-1]
            return aliases.get(typ,typ) or ('int' if field=='length' else '')
        if kind=='binary_expression':
            op=text(node.child_by_field_name('operator'))
            if op in ('==','!=','<','>','<=','>=','&&','||'):return 'boolean'
            types=[self.numeric_type(node.child_by_field_name(side)) for side in ('left','right')]
            if op in ('+','-','*','/','%','&','|','^') and all(t in ('byte','short','char','int','long','float','double') for t in types):
                return next((t for t in ('double','float','long') if t in types),'int')
        if kind=='ternary_expression':
            types=[self.numeric_type(node.child_by_field_name(side)) for side in ('consequence','alternative')]
            if types[0] and types[0]==types[1]:return types[0]
            if all(t in ('int','long','float','double') for t in types):
                return next((t for t in ('double','float','long') if t in types),'int')
        if kind=='method_invocation':
            name=text(node.child_by_field_name('name'))
            inferred=self.source_type(node).split('.')[-1]
            if inferred:return aliases.get(inferred,inferred)
            site=self.p.site(self.method,node)
            declared=self.p.targets(self.method,site) if site else self.p.source_targets(self.method,node)
            meta=self.p.methods[self.method]
            owner=self.p.resolve_type(self.source_type(node.child_by_field_name('object')),meta['module'],meta['file'])
            arguments=node.child_by_field_name('arguments')
            arity=len(arguments.named_children) if arguments is not None else 0
            if declared or owner and self.p.inherited_methods(owner,name,arity):return ''
            if name in ('length','size','parseInt','intValue','indexOf'):return 'int'
            if name in ('parseLong','longValue','getTime'):return 'long'
            if name in ('parseDouble','doubleValue'):return 'double'
            if name in ('parseFloat','floatValue'):return 'float'
        if kind=='switch_expression':
            types=[]
            for group in node.child_by_field_name('body').named_children:
                if group.type=='switch_rule' and len(group.named_children)==2:
                    types.append(self.numeric_type(group.named_children[1]))
            if types and all(t in ('int','long','float','double') for t in types):
                return next((t for t in ('double','float','long') if t in types),'int')
        return ''

    def source_type(self,node):
        """Declared expression types, including bean fields and collection elements."""
        if node is None:return ''
        kind,raw=node.type,text(node)
        meta=self.p.methods[self.method]
        if kind=='string_literal':return 'java.lang.String'
        if kind=='character_literal':return 'char'
        if kind in ('true','false'):return 'boolean'
        if kind in ('decimal_integer_literal','decimal_floating_point_literal'):return self.numeric_type(node)
        if kind=='this':return self.p.nodes[meta['owner']]['fqn']
        if kind=='identifier':
            written=self.variable_types.get(raw,self.p.type_fields.get(meta['owner'],{}).get(raw,{}).get('type',''))
            return '' if self.has_type_variables(written,meta) else written
        if kind=='parenthesized_expression':return self.source_type(node.named_children[-1])
        if kind in ('cast_expression','object_creation_expression'):return text(node.child_by_field_name('type'))
        if kind=='array_access':return self.source_type(node.child_by_field_name('array')).removesuffix('[]')
        if kind=='binary_expression':
            if text(node.child_by_field_name('operator'))=='+':
                types=[self.source_type(node.child_by_field_name(side)) for side in ('left','right')]
                if any(self.standard_type(t,'java.lang.String') for t in types):return 'java.lang.String'
            return self.numeric_type(node)
        if kind=='unary_expression' and raw.startswith('!'):return 'boolean'
        if kind=='ternary_expression':
            types=[self.source_type(node.child_by_field_name(side)) for side in ('consequence','alternative')]
            if types[0] and types[0]==types[1]:return types[0]
            if all(self.standard_type(t,'java.lang.String') for t in types):return 'java.lang.String'
            return self.numeric_type(node)
        if kind not in ('method_invocation','field_access'):return ''
        obj=node.child_by_field_name('object')
        receiver=self.source_type(obj) if obj is not None else self.p.nodes[meta['owner']]['fqn']
        owner=self.p.resolve_type(receiver,meta['module'],meta['file'])
        if kind=='method_invocation':
            site=self.p.site(self.method,node)
            targets=self.p.targets(self.method,site) if site else self.p.source_targets(self.method,node)
            if not targets and owner is not None:
                name=text(node.child_by_field_name('name'))
                arguments=node.child_by_field_name('arguments')
                count=len(arguments.named_children) if arguments is not None else 0
                owners=set(self.p.type_parents.get(owner,set()))|{owner}
                targets=[target for target in self.p.by_name.get(name,[]) if self.p.methods[target]['owner'] in owners
                         and len(self.p.parameters(target))==count]
            types={self.source_return_type(target) for target in targets}
            if len(types)==1:return next(iter(types))
            name=text(node.child_by_field_name('name'))
            arguments=node.child_by_field_name('arguments')
            count=len(arguments.named_children) if arguments is not None else 0
            base,type_arguments=type_parts(receiver)
            native_entry=(self.standard_type(base,'java.util.Map.Entry') or base=='Map.Entry' and self.standard_type('Map','java.util.Map'))
            if native_entry and type_arguments and len(type_arguments)==2 and count==0 and name in ('getKey','getValue'):
                return type_arguments[0 if name=='getKey' else 1]
            if type_arguments:
                if name=='next' and count==0 and len(type_arguments)==1 and self.standard_type(base,'java.util.Iterator'):return type_arguments[0]
                if name=='iterator' and count==0 and len(type_arguments)==1 and any(self.standard_type(base,'java.util.'+kind) for kind in ('Set','Collection','List')):
                    return 'java.util.Iterator<'+type_arguments[0]+'>'
                if count==0 and len(type_arguments)==2 and any(self.standard_type(base,'java.util.'+kind) for kind in ('Map','HashMap','LinkedHashMap')):
                    if name=='keySet':return 'java.util.Set<'+type_arguments[0]+'>'
                    if name=='values':return 'java.util.Collection<'+type_arguments[1]+'>'
                    if name=='entrySet':return 'java.util.Set<java.util.Map.Entry<'+','.join(type_arguments)+'>>'
            shadowed=text(obj) in self.variable_types or text(obj) in self.p.type_fields.get(meta['owner'],{})
            if name=='asList' and count and not shadowed and self.standard_type(text(obj),'java.util.Arrays'):
                types={self.scalar_or_source_type(self.source_type(arg)) for arg in arguments.named_children}
                if len(types)==1 and '' not in types:return 'java.util.List<'+next(iter(types))+'>'
            if self.standard_type(receiver,'java.lang.String'):
                if (name=='substring' and count in (1,2)) or (name in ('toString','trim','toLowerCase','toUpperCase') and count==0):return 'java.lang.String'
                if name=='charAt' and count==1:return 'char'
                if name=='length' and count==0:return 'int'
                if (name in ('equals','equalsIgnoreCase','contains','startsWith','endsWith') and count==1) or (name=='isEmpty' and count==0):return 'boolean'
            if name=='get' and count==1 and owner is None:
                collection=re.fullmatch(r'(?:java\.util\.)?(?:List|ArrayList|LinkedList)\s*<\s*([\w.]+)\s*>',receiver)
                if collection:return collection[1]
                mapping=re.fullmatch(r'(?:java\.util\.)?(?:Map|HashMap|LinkedHashMap)\s*<\s*[\w.]+\s*,\s*([\w.]+)\s*>',receiver)
                if mapping:return mapping[1]
            if count==0 and name.startswith(('get','is')):
                name=name[3:] if name.startswith('get') else name[2:]
                field=name[:1].lower()+name[1:]
            else:return ''
        else:field=text(node.child_by_field_name('field'))
        pending,seen=[owner],set()
        while pending:
            current=pending.pop()
            if current is None or current in seen:continue
            seen.add(current)
            info=self.p.type_fields.get(current,{}).get(field)
            if info:return '' if self.has_type_variables(info['type'],{'owner':info.get('declaring_type',current)}) else info['type']
            pending.extend(self.p.resolve_type(parent,self.p.nodes[current]['module'],self.p.nodes[current]['file'])
                           for parent in self.p.framework_types.get(current,set()))
        return ''

    def map_key_type(self,node):
        """Use source types for boxing, never the shape of a Python scalar."""
        typ=self.source_type(node) or self.numeric_type(node)
        return self.native_scalar_type(typ) or 'unresolved'

    def native_scalar_type(self,typ):
        if typ in ('byte','short','char','int','long','float','double','boolean'):return typ
        for name in ('String','Integer','Long','Byte','Short','Character','Boolean','Double','Float'):
            if self.standard_type(typ,'java.lang.'+name):return name
        return ''

    def source_return_type(self,target):
        meta=self.p.methods[target]
        written=meta.get('return_raw','')
        if self.has_type_variables(written,meta):return ''
        if not re.fullmatch(r'[\w.]+',written):return written
        owner=self.p.resolve_type(written,meta['module'],meta['file'])
        if owner:return self.p.nodes[owner]['fqn']
        for name in ('String','Integer','Long','Byte','Short','Character','Boolean','Float','Double','Object'):
            if self.standard_type(written,'java.lang.'+name,meta):return 'java.lang.'+name
        return written

    def scalar_or_source_type(self,written):
        """Qualify a bounded generic argument in the current source namespace."""
        if not re.fullmatch(r'[\w.]+',written):return ''
        boxed={'byte':'Byte','short':'Short','int':'Integer','long':'Long','char':'Character',
               'boolean':'Boolean','double':'Double','float':'Float'}
        if written in boxed:return 'java.lang.'+boxed[written]
        meta=self.p.methods[self.method]
        if self.has_type_variables(written,meta):return ''
        owner=self.p.resolve_type(written,meta['module'],meta['file'])
        if owner:return self.p.nodes[owner]['fqn']
        for name in ('String','Integer','Long','Short','Byte','Character','Boolean','Double','Float','Object'):
            if self.standard_type(written,'java.lang.'+name):return 'java.lang.'+name
        return ''

    def stream_element_type(self,node):
        written=self.source_type(node)
        match=re.fullmatch(r'((?:java\.util\.)?(?:List|ArrayList|LinkedList))\s*<\s*([\w.]+)\s*>',written)
        if match and self.standard_type(match[1],'java.util.'+match[1].rsplit('.',1)[-1]):
            return self.scalar_or_source_type(match[2])
        return ''

    def narrow_integer(self,value,typ):
        bits={'byte':8,'short':16,'int':32,'long':64}.get(typ)
        if bits:return (value+(1<<(bits-1)))%(1<<bits)-(1<<(bits-1))
        self.approximate=True
        self.warnings.add('unknown Java integer width; numeric result retained as unknown: '+self.method)
        return U

    def catch_type(self,written):
        meta=self.p.methods[self.method]
        owner=self.p.resolve_type(written,meta['module'],meta['file'])
        if owner:return self.p.nodes[owner]['fqn']
        for fqn in NATIVE_TYPES.values():
            if self.standard_type(written,fqn):return fqn
        # Preserve explicit foreign imports instead of matching their short name.
        for node in self.p.trees[meta['file']].root_node.named_children:
            match=re.fullmatch(r'import\s+([\w.]+)\s*;',text(node)) if node.type=='import_declaration' else None
            if match and match[1].rsplit('.',1)[-1]==written:return match[1]
        return written

    def standard_type(self,name,fqn,meta=None):
        """A source-proven JDK type, rather than an unrelated namesake."""
        meta=self.p.methods[self.method] if meta is None else meta
        # Project source and namespaces are immutable during a run. Type proofs
        # are reused across paths, unlike values or local variable bindings.
        cache=self.p.__dict__.setdefault('_standard_type_cache',{})
        variables=self.type_variable_scope(meta)
        key=(name,fqn,meta['module'],meta['file'],tuple(sorted(variables)))
        if key not in cache:cache[key]=name not in variables and self.prove_standard_type(name,fqn,meta)
        return cache[key]

    def type_variable_scope(self,meta):
        owner=meta.get('owner')
        if owner is None:return frozenset()
        methods=self.p.__dict__.get('_method_meta_ids')
        if methods is None:
            methods={id(value):mid for mid,value in self.p.methods.items()}
            self.p._method_meta_ids=methods
        mid=methods.get(id(meta))
        cache=self.p.__dict__.setdefault('_type_variable_scope_cache',{})
        if mid in cache:return cache[mid]
        names=set(self.p.type_variables.get(owner,{}))
        node=self.p.ast.get(mid)
        parameters=node.child_by_field_name('type_parameters') if node is not None else None
        if parameters is not None:
            names.update(text(child) for par in parameters.named_children for child in par.named_children if child.type=='type_identifier')
        result=frozenset(names)
        if mid is not None:cache[mid]=result
        return result

    def has_type_variables(self,written,meta):
        variables=self.type_variable_scope(meta)
        return bool(variables and set(re.findall(r'(?<![\w.])[\w$]+',written)) & variables)

    def prove_standard_type(self,name,fqn,meta):
        if self.p.resolve_type(name,meta['module'],meta['file']):
            return False
        if name==fqn:return True
        if name!=fqn.rsplit('.',1)[-1]:return False
        imports=[match[1] for node in self.p.trees[meta['file']].root_node.named_children if node.type=='import_declaration'
                 for match in [re.search(r'\bimport\s+(?:static\s+)?([\w.*]+)\s*;',text(node))] if match]
        explicit=[item for item in imports if item.rsplit('.',1)[-1]==name]
        if explicit:return explicit==[fqn]
        return fqn.startswith('java.lang.') or fqn.rsplit('.',1)[0]+'.*' in imports

    def method_modifiers(self,target):
        source=self.p.ast.get(target)
        flags={keyword.type for child in source.named_children if child.type=='modifiers'
               for keyword in child.children if not keyword.is_named} if source is not None else set()
        if source is not None and source.parent.parent.type=='interface_declaration' and 'private' not in flags:
            flags.add('public')
        return flags

    def concrete_dispatch(self,owner,name,arity,targets,declared,reason):
        """Refine the supplied declaration by class and parameter signature."""
        anchors=[target for target in declared if target in self.p.methods] or targets
        if any(self.method_modifiers(target) & {'static','private'} for target in anchors):return targets
        ancestry,level=set(),[owner]
        levels=[]
        while level:
            levels.append(set(level));ancestry.update(level)
            level=sorted({parent for current in level for parent in self.p.type_parents.get(current,[]) if parent not in ancestry})
        signatures={self.p.dispatch_signature(target) for target in anchors}
        candidates=[target for target in self.p.by_name.get(name,[]) if self.p.methods[target]['owner'] in ancestry
                    and len(self.p.parameters(target))==arity and not self.p.methods[target].get('abstract')
                    and not self.method_modifiers(target) & {'static','private'}
                    and self.p.ix.unit_of(self.method) in self.p.ix.units.get(self.p.methods[target]['module'],())]
        if None in signatures or any(self.p.dispatch_signature(target) is None for target in candidates):
            self.approximate=True
            self.warnings.add('generic or unresolved dispatch signature; alternatives retained: '+reason)
            return sorted(set(targets)|set(candidates))
        selected=[]
        parents={}
        def ancestors(current):
            if current not in parents:
                found,pending=set(),list(self.p.type_parents.get(current,[]))
                while pending:
                    parent=pending.pop()
                    if parent in found:continue
                    found.add(parent);pending.extend(self.p.type_parents.get(parent,[]))
                parents[current]=found
            return parents[current]
        def package(target):
            return self.p.nodes[self.p.methods[target]['owner']]['fqn'].rpartition('.')[0]
        for anchor in anchors:
            if self.p.methods[anchor]['owner'] not in ancestry:
                self.approximate=True
                self.warnings.add('declared dispatch owner is not a proven receiver supertype: '+reason)
                return targets
            signature=self.p.dispatch_signature(anchor)
            eligible={anchor}
            matching=[target for target in candidates if self.p.dispatch_signature(target)==signature]
            changed=True
            while changed:
                changed=False
                for target in matching:
                    if target in eligible:continue
                    if any(self.p.methods[base]['owner'] in ancestors(self.p.methods[target]['owner'])
                           and (self.method_modifiers(base) & {'public','protected'} or package(base)==package(target))
                           for base in eligible):
                        eligible.add(target);changed=True
            for level in levels:
                nearest=[target for target in matching if target in eligible and self.p.methods[target]['owner'] in level]
                if nearest:
                    selected.extend(nearest)
                    break
        return sorted(set(selected)) or targets

    def map_initializer(self,node,args,env,reason):
        """Native Map subclasses with put-only instance blocks and no overrides."""
        typ=text(node.child_by_field_name('type'))
        base=typ.split('<',1)[0]
        if not any(self.standard_type(base,'java.util.'+name) for name in ('HashMap','LinkedHashMap')):return False,U
        handled,mapping=construct(typ,args,self.state.now)
        if not handled or not isinstance(mapping,JavaMap):return False,U
        body=next(child for child in node.named_children if child.type=='class_body')
        blocks=[child for child in body.named_children if child.type not in ('line_comment','block_comment')]
        if any(block.type!='block' for block in blocks):return False,U
        invocations=[]
        for block in blocks:
            for statement in block.named_children:
                if statement.type in ('line_comment','block_comment'):continue
                if statement.type!='expression_statement' or len(statement.named_children)!=1:return False,U
                call=statement.named_children[0]
                if call.type!='method_invocation' or text(call.child_by_field_name('name'))!='put' or text(call.child_by_field_name('object')) not in ('','this'):return False,U
                values=[child for child in call.child_by_field_name('arguments').named_children if child.type not in ('line_comment','block_comment')]
                if len(values)!=2:return False,U
                if any(child.type=='this' or child.type=='method_invocation' and child.child_by_field_name('object') is None
                       for value in values for child in walk(value)):return False,U
                invocations.append(values)
        for nodes in invocations:
            values=[self.value(value,env) for value in nodes]
            key_type=self.map_key_type(nodes[0])
            _,result=library('put',mapping,values,'this',self.state.now,key_type=key_type,value_type=self.map_key_type(nodes[1]))
            if result is U or any(value is U for value in values):
                self.approximate=True
                self.warnings.add('native Map initializer contains an unresolved key or value: '+reason)
                self.operation_issues[(mapping.last_issue or 'unknown_map_value','initializer.put')]+=1
        return True,mapping

    def call(self, node, env):
        mid = self.method
        site = self.p.site(mid, node)
        cs = self.p.nodes.get(site, {})
        name = '<init>' if node.type == 'object_creation_expression' else text(node.child_by_field_name('name'))
        objnode = node.child_by_field_name('object')
        obj = self.value(objnode, env) if objnode else env.get('this', U)
        argnode = node.child_by_field_name('arguments')
        declared=None
        args=[]
        for child in argnode.named_children if argnode else []:
            if child.type in ('line_comment','block_comment'):continue
            value=self.value(child,env)
            if value is None:
                if declared is None:declared=self.p.targets(mid,site) if site else self.p.source_targets(mid,node)
                parameters=[self.p.parameters(target) for target in declared]
                expected={pars[len(args)][1] for pars in parameters if len(pars)>len(args)}
                if len(expected)==1 and all(len(pars)>len(args) for pars in parameters):
                    value=self.primitive_value(value,next(iter(expected)))
            args.append(value)
        reason = site or f"{self.p.methods[mid]['file']}:{node.start_point.row + 1}"
        if name=='doFilter' and type(obj) is dict and '__filter_chain__' in obj:
            self.continue_filter(*obj['__filter_chain__'])
            return None
        if type(obj) is dict and obj.get('__type__')=='HttpServletResponse':
            if name in ('setStatus','sendError') and args:
                obj['status']=status_code(args[0])
                return None
            if name=='getStatus':return obj['status']
        wiring = self.p.edges.get(site, {})
        targets = self.p.targets(mid, site) if site else self.p.source_targets(mid, node)
        if not targets and not wiring.get('data_access'):
            targets=self.p.source_targets(mid,node)
        receiver_type = cs.get('receiver_type')
        if name=='<init>' and any(child.type=='class_body' for child in node.named_children):
            base,type_args=type_parts(text(node.child_by_field_name('type')))
            body=next(child for child in node.named_children if child.type=='class_body')
            if not args and type_args and len(type_args)==1 and type_args[0] and not any(child.type not in ('line_comment','block_comment') for child in body.named_children):
                for fqn in ('org.springframework.core.ParameterizedTypeReference','com.fasterxml.jackson.core.type.TypeReference'):
                    if self.standard_type(base,fqn):return JavaTypeToken(type_args[0],self.p.methods[mid],fqn.rsplit('.',1)[-1])
            handled,value=self.map_initializer(node,args,env,reason) if not targets else (False,U)
            if handled:return value
            self.approximate=True
            self.warnings.add('anonymous class construction or initializer is not modeled: '+reason)
            self.operation_issues[('unsupported_java_construction','anonymous_class')]+=1
            self.fallback(mid)
            return U
        if name != '<init>' and isinstance(obj,JavaObject) and text(objnode) != 'super':
            owner=self.p.resolve_type(obj.java_type,self.p.methods[mid]['module'],self.p.methods[mid]['file'])
            if owner and targets:
                targets=self.concrete_dispatch(owner,name,len(args),targets,wiring.get('calls',set()),reason)
        if objnode is not None and obj is None:
            static = targets and all('static' in self.method_modifiers(target) for target in targets)
            if not static:
                if targets or self.standard_type(self.source_type(objnode),'com.fasterxml.jackson.databind.ObjectMapper') or name in ('equals','equalsIgnoreCase','toString','length','isEmpty','isBlank','orElseThrow','getForObject','getForEntity','postForObject','postForEntity','exchange'):
                    raise JavaThrow({'__type__':'NullPointerException'})
                self.approximate=True
                self.warnings.add('unresolved static/instance invocation on null: '+reason)
                return U
        if not targets and name == 'builder' and receiver_type in self.p.builder_types:
            fields = self.p.builder_types[receiver_type]
            return {'__builder__': receiver_type, 'fields': {n: False if t == 'boolean' else 0 if t in ('int', 'long', 'double', 'float') else None for n, t in fields}}
        if not targets and type(obj) is dict and '__builder__' in obj:
            if name == 'build': return JavaRecord(obj['__builder__'],{'__type__': obj['__builder__'], **deepcopy(obj['fields'])},obj['fields'])
            if name in obj['fields'] and len(args) == 1:
                obj['fields'][name] = args[0]
                return obj
        if not targets and name == 'values' and not args:
            meta = self.p.methods[mid]
            tid = self.p.resolve_type(text(objnode), meta['module'], meta['file'])
            values = [deepcopy(self.p.enum_objects[key]) for key in self.p.enum_members.get(tid, [])]
            if values: return values
        if not targets and isinstance(obj,JavaEnumValue) and name=='name' and not args:return obj.enum_name
        if not targets and name == 'encode' and receiver_type and 'PasswordEncoder' in receiver_type and args and isinstance(args[0], str):
            # Abstract non-null encoding; no hashing or authentication is executed.
            return 'encoded:' + args[0]
        if not targets and isinstance(obj, dict) and (isinstance(obj,(JavaRecord,JavaEnumValue)) or type(obj) is dict and obj.get('__type__')) and name != '<init>':
            runtime_type = obj.declared_type if isinstance(obj,JavaRecord) else self.p.nodes[obj.enum_owner]['fqn'] if isinstance(obj,JavaEnumValue) else self.p.nodes[obj['__enum_type__']]['fqn'] if obj.get('__enum_type__') else obj['__type__']
            runtime_owner=self.p.resolve_type(runtime_type,self.p.methods[mid]['module'],self.p.methods[mid]['file'])
            targets = [m for m in self.p.inherited_methods(runtime_owner,name,len(args))
                       if not self.p.methods[m].get('abstract')
                       and self.p.ix.unit_of(mid) in self.p.ix.units.get(self.p.methods[m]['module'], ())]
        if name == '<init>':
            typ = text(node.child_by_field_name('type'))
            obj = {'__type__': typ}
            tid = self.p.resolve_type(typ, self.p.methods[mid]['module'], self.p.methods[mid]['file'])
            if tid:
                obj = JavaObject(self.p.nodes[tid]['fqn'],{'__type__': self.p.nodes[tid]['fqn'], '__http_entity__': False},wire_fields=self.p.type_fields.get(tid,{}))
            for field, info in self.p.type_fields.get(tid, {}).items():
                default = info['default']
                if default is U and not info['has_initializer']:
                    default = False if info['type'] == 'boolean' else 0 if info['type'] in ('int', 'long', 'double', 'float', 'short', 'byte') else None
                elif default is U:
                    self.approximate = True
                    self.warnings.add('unsupported instance initializer: ' + str(tid) + '.' + field)
                obj[field] = deepcopy(default)
            if typ.split('.')[-1] == 'UsernamePasswordAuthenticationToken':
                obj.update(principal=args[0] if args else U, credentials=args[1] if len(args) > 1 else U)
            if not tid and re.match(r'(ArrayList|LinkedList|List|HashSet|Set)', typ):
                obj = list(args[0]) if args and isinstance(args[0], list) else []
        if name == '<init>':
            base=typ.split('<')[0]
            if not tid and not targets and self.standard_type(base,'com.fasterxml.jackson.databind.ObjectMapper'):
                if not args:return JavaJsonMapper()
                self.json_issue('JSON mapper constructor overload is not modeled',reason)
                return U
            unresolved_map=not tid and base.rsplit('.',1)[-1] in ('Map','HashMap','LinkedHashMap') and not self.standard_type(base,'java.util.'+base.rsplit('.',1)[-1])
            handled, value = (True,U) if unresolved_map else construct(typ, args, self.state.now) if not tid and not targets else (False, U)
            if handled:
                obj = value
                if value is U:
                    self.approximate=True
                    self.warnings.add('unresolved modeled constructor: '+typ+' at '+reason)
            elif not targets and receiver_type in self.p.all_args_types:
                fields = self.p.all_args_types[receiver_type]
                if len(fields) == len(args): obj = JavaObject(self.p.nodes[tid]['fqn'],{'__type__': receiver_type, **{n: v for (n, _), v in zip(fields, args)}},wire_fields=self.p.type_fields.get(tid,{})) if tid else {'__type__': receiver_type, **{n: v for (n, _), v in zip(fields, args)}}
        if len(targets) > 1:
            selected = self.choose(reason + ':dispatch', targets)
            if selected is not None:
                targets = [selected]
            else:
                self.uncertain += 1
        result = U
        for target_index, target in enumerate(targets):
            self.add(mid, 'calls', target, reason)
            value = self.invoke(target, args, obj, reason)
            result = value if target_index == 0 else merge(result, value)
        if wiring.get('data_access'):
            return self.repository(mid, cs, args, sorted(wiring['data_access']), reason)
        remote = sorted(wiring.get('remote_call', set()) | wiring.get('message_delivery', set()))
        http_verb = (args[1] if name=='exchange' and len(args)>1 and isinstance(args[1],str) else
                     'GET' if name in ('getForObject','getForEntity') else
                     'POST' if name in ('postForObject','postForEntity') else None)
        url=args[0] if args else None
        client_type=self.source_type(objnode) or receiver_type
        is_http_client=(not targets and name in ('exchange','getForEntity','postForEntity','getForObject','postForObject')
                        and any(self.standard_type(client_type or '',fqn) for fqn in
                                ('org.springframework.web.client.RestTemplate','org.springframework.web.client.RestOperations')))
        if is_http_client and (isinstance(url,str) or is_symbolic(url)):
            url=self.expand_http_template(url,args,name,reason)
        address=self.request_address(url) if remote or is_http_client else None
        if isinstance(url,dict) and any(isinstance(part,dict) and part.get('__java_date_text__') for part in url.get('__text_parts__',[])):
            self.approximate=True
            self.warnings.add('Date URL path assumes a standard time zone abbreviation without path delimiters: '+reason)
        if not remote and is_http_client and address and address['hostname'] and address['segments'] is not None:
            remote = sorted(m for m in self.p.ix.handlers_for(http_verb, address['segments'], address['hostname'])
                            if self.p.enabled_type(self.p.methods[m]['owner']))
        if remote:
            if address and address['hostname'] and address['segments'] is not None:
                matched = {m for m in self.p.ix.handlers_for(http_verb, address['segments'], address['hostname'])
                           if self.p.enabled_type(self.p.methods[m]['owner'])}
                if http_verb is None:
                    self.approximate = True
                    self.warnings.add('unknown HTTP method: '+reason)
                remote = sorted(matched)
                if not remote:
                    self.approximate = True
                    self.warnings.add('known HTTP URL has no matching source handler: ' + reason)
            else:
                self.approximate = True
                self.warnings.add('remote target is approximated from static wiring: ' + reason)
            results = []
            request = args[2] if name == 'exchange' and len(args) > 2 else args[1] if name.startswith('post') and len(args) > 1 else None
            headers=header_values(request.get('headers',U)) if http_entity(request) else {}
            body = unwrap(request) if http_entity(request) else request if name.startswith('post') else None if request is None else U
            original_body=body
            try:body=self.json_wire(body,reason)
            except JavaThrow as failure:
                if isinstance(failure.value,dict) and failure.value.get('__serialization_failure__'):
                    self.warnings.add('default HTTP request serialization failed on cyclic object graph: '+reason)
                    raise JavaThrow({'__type__':'HttpMessageNotWritableException'})
                raise
            if isinstance(original_body,JavaEnumValue) and body is not U:body=JsonText(body)
            if len(remote) > 1:
                selected = self.choose(reason + ':remote', remote)
                if selected is not None:
                    remote = [selected]
                else:
                    self.uncertain += 1
            for target in remote:
                if address and address['hostname']:
                    module=self.p.methods[target]['module']
                    declared_names={module,*self.p.ix.units.get(module,())}
                    declared_names.update(str(item['value']) for item in self.p.config
                                          if item.get('module')==module and item['key'].endswith('application.name'))
                    if address['hostname'] not in declared_names:
                        self.approximate=True
                        self.warnings.add('HTTP host resolution uses a module-name heuristic: '+reason)
                try:response,entered = self.http_invoke(target,
                    lambda: self.request_arguments(target,url,headers,body,reason),reason)
                except JavaThrow as failure:
                    entered=getattr(failure,'http_entered',False)
                    response={'__type__':'ResponseEntity','__http_entity__':True,'body':U,
                              'status':self.server_error_status(target,failure)}
                if entered and self.p.ix.unit_of(mid)!=self.p.ix.unit_of(target):
                    self.add(mid,'remote',target,reason)
                status = response.get('status',U) if http_entity(response) else 200
                custom=self.p.ix.unit_of(mid) in self.p.custom_http_error_units
                if custom:
                    self.approximate=True
                    self.warnings.add('custom HTTP error handling is not modeled; return/throw are alternatives: '+reason)
                    rejected=self.choose(reason+':custom-http-error-policy',[True,False])
                    if rejected is True:raise JavaThrow(U)
                    if rejected is None:
                        self.fallback(mid)
                        response=U
                elif status is U:
                    self.approximate = True
                    self.warnings.add('unknown HTTP response status: '+reason)
                    rejected=self.choose(reason+':unknown-http-status-error',[True,False])
                    if rejected is True:raise JavaThrow(U)
                    if rejected is None:self.fallback(mid)
                elif status >= 400:
                    raise JavaThrow({'__type__':'HttpClientErrorException' if status<500 else 'HttpServerErrorException','status':status})
                try:payload=self.json_wire(unwrap(response),reason)
                except JavaThrow as failure:
                    if isinstance(failure.value,dict) and failure.value.get('__serialization_failure__'):
                        self.warnings.add('default HTTP JSON serialization failed on cyclic object graph: '+reason)
                        raise JavaThrow({'__type__':'HttpServerErrorException','status':500})
                    raise
                class_index=3 if name=='exchange' else 2 if name.startswith('post') else 1
                token=args[class_index] if len(args)>class_index else None
                allowed=('Class','ParameterizedTypeReference') if name=='exchange' else ('Class',)
                response_type=token.written if isinstance(token,JavaTypeToken) and token.kind in allowed else None
                type_context=token.context if response_type is not None else self.p.methods[mid]
                native_string=response_type is not None and self.standard_type(response_type,'java.lang.String',type_context)
                if native_string and type(payload) in (int,bool):payload=str(payload).lower()
                elif native_string and (type(payload) is float or is_symbolic(payload) and payload.get('__type__') not in ('String','java.lang.String')):
                    payload=JsonText(payload)
                if native_string and (isinstance(payload,(dict,list)) or isinstance(unwrap(response),JavaEnumValue)) and not isinstance(payload,JsonText) and not (type(payload) is dict and '__symbol__' in payload):
                    payload=JsonText(payload)
                elif not native_string and isinstance(payload,JsonText):
                    payload=payload.payload
                if response_type and not native_string:
                    def unresolved_json(message):
                        self.approximate=True
                        self.warnings.add(message+': '+reason)
                        self.operation_issues[('http_json_binding',message)]+=1
                    payload=decode_response(self.p,payload,response_type,type_context,self.standard_type,unresolved_json)
                if response_type is None:
                    self.json_issue('HTTP response type descriptor is not modeled',reason)
                    payload=U
                results.append(payload)
            value = results[0] if len(results) == 1 else U
            return {'__type__': 'ResponseEntity', '__http_entity__': True, 'body': value,'status':status if len(results)==1 else U} if name in ('exchange', 'getForEntity', 'postForEntity') else value
        if name == 'authenticate' and 'AuthenticationManager' in (cs.get('receiver_type') or ''):
            self.authentication(mid, args, reason)
        if name == '<init>':
            return obj
        if not targets and isinstance(obj,list) and name in ('contains','indexOf') and len(args)==1:
            return self.collection_membership(obj,args[0],name,reason)
        if not targets and name=='getClass' and not args and isinstance(obj,dict) and (isinstance(obj,JavaRecord) or type(obj) is dict and obj.get('__type__')):
            if isinstance(obj,JavaRecord) and not isinstance(obj,JavaObject):
                self.approximate=True
                self.warnings.add('DTO declared type does not prove its exact runtime class: '+reason)
                return U
            actual=obj.java_type if isinstance(obj,JavaObject) else obj['__type__']
            tid=self.p.resolve_type(actual,self.p.methods[mid]['module'],self.p.methods[mid]['file'])
            return {'__java_class__':self.p.nodes[tid]['fqn'] if tid else actual}
        if not targets and name=='equals' and len(args)==1 and isinstance(obj,JavaObject):
            owner=self.p.resolve_type(obj.java_type,self.p.methods[mid]['module'],self.p.methods[mid]['file'])
            pending,seen=[owner],set()
            while pending:
                current=pending.pop()
                if current in seen:continue
                seen.add(current)
                node=self.p.nodes.get(current,{})
                generated=any(a['name'].split('.')[-1] in ('Data','EqualsAndHashCode','Value') for a in node.get('annotations',[]))
                parents=self.p.framework_types.get(current,set())
                if generated or any(parent not in ('Object','java.lang.Object') and not self.p.resolve_type(parent,node.get('module'),node.get('file')) for parent in parents):
                    self.approximate=True
                    self.warnings.add('project or generated Object.equals implementation is unresolved: '+reason)
                    return U
                pending.extend(parent for parent in self.p.type_parents.get(current,[]) if parent not in seen)
            equal=reference_equal(obj,args[0])
            if equal is U:
                self.approximate=True
                self.warnings.add('Object.equals reference identity is unresolved: '+reason)
            return equal
        if not targets:
            handled, value = self.stream_call(name, obj, args, text(objnode), reason, env,
                                              self.stream_element_type(objnode) if name=='stream' else '')
            if handled:
                return value
        if not targets and isinstance(obj,JavaTypeFactory):
            if name=='constructParametricType' and len(args)>=2 and all(isinstance(arg,JavaTypeToken) and arg.kind=='Class' and arg.context==args[0].context for arg in args):
                return JavaTypeToken(args[0].written+'<'+','.join(arg.written for arg in args[1:])+'>',args[0].context,'JavaType')
            self.json_issue('JSON type factory overload or type context is not modeled',reason)
            return U
        if not targets and isinstance(obj,JavaJsonMapper):
            issue=lambda message:self.json_issue(message,reason)
            if name=='equals' and len(args)==1:
                equal=reference_equal(obj,args[0])
                if equal is U:issue('JSON mapper reference identity is unresolved')
                return equal
            if name=='getClass' and not args:return {'__java_class__':'com.fasterxml.jackson.databind.ObjectMapper'}
            handled,result=codec_operation(obj,name,args,issue)
            if handled:return result
            return codec_conversion(obj,name,args,self.p,self.standard_type,issue)
        if not targets and isinstance(obj,JacksonFeature):
            if name=='equals' and len(args)==1:
                equal=reference_equal(obj,args[0])
                if equal is U:self.json_issue('JSON feature enum reference identity is unresolved',reason)
                return equal
            if name=='name' and not args:return obj.name
            self.json_issue('JSON feature enum operation is not modeled: '+name,reason)
            return U
        if not targets and name in ('writeValueAsString','readValue','convertValue','getTypeFactory'):
            self.json_issue('JSON mapper ownership or configuration is not proven',reason)
            return U
        if not targets and isinstance(obj,JsonText):
            if name=='toString' and not args:return obj
            if name=='equals' and len(args)==1 and obj is args[0]:return True
            self.json_issue('JSON text scalar operation is not modeled: '+name,reason)
            return U
        if not targets and isinstance(obj,JavaEnumValue) and name=='equals' and len(args)==1:
            equal=reference_equal(obj,args[0])
            if equal is U:self.json_issue('enum reference identity is unresolved',reason)
            return equal
        if not targets and name=='equals' and isinstance(obj,JavaRecord):
            self.approximate=True
            self.warnings.add('DTO reference equality requires concrete runtime identity: '+reason)
            return U
        key_type=None
        value_type=None
        if isinstance(obj,(JavaMap,JavaMapView,JavaMapEntry,JavaMapIterator)) and args:
            first=next(child for child in argnode.named_children if child.type not in ('line_comment','block_comment'))
            key_type=self.map_key_type(first)
            nodes=[child for child in argnode.named_children if child.type not in ('line_comment','block_comment')]
            if name=='put' and len(nodes)==2:value_type=self.map_key_type(nodes[1])
            elif isinstance(obj,(JavaMapView,JavaMapEntry)):value_type=self.map_key_type(first)
        handled, value = library(name, obj, args, text(objnode), self.state.now,key_type=key_type,
                                 json_issue=lambda message:self.json_issue(message,reason),value_type=value_type,
                                 choose=lambda label,options:self.choose_map_order(reason+':'+label,options)) if not targets else (False, U)
        if handled:
            if value is not U and value is not None and not args and (
                    isinstance(obj,JavaMapEntry) and name in ('getKey','getValue') or
                    isinstance(obj,JavaMapIterator) and name=='next' and obj.view.kind!='entries'):
                mapping=obj.backing if isinstance(obj,JavaMapEntry) else obj.view.backing
                slot=mapping.slot(obj.key if isinstance(obj,JavaMapEntry) else obj.last)
                key_result=name=='getKey' or isinstance(obj,JavaMapIterator) and obj.view.kind=='keys'
                actual=slot.get('kind' if key_result else 'value_kind') if isinstance(slot,dict) else None
                expected=self.native_scalar_type(self.source_type(node))
                if expected and actual!=expected:
                    self.approximate=True
                    self.warnings.add('generic Map view read requires an unresolved implicit reference cast: '+reason)
                    self.operation_issues[('unresolved_collection_cast',name)]+=1
                    self.fallback(self.method)
                    return U
            if isinstance(obj,(JavaMap,JavaMapView,JavaMapEntry,JavaMapIterator)) and value is U:
                self.approximate=True
                self.warnings.add('Java Map operation remains unresolved: '+name+' at '+reason)
                kind=obj.last_issue or 'unknown_map_value'
                self.operation_issues[(kind,name)]+=1
            if type(obj) is dict and obj.get('__type__') in ('SimpleDateFormat','DecimalFormat') and name in ('format','parse'):
                self.approximate=True
                self.warnings.add('formatter default locale/time zone not supplied; numeric date fields and dot decimal symbols modeled: '+reason)
            return value
        if targets:
            return result
        if name.startswith(('get', 'is')) and not args:
            prop = name[3:] if name.startswith('get') else name[2:]
            prop = prop[:1].lower() + prop[1:]
            if isinstance(obj, dict):
                value = member(obj, prop)
                if value is not U:
                    return value
        if name.startswith('set') and len(args) == 1 and isinstance(obj, dict):
            prop = name[3:4].lower() + name[4:]
            obj[prop] = args[0]
            return None
        if result is not U:
            return result
        if name in ('orElseThrow','get') and optional_value(obj):
            value = member(obj, 'optional')
            if value is not U and value is not None:
                return value
            if value is U:
                self.approximate = True
                self.warnings.add('unknown Optional presence: '+reason)
                empty = self.choose(reason+':optional-empty',[True,False])
                if empty is False:return U
                if empty is None:self.fallback(self.method)
            for arg in args:
                if isinstance(arg, tuple) and arg[0] == 'lambda':
                    exception = self.callback_value(arg,[])
                    raise JavaThrow({'__type__':'NullPointerException'} if exception is None else exception)
            if args:
                if args[0] is None:raise JavaThrow({'__type__':'NullPointerException'})
                self.approximate=True
                self.warnings.add('unsupported exception supplier: '+reason)
                raise JavaThrow(U)
            raise JavaThrow({'__type__':'NoSuchElementException'})
        if name == 'isPresent' and optional_value(obj):
            val = member(obj, 'optional')
            return val is not None if val is not U else U
        if name in ('isEmpty', 'isBlank'):
            value = args[0] if args else obj
            return value is None or value == '' or value == [] if value is not U else U
        if name in ('equals', 'equalsIgnoreCase') and args:
            return (obj == args[0] if name == 'equals' else str(obj).lower() == str(args[0]).lower()) if known(obj) and known(args[0]) else U
        if name == 'startsWith' and args and isinstance(obj, str) and isinstance(args[0], str):
            return obj.startswith(args[0])
        if name == 'toString':
            return str(obj) if isinstance(obj, (str, int, float)) else U
        if name=='fromString' and not self.source_type(objnode) and self.standard_type(text(objnode),'java.util.UUID') and args:
            converted=uuid_value(args[0])
            if converted is not U:return converted
        if name=='parseInt' and not self.source_type(objnode) and self.standard_type(text(objnode),'java.lang.Integer'):
            if len(args) not in (1,2):
                self.approximate=True
                self.warnings.add('unsupported Integer.parseInt overload: '+reason)
                return U
            value=parse_integer(*args)
            if value is U:
                self.approximate=True
                self.warnings.add('Integer.parseInt value, radix or Unicode digit rules are unresolved: '+reason)
                valid=self.choose(reason+':parse-int-valid',[True,False])
                if valid is False:raise JavaThrow({'__type__':'NumberFormatException'})
                if valid is None:self.fallback(mid)
            return value
        if name in ('parseDouble', 'parseFloat') and args and args[0] is not U:
            try:
                return int(args[0]) if name == 'parseInt' else float(args[0]) if name in ('parseDouble', 'parseFloat') else args[0]
            except (ValueError, TypeError):
                return U
        if name == 'size' and isinstance(obj, list):
            return len(obj)
        if name == 'get' and isinstance(obj, list) and args and isinstance(args[0], int):
            if not 0<=args[0]<len(obj):raise JavaThrow({'__type__':'IndexOutOfBoundsException'})
            return obj[args[0]]
        if name in ('add', 'addAll') and isinstance(obj, list) and args:
            obj.extend(args[0] if name == 'addAll' and isinstance(args[0], list) else [args[0]])
            return True
        if name == 'randomUUID':
            if not self.source_type(objnode) and self.standard_type(text(objnode),'java.util.UUID'):
                return self.state.generated_value('UUID','java.util.UUID.randomUUID')
        if name not in ('debug', 'info', 'warn', 'error', 'trace', 'println', 'print'):
            for value in owned_objects([obj,*args]):
                if isinstance(value,JavaJsonMapper):value.invalidate()
            self.approximate = True
            self.warnings.add('unsupported call: ' + reason + ' ' + name)
            declared=self.source_type(objnode)
            kind=('unknown_receiver' if obj is U and declared else 'unresolved_external_type' if obj is U
                  else 'unresolved_source_method' if isinstance(obj,JavaObject)
                  else 'unsupported_collection_operation' if isinstance(obj,list)
                  else 'unresolved_object_model' if isinstance(obj,dict) else 'unsupported_library_operation')
            self.operation_issues[(kind,name)]+=1
        return U

    def choose_map_order(self,reason,options):
        self.approximate=True
        self.warnings.add('Map iteration or removal order is unspecified: '+reason)
        self.operation_issues[('unordered_map_iteration',reason.rsplit(':',1)[-1])]+=1
        return self.choose(reason,options)

    def widen_map_iteration(self,env,reason):
        self.approximate=True
        self.warnings.add('Map iteration budget or contents remain unresolved: '+reason)
        self.operation_issues[('unknown_map_iteration','foreach')]+=1
        for value in owned_objects(env):widen(value)
        self.fallback(self.method)

    def view_element(self,value,kind,target,contract,reason):
        if value is None or value is U:return self.primitive_value(value,target)
        _,arguments=type_parts(contract)
        expected=self.native_scalar_type(arguments[0]) if arguments and len(arguments)==1 else ''
        destination=self.native_scalar_type(target)
        if kind is not None and expected and expected!=kind:
            raise JavaThrow({'__type__':'ClassCastException'})
        aliases={'byte':'Byte','short':'Short','int':'Integer','long':'Long','char':'Character','boolean':'Boolean','float':'Float','double':'Double'}
        if destination in aliases:
            if kind is not None and kind!=aliases[destination] and not expected:
                self.approximate=True;self.warnings.add('unresolved raw collection scalar conversion: '+reason);return U
            widening={'Byte':('byte','short','int','long','float','double'),'Short':('short','int','long','float','double'),
                      'Character':('char','int','long','float','double'),'Integer':('int','long','float','double'),
                      'Long':('long','float','double'),'Float':('float','double'),'Double':('double',),'Boolean':('boolean',)}
            if kind not in widening or destination not in widening[kind] or destination=='float' or kind=='Float':
                self.approximate=True;self.warnings.add('unsupported collection scalar promotion: '+reason);return U
            if kind=='Character':
                if not isinstance(value,str) or len(value.encode('utf-16-le',errors='surrogatepass'))!=2:return U
                if destination!='char':value=int.from_bytes(value.encode('utf-16-le',errors='surrogatepass'),'little')
            return float(value) if destination=='double' else value
        if destination:
            if kind is None:
                self.approximate=True;self.warnings.add('unresolved collection boxed class: '+reason);return U
            if destination!=kind:raise JavaThrow({'__type__':'ClassCastException'})
        return value

    def view_items(self,view,env,reason,target='',contract=''):
        iterator=JavaMapIterator(view)
        if not isinstance(iterator.remaining,list):
            self.widen_map_iteration(env,reason);return
        count=len(iterator.remaining)
        for _ in range(min(count,64)):
            value=iterator_next(iterator,lambda label,options:self.choose_map_order(reason+':'+label,options))
            if iterator.last_issue:
                self.widen_map_iteration(env,reason);return
            slot=view.backing.slot(iterator.last)
            kind=slot.get('kind') if view.kind=='keys' else slot.get('value_kind') if view.kind=='values' else None
            value=self.view_element(value,kind,target,contract,reason)
            yield value
        if count>64:self.widen_map_iteration(env,reason)

    def commuting_map_copy(self,node,view,env):
        """Summarize only disjoint native writes dst.put(k, source.get(k))."""
        if not isinstance(view,JavaMapView) or view.kind!='keys':return False
        source=view.backing
        if not isinstance(source.mapping,dict) or source.flavor not in ('HashMap','LinkedHashMap'):return False
        body=node.child_by_field_name('body')
        if body.type=='block':
            statements=[child for child in body.named_children if child.type not in ('line_comment','block_comment')]
            if len(statements)!=1:return False
            body=statements[0]
        if body.type!='expression_statement' or len(body.named_children)!=1:return False
        put=body.named_children[0]
        if put.type!='method_invocation' or text(put.child_by_field_name('name'))!='put':return False
        receiver=put.child_by_field_name('object')
        arguments=put.child_by_field_name('arguments')
        if receiver is None or receiver.type!='identifier' or arguments is None:return False
        args=[child for child in arguments.named_children if child.type not in ('line_comment','block_comment')]
        name=text(node.child_by_field_name('name'))
        if len(args)!=2 or args[0].type!='identifier' or text(args[0])!=name:return False
        get=args[1]
        if get.type!='method_invocation' or text(get.child_by_field_name('name'))!='get':return False
        origin=get.child_by_field_name('object');lookup=get.child_by_field_name('arguments')
        if origin is None or origin.type!='identifier' or env.get(text(origin)) is not source or lookup is None:return False
        keys=[child for child in lookup.named_children if child.type not in ('line_comment','block_comment')]
        if len(keys)!=1 or keys[0].type!='identifier' or text(keys[0])!=name:return False
        destination=env.get(text(receiver))
        if not isinstance(destination,JavaMap) or not isinstance(destination.mapping,dict) or destination.flavor not in ('HashMap','LinkedHashMap'):return False
        kind=self.native_scalar_type(text(node.child_by_field_name('type')))
        entries=source.entries()
        # No implicit conversion, custom equality, abrupt completion or writes
        # through the iteration variable may be hidden by this proof.
        if not kind or kind[:1].islower() or len(entries)>10000:return False
        if any(entry['kind']!=kind or type(entry['key']) not in (str,int,bool) for entry in entries):return False
        slots=[destination.slot(entry) for entry in entries]
        if any(slot is U for slot in slots):return False
        new_keys=sum(slot is None for slot in slots)
        if not isinstance(source.order,list) and new_keys>1:destination.order=U
        for entry in entries:
            destination.put({'kind':entry['kind'],'key':entry['key']},entry['value'],entry.get('value_kind'))
        return True

    def collection_membership(self,items,value,name,reason):
        unknown=False
        for index,item in enumerate(items):
            equal=U
            if isinstance(value,dict) and '__type__' in value and '__symbol__' not in value:
                tid=self.p.resolve_type(value.declared_type if isinstance(value,JavaRecord) else value['__type__'],self.p.methods[self.method]['module'],self.p.methods[self.method]['file'])
                pending,seen=[tid],set()
                targets=[]
                while pending and not targets:
                    targets=[mid for mid in self.p.by_name.get('equals',[]) if self.p.methods[mid]['owner'] in pending
                             and self.p.methods[mid].get('params_as_written',[]) in (['Object'],['java.lang.Object'])
                             and not self.p.methods[mid].get('abstract')]
                    seen.update(pending)
                    pending=sorted({parent for owner in pending for parent in self.p.type_parents.get(owner,[]) if parent not in seen})
                if len(targets)==1:
                    equal=self.invoke(targets[0],[item],value,'Java collection equals callback at '+reason)
                else:
                    annotations=self.p.nodes.get(tid,{}).get('annotations',[])
                    has_generated=any(a['name'].split('.')[-1] in ('Data','EqualsAndHashCode') for a in annotations)
                    source=self.p.sources.get(self.p.nodes.get(tid,{}).get('file'),b'').decode()
                    generated=(has_generated and not any(a['name'].split('.')[-1]=='EqualsAndHashCode' and a.get('args') for a in annotations)
                               and not re.search(r'EqualsAndHashCode\.(?:Include|Exclude)',source))
                    if generated and not self.p.type_parents.get(tid):equal=key_equal(value,item)
                    elif value is item:equal=True
                    elif not has_generated and not targets and key_equal(value,item) is False:equal=False
            elif value is None:equal=item is None if item is not U else U
            elif not isinstance(value,dict) or '__symbol__' in value:equal=key_equal(value,item)
            if equal is U:
                unknown=True
                self.approximate=True
                self.warnings.add('collection equality is not fully known: '+reason)
            elif equal is True:
                return True if name=='contains' else U if unknown else index
        return U if unknown else False if name=='contains' else -1

    def stream_call(self, name, obj, args, receiver, reason, env,element_type=''):
        """Sequential lazy filter/map pipelines over a known ordered collection."""
        if name == 'stream' and isinstance(obj, list) and not args:
            return True, {'__stream__': obj, 'operations': [], 'linked': False, 'lifecycle': {'consumed': False},'element_type':element_type}
        if name == 'toList' and not args and receiver in ('Collectors', 'java.util.stream.Collectors'):
            meta = self.p.methods[self.method]
            source = text(self.p.trees[meta['file']].root_node)
            imported = bool(re.search(r'\bimport\s+java\.util\.stream\.(?:Collectors|\*)\s*;', source))
            shadowed = receiver in env or self.p.resolve_type(receiver, meta['module'], meta['file'])
            if not shadowed and (receiver.startswith('java.') or imported):
                return True, {'__collector__': 'java.util.stream.Collectors.toList'}
        if type(obj) is not dict or '__stream__' not in obj:
            return False, U
        if obj['lifecycle']['consumed'] or obj['linked']:
            self.approximate = True
            self.warnings.add('stream reused after consumption: ' + reason)
            return True, U
        if name in ('filter', 'map') and len(args) == 1 and isinstance(args[0], tuple) and args[0][0] == 'lambda':
            obj['linked'] = True
            incoming=obj.get('element_type','')
            outgoing=self.callback_return_type(args[0],incoming) if name=='map' else incoming
            return True, {**obj, 'linked': False, 'operations': [*obj['operations'], (name, args[0],incoming)],'element_type':outgoing}
        if name != 'collect' or args != [{'__collector__': 'java.util.stream.Collectors.toList'}]:
            self.approximate = True
            self.warnings.add('unsupported stream operation: ' + reason + ' ' + name)
            return True, U
        obj['lifecycle']['consumed'] = True
        if len(obj['__stream__']) > 10000:
            self.warnings.add('stream collection budget exceeded: ' + reason)
            self.fallback(self.method)
            return True, U
        output = []
        for item in obj['__stream__']:
            keep = True
            for operation, callback, input_type in obj['operations']:
                value = self.callback_value(callback, [item],input_type)
                if operation == 'map':
                    item = value
                    continue
                if type(value) is not bool:
                    value = self.choose(reason + ':stream-filter', [True, False])
                    if value is None:
                        self.warnings.add('unknown stream membership: ' + reason)
                        self.fallback(self.method)
                        return True, U
                if not value:
                    keep = False
                    break
            if keep:
                output.append(item)
        return True, output

    def callback_parameter_types(self,node,inferred):
        parameters=node.child_by_field_name('parameters')
        if parameters is None:return {}
        if parameters.type=='identifier':return {text(parameters):inferred} if inferred else {}
        result={text(par.child_by_field_name('name')):text(par.child_by_field_name('type'))
                for par in parameters.named_children if par.type=='formal_parameter'}
        if not result and inferred and len(parameters.named_children)==1:
            result[text(parameters.named_children[0])]=inferred
        return result

    def callback_return_type(self,callback,inferred):
        node,_,owner,types=callback[1:]
        previous,previous_types=self.method,self.variable_types
        self.method,self.variable_types=owner,{**types,**self.callback_parameter_types(node,inferred)}
        try:
            body=node.child_by_field_name('body')
            if body.type!='block':return self.scalar_or_source_type(self.source_type(body))
            def returns(current):
                if current.type in ('lambda_expression','class_body','method_declaration'):return
                if current.type=='return_statement' and current.named_children:
                    yield self.scalar_or_source_type(self.source_type(current.named_children[0]))
                else:
                    for child in current.named_children:yield from returns(child)
            types=set(returns(body))
            return next(iter(types)) if len(types)==1 else ''
        finally:self.method,self.variable_types=previous,previous_types

    def callback_value(self, callback, arguments,inferred=''):
        node, captured, owner, types = callback[1:]
        parameters = node.child_by_field_name('parameters')
        names = ([text(parameters)] if parameters is not None and parameters.type == 'identifier' else
                 [text(child.child_by_field_name('name') or child) for child in parameters.named_children]
                 if parameters is not None else [])
        if len(names) != len(arguments):
            self.approximate = True
            self.warnings.add('unsupported callback parameters: ' + text(node))
            return U
        local = {**captured, **dict(zip(names,arguments))}
        previous, previous_types = self.method, self.variable_types
        self.method, self.variable_types = owner, dict(types)
        self.variable_types.update(self.callback_parameter_types(node,inferred))
        try:
            body = node.child_by_field_name('body')
            if body.type != 'block':
                return self.value(body, local)
            value, control = self.execute(body, local)
            if control == 'throw':
                raise JavaThrow(value)
            return value if control == 'return' else U
        finally:
            self.method, self.variable_types = previous, previous_types

    def expand_http_template(self,url,args,name,reason):
        variables=args[4 if name=='exchange' else 3 if name.startswith('post') else 2:]
        mapping=variables[0].mapping if len(variables)==1 and isinstance(variables[0],JavaMap) else None
        if mapping is not None and not isinstance(mapping,dict):
            self.approximate=True
            self.warnings.add('unresolved Java Map URI variables: '+reason)
            return U
        configuration=self.p.__dict__.setdefault('_custom_uri_template_units',None)
        if configuration is None:
            configuration={self.p.ix.unit_of(site['method']) for site in self.p.nodes.values()
                           if site.get('kind')=='call_site' and site.get('callee') in ('setUriTemplateHandler','setEncodingMode','setParsePath','setDefaultUriVariables')
                           and site.get('method') in self.p.methods}
            self.p._custom_uri_template_units=configuration
        if self.p.ix.unit_of(self.method) in configuration:
            self.approximate=True
            self.warnings.add('custom URI template handler or encoding mode is not modeled: '+reason)
            return U
        if isinstance(url,str) and ('{' in re.sub(r'\{([A-Za-z_]\w*)\}','',url) or '}' in re.sub(r'\{([A-Za-z_]\w*)\}','',url)):
            self.approximate=True
            self.warnings.add('unsupported URI template syntax: '+reason)
            return U
        position=0
        def lookup(key):
            nonlocal position
            if mapping is not None and key not in mapping or mapping is None and position>=len(variables):
                raise JavaThrow({'__type__':'IllegalArgumentException'})
            value=mapping[key] if mapping is not None else variables[position]
            position+=1
            return value
        def unknown():
            self.approximate=True
            self.warnings.add('unresolved URI template value: '+reason)
            return {'__symbol__':self.constraint_symbol(),'__type__':'String'}
        return client_template(url,lookup,unknown)

    request_address = staticmethod(request_address)

    def route_path_values(self,target,address):
        if not address or address['segments'] is None:return None
        segments=address['segments']
        for mid, _, template in self.p.ix.handlers:
            if mid == target and len(template) == len(segments) and all(
                    key.startswith('{') or key in ('*', '**') or key == val for key, val in zip(template, segments)):
                if any(key.startswith('{') and ':' in key for key in template):
                    self.approximate=True
                    self.warnings.add('request route regular-expression constraints are not fully modeled: '+target)
                return {key[1:-1].split(':',1)[0]:deepcopy(value)
                        for key,value in zip(template,segments) if key.startswith('{')}
        return None

    def path_parameters(self, target, url):
        # Raw values for source grounding; actual HTTP conversion is deferred
        # until filters have admitted the request.
        address=self.request_address(url)
        values=self.route_path_values(target,address)
        if values is None:return {}
        path=dict(values)
        for par in self.p.http_parameters(target):
            if par['kind']=='PathVariable' and par['wire_name'] in path:
                values[par['name']]=path[par['wire_name']]
            elif par['kind']=='RequestParam':
                found=address['query'].get(par['wire_name']) if address['query_complete'] else U
                if found is U:values[par['name']]=U
                elif found is None or found==['']:
                    if par['default'] is not U:values[par['name']]=par['default']
                    elif found is None and not par['required']:values[par['name']]=None
                    elif found==['']:values[par['name']]=''
                else:values[par['name']]=found[0] if len(found)==1 else found
        return values

    def request_arguments(self,target,url,headers,body,reason):
        address=self.request_address(url)
        path=self.route_path_values(target,address)
        parameters={p['name']:p for p in self.p.http_parameters(target)}
        values=[]
        for name,typ in self.p.parameters(target):
            parameter=parameters.get(name,{})
            kind=parameter.get('kind')
            if http_headers_type(typ):
                value={'__type__':'HttpHeaders','__http_headers__':True,'headers':deepcopy(headers)}
            elif kind in ('PathVariable','RequestParam','RequestHeader'):
                wire_name=parameter['wire_name']
                if kind=='PathVariable':found=U if path is None else [path[wire_name]] if wire_name in path else None
                elif kind=='RequestParam':
                    found=address['query'].get(wire_name) if address and address['query_complete'] else U
                    media=headers.get('content-type',[]) if isinstance(headers,dict) else U
                    if body is not None and (media is U or any('form' in value or 'multipart' in value for value in media if isinstance(value,str))):
                        found=U
                else:
                    found=headers.get(wire_name.lower(),U if headers.get('__rest_unknown__') else None) if isinstance(headers,dict) else U
                value=bind_named(self,target,parameter,found)
            elif kind=='RequestBody':value=self.bind_http_body(body,typ,target,reason)
            else:
                value=body.payload if typ.split('.')[-1]!='String' and isinstance(body,JsonText) else body
                target_type=self.p.resolve_type(typ,self.p.methods[target]['module'],self.p.methods[target]['file'])
                if target_type in self.p.type_fields and isinstance(value,dict) and '__symbol__' not in value:
                    value={**self.p.request_body_defaults(target),**deepcopy(value)}
                    if '__type__' not in self.p.type_fields[target_type]:value['__type__']=self.p.nodes[target_type]['fqn']
                    if '__http_entity__' not in self.p.type_fields[target_type]:value['__http_entity__']=False
                    value=JavaRecord(self.p.nodes[target_type]['fqn'],value,self.p.type_fields[target_type])
            values.append(value)
        return values

    def authentication(self, mid, args, reason):
        module = self.p.methods[mid]['module']
        principal = member(args[0], 'principal') if args else U
        self.approximate = True
        self.warnings.add('authentication provider result is abstracted')
        for callback in self.p.by_name.get('loadUserByUsername', []):
            if self.p.methods[callback]['module'] == module and not self.p.methods[callback].get('abstract'):
                self.invoke(callback, [principal], reason='Spring authentication callback at ' + reason)
        for name in ('getPassword', 'getAuthorities', 'isAccountNonExpired', 'isAccountNonLocked', 'isCredentialsNonExpired', 'isEnabled'):
            for callback in self.p.by_name.get(name, []):
                meta = self.p.methods[callback]
                if meta['module'] == module and any(a.split('.')[-1] == 'UserDetails' for a in self.p.framework_types.get(meta['owner'], set())):
                    self.invoke(callback, [], reason='UserDetails authentication callback at ' + reason)

    def repository(self, mid, cs, args, resources, reason):
        result = U
        for rid in resources:
            self.add(mid, 'data', rid, reason)
            self.data_operations.append({'method': mid, 'resource': rid, 'operation': cs.get('callee'),
                                         'arguments': deepcopy(args), 'source_site': reason,
                                         'uncertain_write': bool(self.uncertain)})
            resource = self.p.nodes[rid]
            rows = self.state.database.rows(resource)
            if rows is None or resource.get('collection_of'):
                self.approximate = True
                self.warnings.add('ORM access is approximated from static mapping: ' + rid)
                continue
            name = cs.get('callee', '')
            entity = self.p.entities.get(rid)
            if name.startswith(('save', 'insert')) and args and isinstance(args[0], dict):
                record = deepcopy(args[0])
                if self.uncertain:
                    self.warnings.add('possible database write not committed: ' + reason)
                    self.state.database.invalidate(rows)
                else:
                    generated = self.p.generated_ids.get(rid)
                    if generated and record.get(generated, U) in (U, None):
                        field=self.p.type_fields.get(entity,{}).get(generated,{})
                        record[generated] = self.state.generated_value(field.get('type','Object'),'ORM generated identifier',
                                                                       [row.get(generated,U) for row in rows])
                        if field.get('uuid_generated') and field.get('type','').split('.')[-1]=='String':
                            record[generated].update(__uuid_text__=True,__length__=36,
                                                     __generation__='org.hibernate.id.UUIDGenerator')
                        args[0][generated] = record[generated]
                    keys = self.p.id_fields.get(rid, [])
                    key = tuple(record.get(k, U) for k in keys) if keys else U
                    existing = next((r for r in rows if key is not U and U not in key and all(self.p.materialize(self.state.database, rid, r).get(k, U) == record.get(k, U) for k in keys)), None)
                    if existing is None and keys and any(key_equal({k:self.p.materialize(self.state.database,rid,r).get(k,U) for k in keys},
                                                                 {k:record.get(k,U) for k in keys}) is U for r in rows):
                        self.approximate=True
                        self.warnings.add('opaque primary-key upsert overlap is not modeled; abstract write identity retained: '+reason)
                    if existing is None:
                        rows.append(record)
                        self.created_objects.append({**deepcopy(record), '__resource__': rid,
                                                     '__type__': self.p.nodes[entity]['fqn'] if entity else record.get('__type__', '')})
                    else:
                        existing.update(record)
                result = record
                continue
            selected = [self.p.materialize(self.state.database, rid, r) for r in rows]
            find = re.search(r'(?:find|query|get|delete|exists).*?By(.+)', name)
            unknown_query = False
            query_key = (cs.get('receiver_type'), name)
            declared_query = query_key in self.p.repository_queries
            query = self.p.repository_queries.get(query_key)
            primary_keys = self.p.id_fields.get(rid, [])
            pairs = []
            comparisons = []
            if declared_query:
                if query is None or any(int(index) > len(args) or int(index) < 1 for _, _, index in query):
                    unknown_query = True
                else:
                    from .state import camel
                    pairs = [(camel(field) + ('In' if op.lower() == 'in' else ''), args[int(index)-1])
                             for field, op, index in query if op.lower() in ('=','in')]
                    comparisons = [(camel(field),op,args[int(index)-1]) for field,op,index in query if op.lower() not in ('=','in')]
            elif name == 'findAllById' and args and isinstance(args[0], list):
                if len(primary_keys) == 1:
                    selected = [r for r in selected if r.get(primary_keys[0]) in args[0]]
                else:
                    unknown_query = True
            elif find:
                fields = re.split('And', find[1])
                pairs = [(field, value) for field, value in zip(fields, args)]
                if len(fields) != len(args):
                    unknown_query = True
                if name in ('findById', 'getById', 'getReferenceById', 'existsById', 'deleteById') and len(primary_keys) == 1 and args:
                    pairs = [(primary_keys[0], args[0])]
            elif name not in ('findAll', 'count'):
                unknown_query = True
            for field, value in pairs:
                in_query = field.endswith('In')
                field = field[:-2] if in_query else field
                prop = field[:1].lower() + field[1:]
                symbolic_query = is_symbolic(value)
                if not known(value) and not symbolic_query:
                    unknown_query = True
                else:
                    def matches(row):
                        nonlocal unknown_query
                        stored = member(row, prop)
                        if declared_query and (stored is None or value is None):
                            return False
                        if symbolic_query or isinstance(stored, dict) and '__symbol__' in stored:
                            equal = key_equal(stored, value)
                            if equal is U:
                                unknown_query = True
                            return equal is not False
                        if not known(stored):
                            unknown_query = True
                            return True
                        if isinstance(stored, dict) and isinstance(value, dict):
                            equal = key_equal(stored, value)
                            if equal is U: unknown_query = True
                            return equal is not False
                        return stored in value if in_query and isinstance(value, list) else stored == value
                    selected = [r for r in selected if matches(r)]
            for field,op,value in comparisons:
                kept=[]
                for row in selected:
                    stored=member(row,field)
                    # A SQL comparison involving NULL is never TRUE in WHERE.
                    if stored is None or value is None:
                        continue
                    numeric=all(type(item) in (int,float) and math.isfinite(item) for item in (stored,value))
                    if not numeric:
                        unknown_query=True
                        kept.append(row)
                        continue
                    passed={'>':operator.gt,'>=':operator.ge,'<':operator.lt,'<=':operator.le,'!=':operator.ne,'<>':operator.ne}[op](stored,value)
                    if passed:kept.append(row)
                selected=kept
            if (unknown_query and not declared_query and len(primary_keys)==1 and args and
                    name in ('findById','getById','getReferenceById','existsById')):
                exact=[row for row in selected if key_equal(member(row,primary_keys[0]),args[0]) is True]
                # A declared primary key is unique in a valid database state.
                # One exact symbolic identity excludes all other row identities.
                if len(exact)==1:selected,unknown_query=exact,False
            if unknown_query and not selected and ((declared_query and query is not None)
                    or not declared_query and find and len(pairs)==len(args)):
                unknown_query=False
            if unknown_query:
                self.approximate = True
                self.warnings.add('repository predicate is not fully modeled: ' + reason)
            if name.startswith('delete'):
                if not self.uncertain and not unknown_query:
                    if primary_keys:
                        removed = [tuple(row.get(key, U) for key in primary_keys) for row in selected]
                        rows[:] = [row for row in rows if tuple(self.p.materialize(self.state.database, rid, row).get(key, U)
                                                               for key in primary_keys) not in removed]
                    else:
                        self.approximate = True
                        self.warnings.add('deletion without an identifiable primary key: ' + reason)
                else:
                    self.warnings.add('possible deletion not committed: ' + reason)
                    self.state.database.invalidate(rows)
                result = None
                continue
            if name == 'count':
                result = len(rows); continue
            if name.startswith('exists'):
                result = U if unknown_query else bool(selected)
                continue
            materialized = []
            for row in selected:
                record = {'__type__': self.p.nodes[entity]['fqn'] if entity else '', **deepcopy(row)}
                if entity:record=JavaRecord(self.p.nodes[entity]['fqn'],record,self.p.type_fields.get(entity,{}))
                if entity:
                    for ctor in self.p.methods_of(entity, '<init>'):
                        if not self.p.methods[ctor].get('params_as_written'):
                            # Constructor is reached through materialization, not a direct project call.
                            if any(self.p.targets(ctor, site) for site in self.p.sites.get(ctor, [])):
                                self.invoke(ctor, [], deepcopy(record), 'entity materialization with project calls at ' + reason)
                materialized.append(record)
            if unknown_query:
                result = U
                continue
            # Repository declarations are indexed even though their bodies are abstract.
            declared_owner=self.p.resolve_type(cs.get('receiver_type',''),self.p.methods[mid]['module'],self.p.methods[mid]['file'])
            declared = [m.get('return_raw', '') for m in self.p.methods.values()
                        if m['name'] == name and m['owner']==declared_owner]
            return_type = declared[0] if declared else ('Optional' if name == 'findById' else '')
            first = materialized[0] if materialized else None
            result = {'__optional__': True, 'optional': first} if 'Optional' in return_type else materialized if any(t in return_type for t in ('List', 'Set', 'Collection')) or name == 'findAll' else first
        return result
