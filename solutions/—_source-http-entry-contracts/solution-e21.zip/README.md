# Решение №33

Редакция E21 сохраняет предыдущие source HTTP/Feign/Jackson исправления, целое JSON-тело и порядок полей. Добавлен ограниченный выбор singular GET по типу и завершённым response producers. 2370 тестов кода и 17 интеграционных запусков проходят; восемь ответов Train Ticket совпадают с E14. Полные независимые semantic transfer проверки ещё не завершены.

Python-анализатор исходного кода Java/Spring. Вход — исходники, готовый skeleton, сценарии и начальное состояние данных. Исследуемые приложения не запускаются. Стандартный режим не требует локальной модели, сети или внешнего LLM API.

Проверенное окружение: Python 3.11.9 и версии из requirements.txt. Из корня распакованного решения:

```sh
python -m pip install -r requirements.txt
python -B code/offline_run.py --source /path/to/source --skeleton /path/to/skeleton.json.gz --context /path/to/context --scenarios /path/to/scenarios --output /tmp/answer33.json --report /tmp/report33.json
python -B -m pytest -q -p no:cacheprovider code/tests
```

submission.json расположен в корне. SHA256 ответа: `95927fa5eb50b7d9f26d13a1c9e224bb2b803a9a6b07aa1c42996beaa15c371d`. Открытый S0: 0,8008928571428572; score сайта не получен. Полная совместимость Java/Spring и универсальность не заявлены. Неопределённые значения и неподдержанные механизмы отражаются в отчёте; потенциальное ребро скелета не считается доказательством выполнения.

Полный causal review, модельные эксперименты, частичные transfer oracle и команды before/after поставляются в отдельном аналитическом архиве. В этом компактном архиве находятся текущий код, его тесты, requirements и готовый ответ. Его README — эта компактная инструкция, а не полный рабочий отчёт.
