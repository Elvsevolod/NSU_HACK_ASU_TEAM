from analyzer.contracts import ContractGrounder, ContractIndex, explicit_value
from analyzer.frontend import Frontend
from analyzer.provenance import history_value
from analyzer.scenario_literals import structured_bindings
from analyzer.state import ScenarioState, U
from builders import build


def test_explicit_chain_and_numeric_csv_use_declared_split_fields(tmp_path):
    project, _, ids = build(tmp_path, {'Api.java': '''class Api {
      @PostMapping("/itineraries") String add(@RequestBody ItineraryInput input){return input.locationList;}
    } class ItineraryInput {
      String startLocation;String endLocation;String viaLocation;String locationList;String durationList;
      List<String> getLocations(){return Arrays.asList(locationList.split(","));}
      List<String> getDurations(){return Arrays.asList(durationList.split(","));}
    }'''})
    bindings=structured_bindings(project,ids['Api.add'],
        'Add itinerary North Harbor — Mid Park — West Point with durations 0, 10 and 25')
    assert {key:value[0] for key,value in bindings.items()} == {
        'startLocation':'North Harbor','endLocation':'West Point','viaLocation':'Mid Park',
        'locationList':'North Harbor,Mid Park,West Point','durationList':'0,10,25'}
    assert 'getLocations' in bindings['locationList'][1]
    assert 'getDurations' in bindings['durationList'][1]


def test_csv_shape_is_not_assumed_from_field_name_alone(tmp_path):
    project, _, ids=build(tmp_path,{'Api.java':'''class Api {
      @PostMapping("/itineraries") String add(@RequestBody ItineraryInput input){return input.locationList;}
    } class ItineraryInput {String startLocation;String endLocation;String locationList;String durationList;}'''})
    values=structured_bindings(project,ids['Api.add'],'Add itinerary A → B with durations 0 and 10')
    assert 'locationList' not in values and 'durationList' not in values


def test_field_label_projection_is_unique_and_times_do_not_gain_invented_dates(tmp_path):
    project, _, ids=build(tmp_path,{'Api.java':'''class Api {
      @PostMapping("/runs") String add(@RequestBody Run input){return input.startTime;}
    } class Run {String startTime;String endTime;double basePriceRate;double priorityPriceRate;}'''})
    values=structured_bindings(project,ids['Api.add'],
        'Add run with base rate 0.5, priority rate 1.2, departing 09:00 and arriving 12:00')
    assert {key:item[0] for key,item in values.items()}=={
        'basePriceRate':0.5,'priorityPriceRate':1.2,'startTime':'09:00','endTime':'12:00'}
    assert explicit_value('rate 1 and rate unknown','rate','int')==(U,'')


def test_declared_name_reference_uses_matching_entity_only(tmp_path):
    project, _, ids=build(tmp_path,{'Api.java':'''class Api {
      @PostMapping("/runs") String add(@RequestBody Run input){return input.deviceTypeName;}
    } class Run {String deviceTypeName;}
    class DeviceType {String name;} class ReaderType {String name;}'''})
    history=[{'result':{'__type__':'ReaderType','name':'wrong'}}]
    assert history_value(project,ids['Api.add'],'deviceTypeName','Add run',history) is None
    history.append({'result':{'__type__':'DeviceType','name':'Portable'}})
    assert history_value(project,ids['Api.add'],'deviceTypeName','Add run',history)[1]=='Portable'


def test_structured_literals_are_used_by_grounder_without_ui(tmp_path):
    project, db, _=build(tmp_path,{'Api.java':'''class Api {
      @PostMapping("/experiments") int add(@RequestBody Experiment input){return input.temperatures.size();}
    } class Experiment {List<Integer> temperatures;}'''})
    frontend=Frontend(project)
    choices,_=ContractGrounder(project,frontend,ContractIndex(project,frontend),None,{'facts':{}}).step(
        'Add experiment with temperatures 0, 100 and 250',ScenarioState(db))
    assert choices[0]['params']=={'temperatures':[0,100,250]}


def test_status_and_state_labels_share_source_enum_without_business_codes(tmp_path):
    from analyzer.request_semantics import filter_bindings
    project, _, ids=build(tmp_path,{'Api.java':'''class Api {
      @PostMapping("/parcels/query") int query(@RequestBody ParcelInfo input){return input.state;}
    } class ParcelInfo {boolean enabled;int state;void enableStateQuery(int state){enabled=true;this.state=state;}}
    enum ParcelStatus {CANCEL(37);int code;ParcelStatus(int code){this.code=code;}}'''})
    values=filter_bindings(project,ids['Api.query'],"List parcels filtered by the 'Cancel' status")
    assert {k:v for k,v,_,_ in values}=={'enabled':True,'state':37}


def test_boolean_string_predicate_requires_source_conversion(tmp_path):
    project, _, ids=build(tmp_path,{'Api.java':'''class Api {
      @GetMapping("/quotes/{isInRegion}") boolean quote(@PathVariable String isInRegion){return Boolean.parseBoolean(isInRegion);}
      @GetMapping("/records/{isInRegion}") String lookup(@PathVariable String isInRegion){return isInRegion;}
    }'''})
    assert structured_bindings(project,ids['Api.quote'],'Check quote in the region')['isInRegion'][0]=='true'
    assert structured_bindings(project,ids['Api.quote'],'Check quote not in the region')['isInRegion'][0]=='false'
    assert 'isInRegion' not in structured_bindings(project,ids['Api.quote'],'Check quote')
    assert 'isInRegion' not in structured_bindings(project,ids['Api.lookup'],'Read record in the region')


def test_reverse_numeric_description_uses_typed_source_aliases(tmp_path):
    project, _, ids=build(tmp_path,{'Api.java':'''class Api {
      @PostMapping("/batches") int add(@RequestBody Batch input){return input.premiumSlots;}
    } class Batch {int premiumSlots;int standardSlots;}
    class Reader {int read(Batch input){int priorityTotalCount=input.getPremiumSlots();
      int ordinaryTotalCount=input.getStandardSlots();return priorityTotalCount;}}'''})
    values=structured_bindings(project,ids['Api.add'],'Add batch with 30 priority and 100 ordinary slots')
    assert {k:v[0] for k,v in values.items()}=={'premiumSlots':30,'standardSlots':100}
    assert all('Reader#read' in item[1] for item in values.values())
    assert 'premiumSlots' not in structured_bindings(project,ids['Api.add'],'Add batch with 30 priority and 45 priority slots')


def test_reference_spelling_comes_from_matching_entity_not_arbitrary_strings(tmp_path):
    from analyzer.scenario_literals import canonical_reference
    project, db, ids=build(tmp_path,{'Api.java':'''class Api {
      @PostMapping("/itineraries") String add(@RequestBody Itinerary input){return input.startLocation;}
    } class Itinerary {String startLocation;String locationList;List<String> getLocations(){return Arrays.asList(locationList.split(","));}}
    @Entity @Table(name="locations") class Location {@Id String id;String name;}
    @Entity @Table(name="readers") class Reader {@Id String id;String name;}
    '''},rows={'locations':[{'id':'a','name':'northharbor'}],'readers':[{'id':'r','name':'LittleBay'}]})
    assert canonical_reference(project,ids['Api.add'],'startLocation','North Harbor',db)[0]=='northharbor'
    assert canonical_reference(project,ids['Api.add'],'locationList','North Harbor,Little Bay',db)[0]=='northharbor,Little Bay'
    assert canonical_reference(project,ids['Api.add'],'startLocation','Little Bay',db) is None
    assert canonical_reference(project,ids['Api.add'],'name','North Harbor',db) is None
    assert canonical_reference(project,ids['Api.add'],'locationId','North Harbor',db) is None


def test_unqualified_middle_location_is_not_last_created_destination(tmp_path):
    project, db, ids=build(tmp_path,{'Api.java':'''class Api {
      @PostMapping("/shipments") String add(@RequestBody Shipment input){return input.hubsName;}
    } class Shipment {String startHubName;String terminalHubName;String hubsName;}
    class Hub {String name;}'''})
    state=ScenarioState(db)
    state.history=[{'action':'Add hub','result':{'__type__':'Hub','name':'West Point'}}]
    frontend=Frontend(project)
    grounder=ContractGrounder(project,frontend,ContractIndex(project,frontend),None,{'facts':{}})
    choices,_=grounder.step('Add shipment from North Harbor via Mid Park to West Point',state)
    assert choices[0]['params']=={'startHubName':'North Harbor','hubsName':'Mid Park','terminalHubName':'West Point'}
    assert history_value(project,ids['Api.add'],'hubsName','Add shipment',state.history) is None


def test_ordinal_type_uses_source_enum_order_and_arbitrary_codes(tmp_path):
    from analyzer.request_semantics import enum_ordinal_binding
    sources={'Api.java':'''class Api {int add(@RequestBody Parcel input){return input.coating;}}
      class Parcel {int coating;int packaging;}
      enum CoatingType {GOLD(17),SILVER(43);int code;CoatingType(int code){this.code=code;}}
      class Catalog {List<CoatingType> list(){List<CoatingType> output=new ArrayList<>();
        for(CoatingType item:CoatingType.values()){output.add(item);} return output;}}'''}
    project, _, ids=build(tmp_path,sources)
    assert enum_ordinal_binding(project,ids['Api.add'],'coating','Add parcel with coating of the second type',[ids['Catalog.list']],'code')[0]==43
    assert enum_ordinal_binding(project,ids['Api.add'],'packaging','Add parcel with coating of the second type') is None
    sources['Api.java']=sources['Api.java'].replace('return output;','Collections.reverse(output); return output;')
    reversed_project, _, reversed_ids=build(tmp_path/'reversed',sources)
    assert enum_ordinal_binding(reversed_project,reversed_ids['Api.add'],'coating','Add parcel with coating of the first type',[reversed_ids['Catalog.list']],'code') is None
    sources['Api.java']+='''class Unrelated {List<CoatingType> all(){List<CoatingType> output=new ArrayList<>();
      for(CoatingType item:CoatingType.values()){output.add(item);}return output;}}'''
    competing, _, competing_ids=build(tmp_path/'competing',sources)
    assert enum_ordinal_binding(competing,competing_ids['Api.add'],'coating','Add parcel with coating of the first type',[competing_ids['Catalog.list']],'code') is None
    sources['Api.java']=sources['Api.java'].replace('Collections.reverse(output); ', '').replace(
        'output.add(item);','if(item.code>20){output.add(item);}')
    filtered, _, filtered_ids=build(tmp_path/'filtered',sources)
    assert enum_ordinal_binding(filtered,filtered_ids['Api.add'],'coating','Add parcel with coating of the first type') is None


def test_partial_constructor_does_not_erase_independent_literal_defaults(tmp_path):
    project, db, _=build(tmp_path,{'Api.java':'''class Api {
      @PostMapping("/records") String add(@RequestBody RecordInput input){return input.ownerId;}
    } class RecordInput {String ownerId;String timestamp;
      RecordInput(){this.ownerId="";this.timestamp=Clock.format(new Date());}}
    class Clock {static String format(Date date){return "now";}}'''})
    (tmp_path/'ui.js').write_text('''$.ajax({url:"/records",type:"POST",data:{}});''')
    frontend=Frontend(project)
    choices,_=ContractGrounder(project,frontend,ContractIndex(project,frontend),None,{'facts':{}}).step('Add record',ScenarioState(db))
    assert choices[0]['params']=={'ownerId':''}
    assert choices[0]['unresolved']==[]
    assert choices[0]['body_omissions']=={'input':['ownerId','timestamp']}


def test_enum_scalar_binding_does_not_replace_custom_getter_or_typed_enum(tmp_path):
    from analyzer.request_semantics import enum_scalar_binding
    sources={'Api.java':'''class Api {boolean add(@RequestBody Input input){return input.getTier()==Tier.PREMIUM.getCode();}}
      class Input {int tier;int getTier(){return tier;}}
      enum Tier {PREMIUM(17);int code;Tier(int code){this.code=code;}int getCode(){return code+100;}}'''}
    project, _, ids=build(tmp_path,sources)
    assert enum_scalar_binding(project,ids['Api.add'],'tier','Add premium tier') is None
    sources['Api.java']=sources['Api.java'].replace('input.getTier()==Tier.PREMIUM.getCode()','input.getTier()==Tier.PREMIUM').replace('int tier;int getTier()','Tier tier;Tier getTier()')
    typed, _, typed_ids=build(tmp_path/'typed',sources)
    assert enum_scalar_binding(typed,typed_ids['Api.add'],'tier','Add premium tier') is None
