"""Standard HashSet with known scalar equality, without an encounter order."""
from .native_storage import JavaList
from .boxed_values import boxed_equal
from .state import U
from .set_keys import hash_value,equal as key_equal,stop,SCALARS


def shapes(value,path='body',seen=None):
    seen=set() if seen is None else seen
    if not isinstance(value,(dict,list)) or id(value) in seen:return []
    seen.add(id(value));result=[]
    if isinstance(value,JavaList) and not value.order_known:
        result.append({'path':path,'size':None if value.opaque else len(value),'order':'unspecified'})
    children=value.items() if isinstance(value,dict) else enumerate(value)
    for key,child in children:result.extend(shapes(child,path+'/'+str(key),seen))
    return result


def next_index(engine,iterator,reason):
    remaining=iterator['remaining']
    if not remaining:return None
    choices=list(range(len(remaining)))
    info=getattr(iterator.get('backing'),'repository_order',None)
    if info:
        from .engine import CompletionRequired,AnalysisBoundary
        if not info['supported']:raise AnalysisBoundary('repository iteration order is outside scope: '+info.get('reason',''),category='unsupported_semantics')
        variants=info['variants']
        if 'order_variant' not in iterator:
            label=reason+':repository-null-order'
            selected=engine.choose(label,list(range(len(variants)))) if len(variants)>1 else 0
            if selected is None:
                if not engine.allow_completion_splits:raise AnalysisBoundary('repository null-order completion budget: '+reason)
                raise CompletionRequired(str(engine.branch_index)+':'+label,list(range(len(variants))))
            iterator['order_variant']=selected
        groups=variants[iterator['order_variant']]
        group=next((g for g in groups if any(i in remaining for i in g)),[])
        choices=[position for position,index in enumerate(remaining) if index in group]
        if not choices:raise AnalysisBoundary('repository encounter witness no longer covers remaining values: '+reason,category='unsupported_semantics')
    selected=engine.choose(reason+':unordered-collection-next',choices) if len(choices)>1 else choices[0]
    if selected is None:
        from .engine import CompletionRequired,AnalysisBoundary
        if not engine.allow_completion_splits:raise AnalysisBoundary('collection encounter order needs a continuation: '+reason)
        raise CompletionRequired(str(engine.branch_index)+':'+reason+':unordered-collection-next',choices)
    return remaining.pop(selected)


def call(engine,name,values,args,kinds,reason):
    if not isinstance(values,JavaList) or values.flavor!='HashSet':return False,U
    if name=='stream' and not args:return False,U
    def boundary(message,write=False):
        engine.approximate=True;engine.warnings.add('Java Set '+message+': '+reason)
        engine.operation_issues[('java_set_boundary',message)]+=1
        if write:values.opaque=True
        return True,U
    def index(value,kind):
        version=values.structural_version
        hashed=hash_value(engine,value,kind,reason)
        if values.structural_version!=version:stop('reentrant Set mutation during hashCode: '+reason)
        if hashed is U:return U,U
        hashed=(hashed & 0xffffffff)^((hashed & 0xffffffff)>>16)
        stored=getattr(values,'set_hashes',None)
        if stored is None:
            if values:stop('stored key placement metadata is unavailable: '+reason)
            values.set_hashes=stored=[]
        if len(stored)!=len(values):stop('stored key placement metadata is unresolved: '+reason)
        for i,item in enumerate(values):
            if stored[i]!=hashed:continue
            equal=key_equal(engine,value,item,kind,values.kinds[i],reason)
            if values.structural_version!=version:stop('reentrant Set mutation during equals: '+reason)
            if equal is True:return i,hashed
            if equal is U:return U,hashed
        return -1,hashed
    if name=='clear' and not args:values.clear();values.set_hashes=[];return True,None
    if values.opaque:return boundary('membership is unresolved',name in ('add','addAll','remove','removeAll','retainAll'))
    if name in ('size','isEmpty') and not args:return True,len(values) if name=='size' else not values
    if name in ('add','contains','remove') and len(args)==1:
        found,hashed=index(args[0],kinds[0])
        if found is U:return boundary('element equality or hash contract is unresolved',name!='contains')
        if name=='contains':return True,found!=-1
        if name=='add':
            if found!=-1:return True,False
            # Linked-bin OpenJDK HashMap scope; treeified bins require another
            # comparison order contract. Keep this limit independent of paths.
            capacity=16
            while len(values)+1>capacity*3//4:capacity*=2
            if sum((h & (capacity-1))==(hashed & (capacity-1)) for h in values.set_hashes)>=7:
                stop('treeification/collision-bin scope exceeded: '+reason)
            values.append(args[0],kinds[0]);values.set_hashes.append(hashed);return True,True
        if found==-1:return True,False
        values.pop(found);values.set_hashes.pop(found);return True,True
    if name in ('addAll','removeAll','retainAll') and len(args)==1:
        other=args[0]
        if other is None:
            from .java_exceptions import JavaThrow
            raise JavaThrow({'__type__':'NullPointerException'})
        if not isinstance(other,JavaList) or other.opaque:return boundary('bulk membership is unresolved',True)
        if name!='addAll' and any(value is not None and kind not in ('String','Integer','Long','Short','Byte','Character','Boolean') for value,kind in zip(other,other.kinds)):
            from .engine import AnalysisBoundary
            raise AnalysisBoundary('Java Set bulk equality/hash callbacks are outside the scalar contract: '+reason,category='unsupported_semantics')
        if name=='addAll':
            changed=False
            from .java_lists import iteration
            scalar=all(value is None or kind in SCALARS for value,kind in zip(other,other.kinds))
            entries=zip(list(other),list(other.kinds)) if scalar else iteration(engine,other,reason+':addAll source')
            for value,kind in entries:
                _,result=call(engine,'add',values,[value],[kind],reason)
                if result is U:return True,U
                changed|=result
            return True,changed
        kept=[];kept_kinds=[];kept_hashes=[]
        for position,(value,kind) in enumerate(zip(values,values.kinds)):
            comparisons=[boxed_equal(value,item,kind,other.kinds[i],lambda a,b:a==b) for i,item in enumerate(other)]
            present=True if True in comparisons else U if U in comparisons else False
            if present is U:return boundary('bulk element equality is unresolved',True)
            if present==(name=='retainAll'):
                kept.append(value);kept_kinds.append(kind);kept_hashes.append(values.set_hashes[position])
        changed=len(kept)!=len(values)
        if changed:values[:]=kept;values.kinds[:]=kept_kinds;values.set_hashes=kept_hashes
        return True,changed
    if name=='iterator' and not args:return False,U
    if name=='equals' and len(args)==1:
        other=args[0]
        if not isinstance(other,JavaList) or other.flavor!='HashSet':return True,False
        if other.opaque:return boundary('equality contents are unresolved')
        if len(values)!=len(other):return True,False
        found=[index(value,kind)[0] for value,kind in zip(other,other.kinds)]
        return boundary('equality is unresolved') if U in found else (True,all(i!=-1 for i in found))
    return boundary('operation is outside the supported scalar contract: '+name)
